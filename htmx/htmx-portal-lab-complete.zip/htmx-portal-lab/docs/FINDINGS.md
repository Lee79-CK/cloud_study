# 측정으로 바로잡은 것

시리즈를 만들며 문서나 짐작과 다르게 동작해 직접 측정·소스 확인으로 바로잡은 내용이다. 각 항목의 자세한 측정은 해당 편 강의에 있다.

| 편 | 영역 | 발견 | 대응 |
|---|---|---|---|
| 4 | 트리거 | hx-trigger의 from: 값에 공백이 있으면(closest article) 감싸지 않을 때 경고 없이 실패 | from:'closest article'처럼 따옴표 |
| 5 | 스왑 | settle 기본값이 1ms (2.x는 20ms) | settle 타이밍에 기대던 CSS 전환 점검 |
| 5 | 스왑 | 2.x의 show:#other:top이 4.x에서 동작하지 않음 | show:top showTarget:#other |
| 5 | 스왑 | htmx-added 클래스로 페이드인이 되지 않음 | @keyframes 사용 |
| 5 | 스왑 | OOB·partial만 있는 빈 본문 응답에서는 본 스왑을 건너뜀 | 필요하면 swapEmpty |
| 5 | 스왑 | 앞 요소가 있는 응답의 OOB 표 행은 HTML 파서가 버림 | <hx-partial> 사용 |
| 6 | 서버 응답 | hx-status 값 none은 효과 없음 | swap:none |
| 6 | 서버 응답 | HX-Location을 처리하면 그 응답의 OOB는 무시됨 (HX-Trigger는 유지) | 토스트 대신 이벤트 |
| 6 | 서버 응답 | 시간 초과는 error.name이 아니라 signal.reason === 'timeout'으로 구분 | 전역 오류 처리에 반영 |
| 6 | FastAPI | 500 응답에 요청 ID가 빠짐 | call_next를 try/except로 |
| 7 | 히스토리 | 뒤로 가기 복원 요청에 HX-Request가 없음 (HX-History-Restore-Request·HX-Request-Type만) | 두 헤더 중 하나면 htmx 요청으로 판별 |
| 7 | 히스토리 | htmx 링크의 Ctrl·Cmd·Shift+클릭이 막힘 | 캡처 단계에서 stopPropagation |
| 7 | 히스토리 | hx-history-cache는 세션 만료 뒤에도 캐시로 화면을 복원 | 민감 화면은 hx-history="false" |
| 7 | 부스트 | body 안 모듈 스크립트는 부스트 재방문 때 다시 실행되지 않음 | head에서 한 번 (11·12·20편에서 완전 해결) |
| 8 | 이벤트 | config:request를 취소하면 finally:request도 오지 않음 | 진행 표시는 before에서 넣고 finally에서 있으면 뺌 |
| 8 | 이벤트 | confirm 거절 시 before:request 없이 finally:request만 옴 | 같은 처리 |
| 9 | 모핑 | 모핑은 data-* 속성을 서버 HTML 기준으로 덮어씀 | morphIgnore 또는 조상 요소에 상태 |
| 9 | Alpine | hx-alpine-compat 없이 모핑하면 화면만 되돌아가고 Alpine 상태는 그대로 | compat 확장 |
| 10 | SSE | 자기 변경이 SSE로 먼저 와서 응답 대상이 떨어지면 htmx가 응답(토스트 포함)을 버림 | 탭 ID로 자기 변경 제외 (21편에서 확장) |
| 10 | preload | preload 요청은 config:request를 거치지 않아 거기서 붙인 헤더가 없음 | 쿠키 기반 GET에만 |
| 10 | WebSocket | hx-ws 메시지 형식·이벤트 이름이 일부 문서와 4.0.1 소스가 다름 | 배포본 소스 기준 |
| 10 | 확장 | detail.warn 자동 기록은 내부 API(triggerHtmxEvent)에서만 | init으로 받은 API 사용 |
| 11 | 소유권 | htmx가 React 컨테이너를 덮어써도 즉시 오류 없이 어긋나고, 구조가 바뀌는 순간 removeChild 오류 | 안쪽을 대상으로 삼지 않기 |
| 11 | 소유권 | 컨테이너가 사라져도 언마운트하지 않으면 API 요청이 계속됨 (누수) | 정리 호출 (12편 웹 컴포넌트) |
| 11 | 소유권 | hx-ignore는 초기화만 막고, 모핑은 hx-ignore와 무관하게 자식을 맞춤 | 웹 컴포넌트·섀도 DOM |
| 12 | 웹 컴포넌트 | moveBefore로 옮기면 connectedMoveCallback만 불림 (정의 시) | 분리 콜백은 한 틱 뒤 확인 후 정리 |
| 12 | 웹 컴포넌트 | hx-preserve의 응답 쪽 자리표시 요소가 잠깐 마운트됨 | 비싼 아일랜드는 가벼운 자리표시 |
| 13 | 이벤트 | 섀도 안에서 bubbles만으로는 경계를 못 넘음 (composed 필요) | 호스트에서 이벤트 발생 |
| 13 | 이벤트 | hx-vals js: 식에는 event가 없음 | ctx.sourceEvent |
| 13 | 모핑 | VM별 id가 모핑 짝 맞춤을 깨 새 요소가 마운트됨 | 역할 기준 고정 id |
| 14 | SPA | React만 영역을 지우면 SSE 연결이 32초 넘게 남음 | 언마운트 때 htmx.swap으로 비우기 |
| 14 | SPA | htmx.ajax에 source가 없으면 이벤트가 body에서 발생 | source: 영역 div |
| 14 | SPA | htmx history를 켠 SPA에서 hx-push-url 후 뒤로 가기 → React 앱이 사라짐 | SPA에서는 history: false |
| 14 | 빌드 | vite build --mode development만으로는 React 개발 빌드가 아님 | NODE_ENV 명시 |
| 15 | 공유 런타임 | CommonJS인 react를 export *로 재내보내면 이름 있는 내보내기가 없음 | 이름 목록으로 진입점 생성 |
| 15 | 토큰 | 호스트 요소에 걸린 페이지 CSS가 :host보다 우선해 토큰 변경이 안 보임 | 호스트 규칙도 토큰으로 |
| 16 | 이관 | 그림자 비교가 레거시 데이터의 어긋남(VM 수 11 vs 12)을 찾음 | 판단 후 다음 단계로 |
| 17 | CSRF | SameSite=Lax 쿠키는 같은 사이트의 다른 포트 공격을 못 막음 (실제 재시작 성공) | Sec-Fetch-Site·Origin 검사 |
| 17 | CSP | 정적 index.html의 인라인 import map에 nonce가 없어 SPA가 막힘 | 서버가 응답 때 nonce 주입 |
| 18 | 압축 | SSE를 압축하면 메시지가 도착하지 않음 (18초 동안 10바이트) | text/event-stream 제외 |
| 18 | 압축 | 실시간 br(품질 4)이 JS에서 gzip보다 큼 | 정적 파일은 빌드 때 사전 압축 (20편) |
| 18 | 캐시 | Cache-Control이 없으면 브라우저가 추정 신선도로 재검증 없이 재사용 | 정책 명시 |
| 18 | 캐시 | Express 자동 ETag + 브라우저 캐시가 hx-ptag의 304를 200으로 바꿔 매번 스왑 | htmx 응답 no-store |
| 19 | 테스트 | Starlette 1.10 TestClient가 httpx에 지원 중단 경고 | httpx2 (테스트 의존성) |
| 19 | 테스트 | SSE가 있는 페이지에서 networkidle을 기다리면 시간 초과 | 요소 단언으로 대기 |
| 19 | 테스트 | 계약 테스트가 4편의 따옴표 회귀를 실제로 포착 | 두 구현 구조 비교 유지 |
| 20 | 배포 | TLS를 끝내는 프록시 뒤에서 로그인이 403 (출처 계산이 http) | trust proxy / uvicorn --proxy-headers |
| 20 | 배포 | 이미지 USER가 이름이면 runAsNonRoot가 컨테이너를 거부 | 숫자 UID |
| 20 | 자산 | 개발 모드에서 web-vitals가 404 (해시 폴더에만 복사) | postinstall에서 vendor로도 복사 |
| 21 | 실시간 | 새 작업이 다른 사용자의 목록에 나타나지 않음 (없는 행을 교체) | 생성 시 afterbegin |
| 21 | 실시간 | 취소 응답과 SSE가 같은 요소를 바꿔 응답이 버려짐 (2회) | 한 요소의 주인은 하나: 응답은 토스트로만 |
| 21 | FastAPI | Python round()의 .5 처리로 진행률이 62% vs 63% | math.floor(x + 0.5) |
