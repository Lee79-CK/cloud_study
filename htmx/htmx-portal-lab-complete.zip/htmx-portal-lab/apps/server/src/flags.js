// 16편: 기능 플래그 (점진적 대체의 스위치). 실서비스에서는 LaunchDarkly·Unleash·OpenFeature 같은 플래그 서비스나
// 설정 저장소가 이 자리를 맡는다. 배포 없이 경로 단위로 레거시 ↔ 새 구현을 바꾸고, 문제가 있으면 즉시 되돌린다.
const MODES = ['legacy', 'shadow', 'percent', 'new'];
const flags = {
  'customers.list':   { mode: 'legacy', percent: 0, label: '고객사 목록' },
  'customers.detail': { mode: 'legacy', percent: 0, label: '고객사 상세' },
};
const stats = Object.fromEntries(Object.keys(flags).map(k => [k, { legacy: 0, new: 0 }]));
const shadow = [];                 // 그림자 비교 결과 (최근 50건)

function hash(s) { let h = 2166136261; for (const c of s) { h ^= c.codePointAt(0); h = Math.imul(h, 16777619); } return h >>> 0; }

export function listFlags() { return Object.entries(flags).map(([key, f]) => ({ key, ...f, stats: stats[key] })); }
export function setFlag(key, { mode, percent }) {
  const f = flags[key];
  if (!f || !MODES.includes(mode)) return false;
  f.mode = mode;
  f.percent = Math.max(0, Math.min(100, Number(percent) || 0));
  return true;
}
export function resetFlags() {
  for (const f of Object.values(flags)) { f.mode = 'legacy'; f.percent = 0; }
  for (const s of Object.values(stats)) { s.legacy = 0; s.new = 0; }
  shadow.length = 0;
}

/**
 * 이 요청을 어느 구현이 받을지 결정한다.
 * 우선순위: 운영자의 강제 지정(?ff= 또는 쿠키) → 플래그 모드 → 비율이면 사용자 해시로 고정 배정
 * 반환: { impl: 'legacy' | 'new', shadow: boolean, reason }
 */
export function decide(key, user, override) {
  const f = flags[key];
  if (override === 'legacy' || override === 'new') return { impl: override, shadow: false, reason: 'override' };
  if (f.mode === 'new') return { impl: 'new', shadow: false, reason: 'mode' };
  if (f.mode === 'shadow') return { impl: 'legacy', shadow: true, reason: 'shadow' };
  if (f.mode === 'percent') {
    // 같은 사용자는 늘 같은 쪽으로 (새로고침마다 화면이 바뀌지 않게). 비율을 올리면 새 구현 쪽이 늘어나기만 한다
    const bucket = hash(`${user.id}:${key}`) % 100;
    return { impl: bucket < f.percent ? 'new' : 'legacy', shadow: false, reason: `percent bucket=${bucket}` };
  }
  return { impl: 'legacy', shadow: false, reason: 'mode' };
}
export function count(key, impl) { stats[key][impl]++; }
export function recordShadow(entry) { shadow.unshift({ at: new Date(), ...entry }); shadow.length = Math.min(shadow.length, 50); }
export function shadowResults() { return shadow; }
