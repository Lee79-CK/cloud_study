// node_modules의 htmx 배포본을 public/vendor로 복사한다.
// Express 서버와 FastAPI 대안 서버가 같은 파일을 쓰도록 한 곳에 둔다.
import { createRequire } from 'node:module';
import { cpSync, existsSync, mkdirSync, readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const htmxDir = dirname(require.resolve('htmx.org/package.json'));
const { version } = JSON.parse(readFileSync(join(htmxDir, 'package.json'), 'utf8'));
const dest = join(dirname(fileURLToPath(import.meta.url)), '..', 'public', 'vendor', 'htmx');

mkdirSync(dest, { recursive: true });
cpSync(join(htmxDir, 'dist', 'htmx.min.js'), join(dest, 'htmx.min.js'));
cpSync(join(htmxDir, 'dist', 'ext'), join(dest, 'ext'), { recursive: true });
console.log(`[vendor] htmx ${version} → public/vendor/htmx`);

// 20편: web-vitals(RUM). 패키지 exports에 package.json이 없어 node_modules 경로로 찾는다 (워크스페이스면 루트로 끌어올려짐)
const wvCandidates = [join(dirname(fileURLToPath(import.meta.url)), '..', 'node_modules', 'web-vitals'),
                      join(dirname(fileURLToPath(import.meta.url)), '..', '..', '..', 'node_modules', 'web-vitals')];
const wvDir = wvCandidates.find(d => existsSync(join(d, 'dist', 'web-vitals.js')));
if (wvDir) {
  cpSync(join(wvDir, 'dist', 'web-vitals.js'), join(dest, '..', 'web-vitals.js'));
  console.log(`[vendor] web-vitals ${JSON.parse(readFileSync(join(wvDir, 'package.json'), 'utf8')).version} → public/vendor/web-vitals.js`);
}
