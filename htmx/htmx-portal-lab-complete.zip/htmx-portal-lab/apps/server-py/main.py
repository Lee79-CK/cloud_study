"""FastAPI 대안 서버 — Express 서버(apps/server)와 같은 URL·같은 동작."""
import asyncio
import json
import os
import threading
from datetime import datetime
import secrets
import time
import uuid
import re
from pathlib import Path
from urllib.parse import quote, unquote, urlencode

from fastapi import FastAPI, Form, Request, WebSocket, WebSocketDisconnect
from fastapi.encoders import jsonable_encoder
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, PlainTextResponse, RedirectResponse, Response, StreamingResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.gzip import GZipMiddleware
from fastapi.templating import Jinja2Templates

import httpx
from prometheus_client import Counter, Gauge, Histogram, start_http_server

import assertion
import auth
import flags
import jobs
import store

HERE = Path(__file__).parent
PUBLIC = HERE.parent / "server" / "public"          # htmx 배포본·CSS·아일랜드 번들을 Express와 공유

app = FastAPI()

# 20편: 자산 매니페스트 (npm run build:assets). 운영(APP_ENV=production) 또는 USE_DIST=1이면 매니페스트,
# 개발 중에는 원본 경로 + Vite 매니페스트(감시 빌드가 갱신)를 그때그때 읽는다 (Express와 같은 규칙)
MANIFEST_FILE = PUBLIC / "dist" / "manifest.json"
MANIFEST = json.loads(MANIFEST_FILE.read_text(encoding="utf-8")) if MANIFEST_FILE.exists() else {}
USE_DIST = os.environ.get("APP_ENV") == "production" or os.environ.get("USE_DIST") == "1"
VITE_ENTRIES = {"islands/react.js": ("islands/react", "src/main.jsx"), "islands/vue.js": ("islands/vue", "src/main.js"),
                "shared/react.js": ("shared", "src/react.js"), "shared/react-jsx-runtime.js": ("shared", "src/react-jsx-runtime.js"),
                "shared/react-dom-client.js": ("shared", "src/react-dom-client.js")}


def _vite_entry(d: str, src: str) -> str | None:
    try:
        return f"/{d}/" + json.loads((PUBLIC / d / ".vite" / "manifest.json").read_text(encoding="utf-8"))[src]["file"]
    except (OSError, KeyError, ValueError):
        return None


def asset(name: str) -> str:
    if USE_DIST:
        return MANIFEST.get(name, f"/{name}")
    return (_vite_entry(*VITE_ENTRIES[name]) if name in VITE_ENTRIES else None) or f"/{name}"


def island_bundles() -> dict:
    return {"metric-chart": asset("islands/react.js"), "hello-react": asset("islands/react.js"),
            "metric-summary": asset("islands/vue.js"), "hello-vue": asset("islands/vue.js")}


print(f"[assets] {f'매니페스트 {len(MANIFEST)}개 항목 사용' if USE_DIST else '개발 모드: 원본 경로 + Vite 매니페스트'}")

# 20편: 관측 지표 (Prometheus). 업무 포트와 분리된 포트에서만 노출 (기본 9464, 로컬에서 Express와 함께 띄우면 9465)
HTTP_DURATION = Histogram("portal_http_request_duration_seconds", "HTTP 요청 처리 시간", ["method", "route", "status", "htmx"],
                          buckets=(0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5))
FLAG_SERVED = Counter("portal_flag_served_total", "16편 기능 플래그 경로별 응답 구현", ["flag", "impl"])
SHADOW_COMPARE = Counter("portal_shadow_compare_total", "16편 그림자 비교 결과", ["flag", "result"])
WEB_VITALS = Histogram("portal_web_vitals_seconds", "실사용자 Web Vitals (초)", ["name", "page", "rating"],
                       buckets=(0.1, 0.2, 0.5, 0.8, 1, 1.8, 2.5, 3, 4, 6))
JOBS_TOTAL = Counter("portal_jobs_total", "21편 패치 작업 종료 수", ["result"])
JOB_DURATION = Histogram("portal_job_duration_seconds", "21편 패치 작업 소요 시간", ["result"], buckets=(1, 2, 5, 10, 20, 30, 60, 120))
WEB_VITALS_CLS = Histogram("portal_web_vitals_cls", "실사용자 CLS", ["page", "rating"], buckets=(0.01, 0.05, 0.1, 0.15, 0.25, 0.5))
if os.environ.get("METRICS_PORT", "9464") != "off":       # 테스트(TestClient)에서는 METRICS_PORT=off
    try:
        start_http_server(int(os.environ.get("METRICS_PORT", "9464")))
    except OSError as e:
        print(f"[metrics] 지표 포트를 열 수 없음: {e}")
templates = Jinja2Templates(directory=HERE / "templates")   # Jinja2는 .html 템플릿을 자동 이스케이프


def htmx_info(request: Request) -> dict | None:
    # 7편: 뒤로 가기 복원 요청은 htmx 4.0.1에서 HX-Request 없이 HX-History-Restore-Request만 온다(실측)
    restore = request.headers.get("hx-history-restore-request") == "true"
    if request.headers.get("hx-request") != "true" and not restore:
        return None
    return {
        "type": request.headers.get("hx-request-type") or "full",
        "source": request.headers.get("hx-source"),
        "target": request.headers.get("hx-target"),
        "boosted": request.headers.get("hx-boosted") == "true",
        "restore": restore,
    }


def view_globals() -> dict:
    """6편: 모든 템플릿에 공통으로 넘기는 값 (현재 사용자와 쓰기 권한)"""
    user = auth.current_user.get()
    return {"labels": store.STATUS_LABEL, "channels": store.CHANNELS, "user": user,
            "role_label": auth.ROLE_LABEL, "can_edit": bool(user and user["role"] == "operator"),
            "activity_version": store.activity_version, "nonce": auth.current_nonce.get(),
            "asset": asset, "island_bundles": island_bundles()}     # 20편


def route_template(request: Request, default: str = "") -> str:
    """20편: 지표 라벨용 라우트 템플릿. FastAPI의 /vms/{name}을 Express와 같은 /vms/:name 모양으로"""
    route = request.scope.get("route")
    path = getattr(route, "path", None)
    return re.sub(r"\{(\w+)(:[^}]*)?\}", r":\1", path) if path else default


def render(request: Request, name: str, ctx: dict | None = None, status: int = 200) -> HTMLResponse:
    context = {**view_globals(), "page": route_template(request), **(ctx or {})}   # 20편: RUM용 라우트 템플릿
    return templates.TemplateResponse(request, name, context, status_code=status)


PUBLIC_PATHS = [r"^/login", r"^/logout", r"^/legacy/", r"^/noop$", r"^/rum$", r"^/(healthz|readyz)$"]   # 20편
ROLE_FREE = [r"^/login", r"^/logout", r"^/session/", r"/alerts/check$"]
STATIC = ("/vendor", "/css", "/islands", "/js", "/shared", "/dist")   # 7편: 공통 스크립트도 로그인 없이, 18편: 공유 런타임, 20편: 해시 자산
HASHED = ("/dist/", "/islands/", "/shared/", "/console/assets/")
TYPES = {".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".json": "application/json; charset=utf-8"}


@app.middleware("http")
async def auth_and_log(request: Request, call_next):
    """6편: 세션 확인 → 역할 확인 → 처리 → 로그. Express의 ②·②-2·②-3 미들웨어를 하나로 합친 것"""
    path = request.url.path
    t0 = time.perf_counter()
    hx = htmx_info(request)
    session = auth.get_session(request.cookies.get("sid"))
    user = ({"id": session["user_id"], "name": auth.USERS[session["user_id"]]["name"], "role": session["role"],
             "sid": request.cookies.get("sid")} if session else None)
    request.state.user = user
    auth.current_user.set(user)          # part()·render()가 읽는 현재 사용자
    cid = request.headers.get("x-client-id", "")
    auth.current_client.set(cid if re.fullmatch(r"[0-9a-fA-F-]{8,64}", cid) else None)   # 10편: 탭 식별자
    origin = f"{request.url.scheme}://{request.url.netloc}"
    is_write = request.method in ("POST", "PUT", "PATCH", "DELETE")

    # 17편: 요청마다 CSP nonce (템플릿의 인라인 import map에 같은 값)
    nonce = secrets.token_urlsafe(16)
    auth.current_nonce.set(nonce)
    request.state.nonce = nonce
    sec_headers = {"X-Content-Type-Options": "nosniff", "Referrer-Policy": "same-origin", "Cross-Origin-Opener-Policy": "same-origin"}
    if not path.startswith("/lab/csp"):
        sec_headers["Content-Security-Policy"] = "; ".join([
            "default-src 'self'", f"script-src 'self' 'nonce-{nonce}' 'unsafe-eval'", "style-src 'self' 'unsafe-inline'",
            "img-src 'self' data:", "connect-src 'self'", "object-src 'none'", "base-uri 'self'", "form-action 'self'", "frame-ancestors 'none'"])
    if path.startswith(STATIC):
        hashed = path.startswith(HASHED) and "/.vite/" not in path
        # 20편: 사전 압축 파일(.br/.gz)이 있으면 그것을 보낸다
        ext = path[path.rfind("."):]
        if hashed and ext in TYPES and request.method in ("GET", "HEAD"):
            accept = request.headers.get("accept-encoding", "")
            for enc, suffix in (("br", ".br"), ("gzip", ".gz")):
                f = (PUBLIC / path.lstrip("/")).resolve()
                pre = f.with_name(f.name + suffix)
                if re.search(rf"\b{enc}\b", accept) and pre.is_file() and pre.is_relative_to(PUBLIC.resolve()):
                    resp = FileResponse(pre, media_type=TYPES[ext], headers={
                        "Content-Encoding": enc, "Vary": "Accept-Encoding", "Cache-Control": "public, max-age=31536000, immutable", **sec_headers})
                    return resp
        response = await call_next(request)
        response.headers.update(sec_headers)
        # 18편→20편: 캐시 정책. 해시 폴더는 1년 immutable, 이름이 고정된 원본(/vendor, /js, /css)은 no-cache
        response.headers["Cache-Control"] = "public, max-age=31536000, immutable" if hashed else "no-cache"
        return response
    # 17편: CSRF 방어 (Fetch Metadata) — 상태를 바꾸는 요청은 같은 출처만
    if request.method not in ("GET", "HEAD", "OPTIONS") and os.environ.get("CSRF_CHECK") != "off":
        site = request.headers.get("sec-fetch-site")
        origin_h = request.headers.get("origin")
        self_origin = f"{request.url.scheme}://{request.url.netloc}"
        bad = (site not in ("same-origin", "none")) if site else (origin_h is not None and origin_h != self_origin)
        if bad:
            print(f"CSRF   차단 {request.method} {path} Sec-Fetch-Site={site or '-'} Origin={origin_h or '-'}")
            resp = PlainTextResponse("Forbidden: cross-origin request", status_code=403)
            resp.headers.update(sec_headers)
            return resp
    # 8편: 요청 ID (클라이언트가 붙인 X-Request-ID를 쓰고 없으면 만든다)
    rid = request.headers.get("x-request-id", "")
    rid = rid if re.fullmatch(r"[0-9a-fA-F-]{8,64}", rid) else str(uuid.uuid4())
    request.state.rid = rid
    if user is None and not any(re.match(p, path) for p in PUBLIC_PATHS) and path.startswith("/api/"):
        response = JSONResponse({"error": "unauthenticated"}, status_code=401)   # 11편: 데이터 API는 401 JSON
    elif user is None and not any(re.match(p, path) for p in PUBLIC_PATHS):
        if hx:   # htmx 요청에는 302 대신 401 + HX-Redirect
            # 복원 요청에는 HX-Current-URL이 없으므로 요청 주소(=복원하려는 화면)를 쓴다
            here = path + (f"?{request.url.query}" if request.url.query else "")
            nxt = auth.safe_next(here if hx["restore"] else request.headers.get("hx-current-url"), origin)
            response = Response(status_code=401, headers={"HX-Redirect": "/login?next=" + quote(nxt, safe="")})
        else:
            nxt = auth.safe_next(path + (f"?{request.url.query}" if request.url.query else ""), origin)
            response = RedirectResponse("/login?next=" + quote(nxt, safe=""), status_code=302)
    elif is_write and user and user["role"] != "operator" and not any(re.search(p, path) for p in ROLE_FREE):
        if hx:   # 응답 위치를 토스트 영역으로 바꿔 경고만 보여 준다
            msg = f"권한이 없습니다. {auth.ROLE_LABEL[user['role']]} 계정은 변경할 수 없습니다."
            response = HTMLResponse(part("partials/toast_item.html", {"msg": msg, "kind": "warn"}), status_code=403,
                                    headers={"HX-Retarget": "#toasts", "HX-Reswap": "beforeend"})
        else:
            response = PlainTextResponse("Forbidden", status_code=403)
    else:
        try:
            response = await call_next(request)
        except Exception as exc:   # 8편: 오류 응답에도 요청 ID와 로그가 남도록 미들웨어 안에서 처리
            print(f"ERROR rid={rid[:8]} {type(exc).__name__}: {exc}")
            response = render(request, "partials/error.html", {"message": "서버 오류가 발생했습니다."}, 500)

    flags = (" boosted" if hx and hx["boosted"] else "") + (" history-restore" if hx and hx["restore"] else "")
    tag = f"[htmx:{hx['type']}{flags}] source={hx['source']} target={hx['target']}" if hx else "[page]"
    response.headers["X-Request-ID"] = rid
    for k, v in sec_headers.items():
        response.headers.setdefault(k, v)
    if hx and "cache-control" not in response.headers:
        response.headers["Cache-Control"] = "no-store"     # 18편: htmx 응답은 브라우저 캐시에 저장하지 않음 (Express와 같은 정책)
    who = (f" user={user['id']}" if user else "") + f" rid={rid[:8]}" + (f" served={response.headers['x-served-by']}" if "x-served-by" in response.headers else "")
    url = path + (f"?{unquote(request.url.query)}" if request.url.query else "")
    print(f"{request.method:<6} {url} → {response.status_code} {tag}{who}")
    HTTP_DURATION.labels(request.method, route_template(request, "unmatched"), str(response.status_code),
                         hx["type"] if hx else "none").observe(time.perf_counter() - t0)    # 20편
    return response


@app.get("/")
def home():
    return RedirectResponse("/vms")


@app.get("/vms")
def vms(request: Request, q: str = "", status: str = "", page: int = 1):
    pg = store.paginate(store.search(q, status), page)
    more = "/vms?" + urlencode({"q": q, "status": status, "page": pg["next_page"]}) if pg["next_page"] else None
    hx = htmx_info(request)
    ctx = {"list": pg["items"], "more": more, "q": q, "status": status, "total": pg["total"]}
    if hx and hx["type"] == "partial":
        name = "partials/vm_rows.html" if pg["page"] > 1 else "partials/vm_rows_response.html"
        resp = render(request, name, ctx)
        if pg["page"] == 1:   # 6편: 검색 조건을 주소창에 반영 (기록을 쌓지 않고 교체)
            qs = urlencode({k: v for k, v in {"q": q, "status": status}.items() if v})
            resp.headers["HX-Replace-Url"] = "/vms" + (f"?{qs}" if qs else "")
    else:
        resp = render(request, "pages/vms.html", {"title": "VM 관리", "sum": store.summary(), **ctx})
    resp.headers["Vary"] = "HX-Request, HX-Request-Type"
    return resp


# 6편: VM 등록 — 폼(GET)과 생성(POST). 성공하면 201 + HX-Location
@app.get("/vms/new")
def vm_new_form(request: Request):
    return render(request, "partials/vm_new_form.html", {"values": {"customer": ""}, "errors": {}})


@app.post("/vms")
async def vm_create(request: Request):
    r = store.create_vm(dict(await request.form()))
    if not r["ok"]:
        return render(request, "partials/vm_new_form.html", {"values": r["values"], "errors": r["errors"]}, 422)
    name = r["vm"]["name"]
    return Response(status_code=201, headers={
        "HX-Location": json.dumps({"path": f"/vms/{name}", "target": "#detail"}),
        "HX-Trigger": json.dumps({"vmChanged": {"name": name}}),
    })


# 9편: 일괄 재시작. /vms/{name}/{action}보다 먼저 선언
@app.post("/vms/bulk/restart")
async def vm_bulk_restart(request: Request):
    form = await request.form()
    names = form.getlist("sel")            # 같은 이름이 여러 번 오면 목록으로
    done, skipped = [], []
    for n in names:
        status, _ = store.transition(n, "restart")
        (done if status == 200 else skipped).append(n)
    q, st = form.get("q", ""), form.get("status", "")
    pg = store.paginate(store.search(q, st), 1)
    more = "/vms?" + urlencode({"q": q, "status": st, "page": pg["next_page"]}) if pg["next_page"] else None
    msg = f"{len(done)}대 재시작 요청" + (f", {len(skipped)}대 건너뜀(실행 중이 아님): {', '.join(skipped)}" if skipped else "")
    html = part("partials/vm_rows_response.html", {"list": pg["items"], "more": more, "q": q, "total": pg["total"]})
    resp = HTMLResponse(html + toast(msg, "warn" if skipped else "ok"))
    if done:
        resp.headers["HX-Trigger"] = json.dumps({"vmChanged": {"names": done}}, ensure_ascii=False)
    return resp


# 4편: 요약 카드 (폴링 대상). /vms/{name}보다 먼저 선언
@app.get("/vms/summary")
def vm_summary(request: Request):
    return render(request, "partials/summary.html", {"sum": store.summary()})


# ---- 3편: VM 상세 (GET) — 같은 URL이 조각과 전체 페이지를 모두 낸다 ----
@app.get("/vms/{name}")
def vm_detail(request: Request, name: str):
    vm = store.find(name)
    hx = htmx_info(request)
    partial = bool(hx and hx["type"] == "partial")
    if vm is None:
        message = f"{name}은(는) 없는 VM입니다."
        resp = (render(request, "partials/error.html", {"message": message}, 404) if partial
                else render(request, "pages/not_found.html", {"title": "페이지 없음", "message": message}, 404))
    else:
        ctx = {"vm": vm, "activity": store.activity_page(vm)}
        if partial:   # 7편: 주소를 push하는 상세 조각에 <title>을 넣어 탭 제목도 바꾼다
            resp = HTMLResponse(part("partials/doc_title.html", {"text": f"{vm['name']} · VM 관리"})
                                + part("partials/vm_detail.html", ctx))
        else:         # 7편: 주소만으로 "목록 + 상세가 열린 패널"을 재현
            pg = store.paginate(store.search("", ""), 1)
            more = "/vms?" + urlencode({"q": "", "status": "", "page": pg["next_page"]}) if pg["next_page"] else None
            resp = render(request, "pages/vms.html", {"title": f"{vm['name']} · VM 관리", "list": pg["items"], "more": more,
                                                     "q": "", "status": "", "total": pg["total"], "sum": store.summary(),
                                                     "detail": ctx})
    resp.headers["Vary"] = "HX-Request, HX-Request-Type"
    return resp


def part(name: str, ctx: dict) -> str:
    """템플릿 하나를 문자열로 렌더링 (응답 여러 개를 이어 붙일 때 사용)"""
    return templates.get_template(name).render({**view_globals(), **ctx})


def toast(msg: str, kind: str = "ok") -> str:
    """5편: 토스트 알림을 OOB(hx-swap-oob="beforeend:#toasts")로 응답 끝에 덧붙인다"""
    return part("partials/toast.html", {"msg": msg, "kind": kind})


def with_activity(vm: dict, html: str) -> str:
    return html + part("partials/activity_new.html", {"vm": vm, "item": vm["activity"][0]})


def not_found_vm(request: Request, name: str) -> HTMLResponse:
    return render(request, "partials/error.html", {"message": f"{name}은(는) 없는 VM입니다."}, 404)


@app.get("/vms/{name}/memo")
def memo_view(request: Request, name: str):
    vm = store.find(name)
    return HTMLResponse(part("partials/memo_view.html", {"vm": vm})) if vm else not_found_vm(request, name)


@app.get("/vms/{name}/memo/edit")
def memo_edit(request: Request, name: str):
    vm = store.find(name)
    return HTMLResponse(part("partials/memo_edit.html", {"vm": vm, "draft": vm["memo"]})) if vm else not_found_vm(request, name)


@app.put("/vms/{name}/memo")
def memo_save(request: Request, name: str, memo: str = Form("")):
    vm = store.find(name)
    if vm is None:
        return not_found_vm(request, name)
    error = store.set_memo(vm, memo)
    if error:
        return HTMLResponse(part("partials/memo_edit.html", {"vm": vm, "draft": memo, "error": error}), status_code=422)
    return HTMLResponse(with_activity(vm, part("partials/memo_view.html", {"vm": vm})) + toast("메모를 저장했습니다."))


@app.post("/vms/{name}/tags")
def tag_add(request: Request, name: str, tag: str = Form("")):
    vm = store.find(name)
    if vm is None:
        return not_found_vm(request, name)
    error = store.add_tag(vm, tag)
    if error:
        return HTMLResponse(part("partials/tags.html", {"vm": vm, "draft": tag, "error": error}), status_code=422)
    return HTMLResponse(with_activity(vm, part("partials/tags.html", {"vm": vm})) + toast(f"태그를 추가했습니다: {tag.strip().lower()}"))


@app.delete("/vms/{name}/tags/{tag}")
def tag_remove(request: Request, name: str, tag: str):
    vm = store.find(name)
    if vm is None:
        return not_found_vm(request, name)
    error = store.remove_tag(vm, tag)
    if error:
        return HTMLResponse(part("partials/tags.html", {"vm": vm, "error": error}), status_code=404)
    return HTMLResponse(with_activity(vm, part("partials/tags.html", {"vm": vm})))


@app.patch("/vms/{name}")
def vm_patch(request: Request, name: str, monitoring: str | None = Form(None)):
    vm = store.find(name)
    if vm is None:
        return not_found_vm(request, name)
    on = monitoring == "on"   # 체크 해제 시 필드 자체가 오지 않는다
    store.set_monitoring(vm, on)
    return HTMLResponse(with_activity(vm, part("partials/monitoring.html", {"vm": vm}))
                        + toast(f"모니터링을 {'켰' if on else '껐'}습니다."))


# ---- 5편: 알림 설정 — 입력 중 검증(POST check)과 저장(PUT). 클라이언트는 outerMorph ----
@app.get("/vms/{name}/alerts")
def alerts_view(request: Request, name: str):
    vm = store.find(name)
    if vm is None:
        return not_found_vm(request, name)
    return HTMLResponse(part("partials/alerts_form.html", {"vm": vm, "values": vm["alerts"], "errors": {}}))


@app.post("/vms/{name}/alerts/check")
async def alerts_check(request: Request, name: str):
    vm = store.find(name)
    if vm is None:
        return not_found_vm(request, name)
    r = store.check_alerts(dict(await request.form()))
    return HTMLResponse(part("partials/alerts_form.html", {"vm": vm, "values": r["values"], "errors": r["errors"], "dirty": True}))


@app.put("/vms/{name}/alerts")
async def alerts_save(request: Request, name: str):
    vm = store.find(name)
    if vm is None:
        return not_found_vm(request, name)
    r = store.save_alerts(vm, dict(await request.form()))
    if not r["ok"]:
        return HTMLResponse(part("partials/alerts_form.html", {"vm": vm, "values": r["values"], "errors": r["errors"], "dirty": True}),
                            status_code=422)
    # 13편: 서버 → 아일랜드. 차트 태그를 partial + outerMorph로 실어 threshold 속성만 바꾼다
    chart = f'<hx-partial hx-target="#detail-chart" hx-swap="outerMorph">{part("partials/metric_chart.html", {"vm": vm})}</hx-partial>'
    return HTMLResponse(with_activity(vm, part("partials/alerts_form.html", {"vm": vm, "values": vm["alerts"], "errors": {}, "saved": True}))
                        + chart + toast("알림 설정을 저장했습니다."))


@app.get("/noop")
def noop():
    return HTMLResponse("")   # 토스트의 hx-swap="delete"용 빈 응답


@app.get("/vms/{name}/activity")
def vm_activity(request: Request, name: str, before: float = float("inf")):
    vm = store.find(name)
    if vm is None:
        return not_found_vm(request, name)
    return HTMLResponse(part("partials/activity_items.html", {"vm": vm, "activity": store.activity_page(vm, before)}))


@app.get("/vms/{name}/row")
def vm_row(request: Request, name: str):
    vm = store.find(name)
    if vm is None:
        return HTMLResponse("")
    return render(request, "partials/vm_row.html", {"vm": vm})


@app.post("/vms/{name}/{action}")
def vm_action(request: Request, name: str, action: str):
    if action not in ("restart", "start"):
        return render(request, "partials/error.html", {"message": f"알 수 없는 작업: {action}"}, 400)
    status, vm = store.transition(name, action)
    if vm is None:
        return render(request, "partials/error.html", {"message": f"{name}은(는) 없는 VM입니다."}, 404)
    msg = f"{name}: 지금 상태에서는 할 수 없는 작업입니다." if status != 200 else f"{name} {'재시작' if action == 'restart' else '시작'} 요청을 보냈습니다."
    resp = HTMLResponse(part("partials/vm_row.html", {"vm": vm}) + toast(msg, "ok" if status == 200 else "warn"), status_code=status)
    if status == 200:  # 4편: 요약 카드가 from:document로 듣는 이벤트
        resp.headers["HX-Trigger"] = json.dumps({"vmChanged": {"name": name}}, ensure_ascii=False)
    return resp


@app.delete("/vms/{name}")
def vm_delete(request: Request, name: str):
    if not store.remove(name):
        return render(request, "partials/error.html", {"message": "이미 삭제된 VM입니다."}, 404)
    trigger = json.dumps({"vmRemoved": {"name": name, "target": "#vm-app"}, "vmChanged": {"name": name}},
                         ensure_ascii=False)
    # OOB 토스트만 있는 응답. 행 삭제 버튼의 hx-swap="outerHTML swapEmpty"가 빈 본문 교체를 명시 (5편)
    return HTMLResponse(toast(f"{name}을(를) 삭제했습니다."), headers={"HX-Trigger": trigger})


@app.post("/lab/reset")
async def lab_reset():
    store.reset()
    jobs.reset_jobs()                          # 21편
    flags.reset_flags()                       # 16편
    try:
        await _http.post(os.environ.get("LEGACY_URL", "http://localhost:3102") + "/reset",
                         headers={"X-Portal-Assertion": assertion.sign_assertion("system", "operator", "reset", "legacy-crm")})
    except httpx.HTTPError:
        pass
    return HTMLResponse("", headers={"HX-Refresh": "true"})


# ---- 10편: 실시간 갱신 (SSE) ----
_sse_log: list[dict] = []
_sse_seq = 0
_sse_clients: set = set()
Gauge("portal_sse_connections", "10편 SSE 연결 수").set_function(lambda: len(_sse_clients))   # 20편
_loop: asyncio.AbstractEventLoop | None = None
_sse_lock = threading.Lock()


def _on_change(ev: dict) -> None:
    """store가 어느 스레드에서 부르든 이벤트 루프로 넘긴다"""
    global _sse_seq
    # 요청 처리 중의 변경이면 그 탭이 origin (타이머 스레드에서 온 settled는 문맥이 없어 None)
    origin = None if ev["kind"] == "settled" else auth.current_client.get()
    with _sse_lock:
        _sse_seq += 1
        entry = {"id": _sse_seq, **ev, "origin": origin}
        _sse_log.append(entry)
        del _sse_log[:-200]
    if _loop:
        for q in list(_sse_clients):
            _loop.call_soon_threadsafe(q.put_nowait, [entry])


store.listeners.append(_on_change)


def _on_job_change(ev: dict) -> None:
    """21편: 작업 진행도 같은 SSE로. 생성만 요청한 탭을 뺀다 (진행·완료·취소는 모두에게 — 작업 상세는 SSE가 소유)"""
    global _sse_seq
    origin = auth.current_client.get() if ev["kind"] == "created" else None
    with _sse_lock:
        _sse_seq += 1
        entry = {"id": _sse_seq, "names": [], "kind": "job", "job": ev["id"], "job_kind": ev["kind"], "origin": origin}
        _sse_log.append(entry)
        del _sse_log[:-200]
    if _loop:
        for q in list(_sse_clients):
            _loop.call_soon_threadsafe(q.put_nowait, [entry])
    if ev["kind"] in ("done", "cancelled"):
        job = jobs.find_job(ev["id"])
        JOBS_TOTAL.labels(ev["kind"]).inc()
        JOB_DURATION.labels(ev["kind"]).observe((job["finished_at"] - job["created_at"]).total_seconds())


jobs.listeners.append(_on_job_change)


def sse_message(entries: list[dict], user: dict | None) -> str:
    auth.current_user.set(user)       # 사용자마다 권한이 다르므로 그 사용자 문맥에서 렌더링
    names = list(dict.fromkeys(n for e in entries for n in e["names"]))
    html = f'<hx-partial hx-target="#summary" hx-swap="innerHTML">{part("partials/summary.html", {"sum": store.summary()})}</hx-partial>'
    for name in names:
        vm = store.find(name)
        html += (f'<hx-partial hx-target="#row-{name}" hx-swap="outerHTML">{part("partials/vm_row.html", {"vm": vm})}</hx-partial>'
                 if vm else f'<hx-partial hx-target="#row-{name}" hx-swap="delete"></hx-partial>')
    job_entries = [e for e in entries if e.get("kind") == "job"]
    for jid in dict.fromkeys(e["job"] for e in job_entries):
        job = jobs.find_job(jid)
        if not job:
            continue
        row = part("partials/job_row.html", {"job": job, "p": jobs.progress(job)})
        if any(e["job"] == jid and e["job_kind"] == "created" for e in job_entries):
            html += ('<hx-partial hx-target="#job-empty" hx-swap="delete"></hx-partial>'
                     f'<hx-partial hx-target="#job-table tbody" hx-swap="afterbegin">{row}</hx-partial>')
        else:
            html += f'<hx-partial hx-target="#job-row-{jid}" hx-swap="outerHTML">{row}</hx-partial>'
        html += (f'<hx-partial hx-target="#job-{jid}" hx-swap="outerHTML">'
                 f'{part("partials/job_detail.html", {"job": job, "p": jobs.progress(job), "steps": jobs.STEPS})}</hx-partial>')
    return html


def sse_frame(eid: int, html: str) -> str:
    return f"id: {eid}\n" + "\n".join(f"data: {line}" for line in html.split("\n")) + "\n\n"


@app.get("/events")
async def events(request: Request):
    global _loop
    _loop = asyncio.get_running_loop()
    user = request.state.user
    me = auth.current_client.get()
    last = request.headers.get("last-event-id", "")
    missed = [e for e in _sse_log if last.isdigit() and e["id"] > int(last)]

    async def stream():
        q: asyncio.Queue = asyncio.Queue()
        _sse_clients.add(q)
        try:
            yield sse_frame(missed[-1]["id"], sse_message(missed, user)) if missed \
                else sse_frame(_sse_seq, sse_message([{"names": []}], user))
            while True:
                try:
                    entries = await asyncio.wait_for(q.get(), timeout=15)
                    mine = [e for e in entries if not e["origin"] or e["origin"] != me]   # 자기 변경은 제외
                    if mine:
                        yield sse_frame(entries[-1]["id"], sse_message(mine, user))
                except asyncio.TimeoutError:
                    yield ": ping\n\n"     # 프록시가 유휴 연결을 끊지 않게
        finally:
            _sse_clients.discard(q)

    return StreamingResponse(stream(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@app.get("/lab/sse-clients")
def sse_clients():
    return PlainTextResponse(str(len(_sse_clients)))


# ---- 13편: 차트(아일랜드)가 고른 시점 전후 1분의 활동 ----
@app.get("/vms/{name}/activity/window")
def activity_window(request: Request, name: str, t: str = ""):
    vm = store.find(name)
    if vm is None:
        return not_found_vm(request, name)
    if not t.lstrip("-").isdigit():
        return HTMLResponse('<p class="muted">시점이 올바르지 않습니다.</p>', status_code=422)
    t_ms = int(t)
    point = next((p for p in store.metrics(vm)["points"] if p["t"] == t_ms), None)
    return render(request, "partials/activity_window.html",
                  {"vm": vm, "t": datetime.fromtimestamp(t_ms / 1000), "cpu": point["cpu"] if point else None,
                   "items": store.activity_window(vm, t_ms)})


# ---- 10편: 활동 기록 폴링 + hx-ptag ----
@app.get("/vms/{name}/activity/live")
def activity_live(request: Request, name: str):
    vm = store.find(name)
    if vm is None:
        return not_found_vm(request, name)
    version = store.activity_version(vm)
    if request.headers.get("hx-ptag") == version:
        return Response(status_code=304, headers={"HX-PTag": version})
    resp = render(request, "partials/activity_live.html", {"vm": vm, "activity": store.activity_page(vm), "version": version})
    resp.headers["HX-PTag"] = version
    return resp


# ---- 10편: WebSocket 운영 메모 채널 ----
_ws_clients: set = set()


@app.websocket("/ws/ops")
async def ws_ops(ws: WebSocket):
    session = auth.get_session(ws.cookies.get("sid"))   # http 미들웨어는 WebSocket에 적용되지 않으므로 직접 확인
    if session is None:
        await ws.close(code=1008)
        return
    await ws.accept()
    who = auth.USERS[session["user_id"]]["name"]
    _ws_clients.add(ws)
    print(f"WS     /ws/ops 연결 user={session['user_id']} (접속 {len(_ws_clients)}명)")
    try:
        while True:
            try:
                msg = json.loads(await ws.receive_text())   # hx-ws:send는 {...폼 값, headers}
            except ValueError:
                continue
            text = str(msg.get("message", "")).strip()[:200]
            if not text:
                continue
            print(f"WS     메시지 user={session['user_id']} source={msg.get('headers', {}).get('HX-Source', '-')} \"{text}\"")
            html = part("partials/ops_line.html", {"who": who, "text": text, "at": datetime.now()})   # Jinja2가 이스케이프
            for c in list(_ws_clients):
                await c.send_text(html)
    except WebSocketDisconnect:
        pass
    finally:
        _ws_clients.discard(ws)


# ---- 15편: 패턴 C. 게이트웨이(BFF) — 다른 팀 서비스의 HTML 조각을 포털 셸에 조합 ----
UPSTREAMS = {"billing": {"url": os.environ.get("BILLING_URL", "http://localhost:3101"), "title": "청구"}}
GATEWAY_TOKEN = os.environ.get("GATEWAY_TOKEN", "lab-gateway-secret")
PASS_REQ = ["hx-request", "hx-request-type", "hx-target", "hx-source", "hx-current-url", "hx-boosted", "hx-history-restore-request"]
_http = httpx.AsyncClient(timeout=5.0)


@app.api_route("/billing/{rest:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE"])
async def gateway_billing(request: Request, rest: str):
    up = UPSTREAMS["billing"]
    user = request.state.user
    # 17편: 서명된 짧은 수명의 신원 주장 (평문 사용자 헤더·고정 공유 비밀 대체)
    headers = {"X-Portal-Assertion": assertion.sign_assertion(user["id"], user["role"], request.state.rid, "billing"),
               "X-Forwarded-Prefix": "/billing", "X-Request-ID": request.state.rid, "Accept": "text/html"}
    for h in PASS_REQ:
        if h in request.headers:
            headers[h] = request.headers[h]
    body = None
    if request.method not in ("GET", "HEAD"):
        body = urlencode(dict(await request.form()))
        headers["Content-Type"] = "application/x-www-form-urlencoded"
    url = up["url"] + "/" + rest + (f"?{request.url.query}" if request.url.query else "")
    partial = request.headers.get("hx-request-type") == "partial"
    try:
        r = await _http.request(request.method, url, headers=headers, content=body)
    except httpx.HTTPError as e:
        print(f"GATEWAY billing 실패 {type(e).__name__}: {e}")
        msg = f'<div class="box"><p class="field-error">{up["title"]} 서비스에 연결할 수 없습니다. 잠시 후 다시 시도하세요.</p></div>'
        return HTMLResponse(msg, status_code=502) if partial else render(request, "pages/composed.html", {"title": up["title"], "fragment": msg}, 502)
    hx = {k: v for k, v in r.headers.items() if k.lower().startswith("hx-")}
    if partial:
        return HTMLResponse(r.text, status_code=r.status_code, headers=hx)
    resp = render(request, "pages/composed.html", {"title": up["title"], "fragment": r.text}, r.status_code)
    resp.headers.update(hx)
    return resp


# ---- 16편: 패턴 D. 점진적 대체 (스트랭글러 피그) ----
LEGACY = os.environ.get("LEGACY_URL", "http://localhost:3102")


async def legacy_fetch(request: Request, method: str, path: str, *, content=None, ctype=None):
    user = request.state.user
    headers = {"X-Portal-Assertion": assertion.sign_assertion(user["id"], user["role"], request.state.rid, "legacy-crm"),
               "X-Request-ID": request.state.rid}
    if ctype:
        headers["Content-Type"] = ctype
    return await _http.request(method, LEGACY + path, headers=headers, content=content)   # httpx는 기본으로 리다이렉트를 따라가지 않음


async def legacy_json(request: Request, path: str):
    r = await legacy_fetch(request, "GET", path)
    if r.status_code != 200:
        raise LookupError(r.status_code)
    return r.json()


def ff_override(request: Request, resp_cookies: list) -> str | None:
    q = request.query_params.get("ff", "")
    if request.state.user["role"] == "operator" and q in ("legacy", "new", "auto"):
        resp_cookies.append(q)
        return None if q == "auto" else q
    return request.cookies.get("ff")


def apply_ff_cookie(resp, cookies: list):
    for q in cookies:
        if q == "auto":
            resp.delete_cookie("ff", path="/")
        else:
            resp.set_cookie("ff", q, path="/", samesite="lax")
    return resp


async def customer_view(request: Request, cid: int):
    c = await legacy_json(request, f"/api/customers/{cid}")
    vms = [v for v in store.search("", "") if v["customer"] == c["name"]]
    return c, vms


async def pass_legacy(request: Request, key: str, reason: str, cookies: list):
    r = await legacy_fetch(request, "GET", request.url.path)
    flags.count(key, "legacy"); FLAG_SERVED.labels(key, "legacy").inc()
    resp = HTMLResponse(r.text, status_code=r.status_code, headers={"X-Served-By": "legacy", "X-Flag-Reason": reason})
    return apply_ff_cookie(resp, cookies)


@app.get("/customers")
async def customers_list(request: Request):
    cookies: list = []
    d = flags.decide("customers.list", request.state.user, ff_override(request, cookies))
    if d["impl"] == "legacy":
        return await pass_legacy(request, "customers.list", d["reason"], cookies)
    lst = await legacy_json(request, "/api/customers")
    vms = store.search("", "")
    counts = {c["name"]: sum(1 for v in vms if v["customer"] == c["name"]) for c in lst}
    flags.count("customers.list", "new"); FLAG_SERVED.labels("customers.list", "new").inc()
    resp = render(request, "pages/customers.html", {"title": "고객사", "list": lst, "counts": counts})
    resp.headers.update({"X-Served-By": "new", "X-Flag-Reason": d["reason"]})
    return apply_ff_cookie(resp, cookies)


@app.get("/customers/{cid}")
async def customer_detail(request: Request, cid: int):
    cookies: list = []
    d = flags.decide("customers.detail", request.state.user, ff_override(request, cookies))
    if d["impl"] == "legacy":
        resp = await pass_legacy(request, "customers.detail", d["reason"], cookies)
        if d["shadow"]:   # 그림자 비교: 응답을 보낸 뒤에 새 구현의 값을 계산해 비교
            rid = request.state.rid[:8]

            async def compare():
                try:
                    c, vms = await customer_view(request, cid)
                    diff = None if c["vmCount"] == len(vms) else f"VM 수: 레거시 {c['vmCount']} / 새 구현 {len(vms)}"
                    flags.record_shadow({"key": "customers.detail", "id": cid, "name": c["name"], "ok": not diff, "diff": diff, "rid": rid})
                    SHADOW_COMPARE.labels("customers.detail", "mismatch" if diff else "match").inc()
                except Exception as e:  # noqa: BLE001
                    flags.record_shadow({"key": "customers.detail", "id": cid, "ok": False, "diff": f"새 구현 오류: {e}", "rid": rid})
                    SHADOW_COMPARE.labels("customers.detail", "error").inc()
            asyncio.create_task(compare())
        return resp
    try:
        c, vms = await customer_view(request, cid)
    except LookupError:
        return render(request, "partials/error.html", {"message": "고객사를 찾을 수 없습니다."}, 404)
    flags.count("customers.detail", "new"); FLAG_SERVED.labels("customers.detail", "new").inc()
    resp = render(request, "pages/customer.html", {"title": c["name"], "c": c, "vms": vms})
    resp.headers.update({"X-Served-By": "new", "X-Flag-Reason": d["reason"]})
    return apply_ff_cookie(resp, cookies)


@app.post("/customers/{cid}/memo")
async def customer_memo_legacy(request: Request, cid: int):
    form = dict(await request.form())
    r = await legacy_fetch(request, "POST", request.url.path, content=urlencode(form), ctype="application/x-www-form-urlencoded")
    headers = {"X-Served-By": "legacy"}
    if "location" in r.headers:
        headers["Location"] = r.headers["location"]
    return Response(r.content, status_code=r.status_code, headers=headers)


@app.patch("/customers/{cid}/memo")
async def customer_memo_new(request: Request, cid: int):
    form = dict(await request.form())
    r = await legacy_fetch(request, "PATCH", f"/api/customers/{cid}", content=json.dumps({"memo": form.get("memo", "")}), ctype="application/json")
    c = r.json()
    return HTMLResponse(part("partials/customer_memo.html", {"c": c}) + toast("메모를 저장했습니다. (레거시 화면에도 같은 값)"), headers={"X-Served-By": "new"})


@app.get("/lab/flags")
def flags_page(request: Request):
    return render(request, "pages/flags.html", {"title": "기능 플래그", "list": flags.list_flags(), "shadow": flags.SHADOW})


@app.put("/lab/flags/{key}")
async def flags_set(request: Request, key: str):
    form = dict(await request.form())
    if not flags.set_flag(key, form.get("mode", ""), form.get("percent", 0)):
        return HTMLResponse('<p class="field-error">잘못된 값</p>', status_code=422)
    print(f"FLAG   {key} → mode={form.get('mode')} percent={form.get('percent', 0)} by={request.state.user['id']}")
    return HTMLResponse(part("partials/flags_table.html", {"list": flags.list_flags(), "shadow": flags.SHADOW}))


# ---- 17편: 엄격한 CSP + hx-csp 데모 ----
def strict_csp(nonce: str) -> str:
    return "; ".join(["default-src 'self'", f"script-src 'self' 'nonce-{nonce}'", "style-src 'self' 'unsafe-inline'",
                      "connect-src 'self'", "object-src 'none'", "base-uri 'self'", "frame-ancestors 'none'"])


@app.get("/lab/csp")
def csp_demo(request: Request, ext: str = "on"):
    n = request.state.nonce
    html = templates.get_template("pages/csp_demo.html").render({"nonce": n, "ext": ext != "off", "asset": asset})
    return HTMLResponse(html, headers={"Content-Security-Policy": strict_csp(n)})


@app.get("/lab/csp/echo")
def csp_echo(request: Request):
    n = request.state.nonce
    return HTMLResponse(f'<p>서버 조각 {datetime.now().strftime("%H:%M:%S")}</p><button id="again" hx-get="/lab/csp/echo" hx-target="#out" hx-nonce="{n}">다시 (서버가 찍은 nonce)</button>',
                        headers={"Content-Security-Policy": strict_csp(n)})


@app.get("/lab/csp/inject")
def csp_inject(request: Request):
    return HTMLResponse('<p>주입된 조각</p><button id="evil" hx-get="/lab/csp/pwn" hx-target="#out">주입된 hx-get</button>'
                        '<button id="evil2" hx-on:click="document.title=\'pwned\'">주입된 hx-on</button>',
                        headers={"Content-Security-Policy": strict_csp(request.state.nonce)})


@app.get("/lab/csp/stolen")
def csp_stolen(request: Request, n: str = ""):
    n = re.sub(r"[^A-Za-z0-9+/=_-]", "", n)
    return HTMLResponse(f'<button id="stolen" hx-get="/lab/csp/pwn" hx-target="#out" hx-nonce="{n}">훔친 nonce</button>',
                        headers={"Content-Security-Policy": strict_csp(request.state.nonce)})


@app.get("/lab/csp/pwn")
def csp_pwn():
    return HTMLResponse('<p class="field-error">이 요청이 나가면 안 된다</p>')


# ---- 14편: 패턴 B. React SPA(운영 콘솔)와 그 안에 끼워 넣을 서버 조각 ----
@app.get("/console/fragments/live-summary")
def console_live_summary(request: Request):
    return render(request, "partials/console_live_summary.html", {"sum": store.summary()})


@app.get("/console")
@app.get("/console/{rest:path}")
def console_spa(request: Request, rest: str = ""):
    """SPA 대체 라우트. ?hxhistory=on이면 htmx history를 켜서 7절의 충돌을 재현한다"""
    # 이 라우트가 정적 파일 마운트보다 먼저 걸리므로, 빌드 산출물(/console/assets/...)은 파일로 돌려준다
    built = (PUBLIC / "console" / rest).resolve()        # 20편: 지역 변수 이름이 asset()을 가리던 것을 바꿈
    if rest and built.is_file() and built.is_relative_to((PUBLIC / "console").resolve()):
        return FileResponse(built, headers={"Cache-Control": "public, max-age=31536000, immutable"})   # 18편: 해시 파일명
    html = (PUBLIC / "console" / "index.html").read_text(encoding="utf-8")
    html = html.replace('<script type="importmap">', f'<script type="importmap" nonce="{request.state.nonce}">')   # 17편
    # 20편: 콘솔 index.html의 고정 경로를 매니페스트의 해시 URL로
    html = re.sub(r'(["\'])/(vendor/htmx/[\w./-]+|js/[\w./-]+|css/[\w.-]+|shared/[\w.-]+)\1', lambda m: m.group(1) + asset(m.group(2)) + m.group(1), html)
    html = html.replace("/islands/react/react-islands.js", asset("islands/react.js")).replace("/islands/vue/vue-islands.js", asset("islands/vue.js"))
    if request.query_params.get("hxhistory") == "on":
        html = html.replace('"history": false', '"history": true')
    return HTMLResponse(html)


# ---- 20편: 상태 확인과 실사용자 측정 ----
STARTED_AT = datetime.now().isoformat()


@app.get("/healthz")
def healthz():
    return PlainTextResponse("ok")


@app.get("/readyz")
def readyz():
    ready = not USE_DIST or bool(MANIFEST)
    return JSONResponse({"ready": ready, "startedAt": STARTED_AT, "assets": len(MANIFEST)}, status_code=200 if ready else 503)


@app.post("/rum")
async def rum(request: Request):
    try:
        items = json.loads((await request.body())[:16384] or b"[]")
    except ValueError:
        items = []
    for m in items[:20] if isinstance(items, list) else []:
        page = m.get("page") if isinstance(m.get("page"), str) and re.fullmatch(r"/[\w/:.-]{0,60}", m.get("page")) else "other"
        rating = m.get("rating") if m.get("rating") in ("good", "needs-improvement", "poor") else "unknown"
        try:
            v = float(m.get("value"))
        except (TypeError, ValueError):
            continue
        if v < 0:
            continue
        if m.get("name") == "CLS":
            WEB_VITALS_CLS.labels(page, rating).observe(v)
        elif m.get("name") in ("LCP", "INP", "FCP", "TTFB"):
            WEB_VITALS.labels(m["name"], page, rating).observe(v / 1000)
    return Response(status_code=204)


# ---- 21편: 종합 실습 — 패치 작업 ----
def _toast_retarget(msg: str, status: int = 200) -> HTMLResponse:
    return HTMLResponse(part("partials/toast_item.html", {"msg": msg, "kind": "warn"}), status_code=status,
                        headers={"HX-Retarget": "#toasts", "HX-Reswap": "beforeend"})


@app.get("/jobs")
def jobs_page(request: Request):
    lst = [{"job": j, "p": jobs.progress(j)} for j in jobs.list_jobs()]
    if (htmx_info(request) or {}).get("type") == "partial":
        return render(request, "partials/job_table.html", {"list": lst})
    return render(request, "pages/jobs.html", {"title": "패치 작업", "list": lst})


@app.post("/jobs")
async def jobs_create(request: Request):
    form = await request.form()
    r = jobs.create_job(form.getlist("sel"), request.state.user)
    if "error" in r:
        return _toast_retarget(r["error"], r["status"])
    return Response(status_code=201, headers={"HX-Location": json.dumps({"path": f"/jobs/{r['job']['id']}", "target": "body"})})


@app.get("/jobs/{job_id}")
def job_page(request: Request, job_id: str):
    job = jobs.find_job(job_id)
    if not job:
        return render(request, "partials/error.html", {"message": "작업을 찾을 수 없습니다."}, 404)
    data = {"job": job, "p": jobs.progress(job), "steps": jobs.STEPS}
    if (htmx_info(request) or {}).get("type") == "partial":
        return render(request, "partials/job_detail.html", data)
    return render(request, "pages/job.html", {"title": f"패치 작업 {job_id}", **data})


@app.post("/jobs/{job_id}/cancel")
def job_cancel(request: Request, job_id: str):
    r = jobs.cancel_job(job_id)
    if "error" in r:
        return _toast_retarget(r["error"], r["status"])
    return _toast_retarget(f"{job_id} 작업을 취소했습니다.")      # 작업 상세는 SSE가 갱신


# ---- 6편: 로그인·세션 ----
def _origin(request: Request) -> str:
    return f"{request.url.scheme}://{request.url.netloc}"


@app.get("/login")
def login_page(request: Request, next: str = ""):
    return render(request, "pages/login.html", {"title": "로그인", "users": auth.USERS,
                                                "next": auth.safe_next(next, _origin(request))})


@app.post("/login")
async def login(request: Request):
    form = dict(await request.form())
    user_id = form.get("user", "")
    if user_id not in auth.USERS:
        return render(request, "pages/login.html", {"title": "로그인", "users": auth.USERS, "next": "/vms",
                                                    "error": "사용자를 고르세요."}, 422)
    resp = RedirectResponse(auth.safe_next(form.get("next"), _origin(request)), status_code=303)
    resp.set_cookie("sid", auth.create_session(user_id), httponly=True, samesite="lax", path="/",
                    secure=os.environ.get("APP_ENV") == "production")   # 20편: 운영(https)에서는 Secure
    return resp


@app.get("/logout")
def logout(request: Request):
    auth.destroy_session(request.cookies.get("sid"))
    resp = RedirectResponse("/login", status_code=302)
    resp.delete_cookie("sid", path="/", secure=os.environ.get("APP_ENV") == "production")
    return resp


@app.post("/session/role")
def session_role(request: Request):
    user = request.state.user
    s = auth.get_session(user["sid"])
    s["role"] = "viewer" if s["role"] == "operator" else "operator"
    user["role"] = s["role"]
    return HTMLResponse(part("partials/whoami.html", {"user": user, "note": "역할만 바뀌었다. 화면은 그대로"}))


@app.post("/session/expire")
def session_expire(request: Request):
    auth.destroy_session(request.state.user["sid"])
    return HTMLResponse(part("partials/whoami.html", {"user": request.state.user, "expired": True}))


# ---- 6편: 장애 주입 ----
class DroppedResponse(Response):
    """Content-Length를 실제 본문보다 크게 선언하고 끝내 버리는 응답. 서버가 연결을 닫아 클라이언트는 본문을 끝까지 못 받는다"""
    async def __call__(self, scope, receive, send):
        await send({"type": "http.response.start", "status": 200,
                    "headers": [(b"content-type", b"text/html"), (b"content-length", b"1000")]})
        await send({"type": "http.response.body", "body": b"<p>", "more_body": False})

@app.get("/lab/fault")
async def lab_fault(kind: str = ""):
    if kind == "500":
        raise RuntimeError("일부러 낸 서버 오류")
    if kind == "503":
        return HTMLResponse("<p>점검 중입니다 (503)</p>", status_code=503, headers={"Retry-After": "30"})
    if kind == "slow":
        await asyncio.sleep(5)
        return HTMLResponse("<p>5초 뒤 도착한 응답</p>")
    if kind == "302":
        return RedirectResponse("/login", status_code=302)
    if kind == "drop":
        return DroppedResponse()   # 응답 도중 연결을 끊는다 → 브라우저 fetch가 네트워크 오류로 실패
    return HTMLResponse("<p>정상 응답</p>")


# ---- 3편: 스왑 실험실 ----
_piece_no = 0


@app.get("/lab/swap")
def swap_lab(request: Request):
    return render(request, "pages/swap_lab.html", {"title": "스왑 실험실"})


@app.get("/lab/swap/stage")
def swap_stage():
    global _piece_no
    _piece_no = 0
    return HTMLResponse(part("partials/swap_stage.html", {}))


@app.get("/lab/swap/piece")
def swap_piece(style: str = "innerHTML"):
    global _piece_no
    _piece_no += 1
    return HTMLResponse(part("partials/swap_piece.html",
                             {"no": _piece_no, "style": style, "keep_id": style in ("outerHTML", "outerMorph")}))


@app.get("/lab")
def lab(request: Request):
    return render(request, "pages/lab.html", {"title": "랩 점검"})


_panel_no = 0


@app.get("/lab/panel")
def lab_panel(request: Request):
    """5편: 랩 점검 패널만 다시 그리기 (hx-preserve 실험)"""
    global _panel_no
    _panel_no += 1
    return render(request, "partials/lab_panel.html", {"no": _panel_no})


@app.get("/legacy/notice")
def legacy_notice(request: Request):
    """5편: htmx를 모르는 레거시 페이지. 포털은 hx-select로 일부만 가져간다"""
    return render(request, "pages/legacy_notice.html", {})


@app.get("/lab/echo")
def lab_echo(request: Request):
    from datetime import datetime
    headers = sorted((k, v) for k, v in request.headers.items() if k.startswith("hx-") or k == "accept")
    return render(request, "partials/echo.html", {"headers": headers, "at": datetime.now().strftime("%H:%M:%S")})


@app.get("/api/vms/{name}/metrics")
def api_metrics(name: str):
    """11편: 아일랜드용 데이터 API (화면용 HTML 엔드포인트와 경로를 나눈다)"""
    vm = store.find(name)
    if vm is None:
        return JSONResponse({"error": "not_found", "vm": name}, status_code=404)
    return JSONResponse(store.metrics(vm), headers={"Cache-Control": "no-store"})


@app.get("/api/vms")
def api_vms(q: str = "", status: str = ""):
    # 활동 기록의 datetime까지 JSON으로 바꾸려면 jsonable_encoder가 필요 (3편 코드의 직렬화 오류 수정)
    return JSONResponse(jsonable_encoder(store.search(q, status)))


app.mount("/", StaticFiles(directory=PUBLIC), name="public")   # 라우트에 걸리지 않은 경로는 정적 파일로


@app.exception_handler(404)
async def not_found(request: Request, exc):
    message = f"{request.method} {request.url.path} 경로가 없습니다."
    if htmx_info(request):
        return render(request, "partials/error.html", {"message": message}, 404)
    return render(request, "pages/not_found.html", {"title": "페이지 없음", "message": message}, 404)


@app.exception_handler(500)
@app.exception_handler(Exception)
async def server_error(request: Request, exc: Exception):
    return render(request, "partials/error.html", {"message": "서버 오류가 발생했습니다."}, 500)


# 18편: 응답 압축. Starlette의 GZipMiddleware는 text/event-stream을 기본으로 제외한다(소스 DEFAULT_EXCLUDED_CONTENT_TYPES).
# add_middleware는 나중에 추가한 것이 바깥을 감싸므로, 맨 끝에서 추가해 모든 응답(정적 파일 포함)에 적용한다. 브로틀리는 없다
app.add_middleware(GZipMiddleware, minimum_size=1024)
