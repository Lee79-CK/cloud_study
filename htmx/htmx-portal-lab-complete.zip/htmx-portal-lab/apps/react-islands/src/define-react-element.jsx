import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';

// 12편: React 컴포넌트를 사용자 정의 요소(웹 컴포넌트)로 감싸는 작은 도우미.
// 마운트·언마운트·속성 변화의 시점을 등록부(11편) 대신 브라우저가 알려 준다.
export const stats = (window.__ceStats ??= { mounts: 0, unmounts: 0, renders: 0 });

export function defineReactElement(tag, render, { attributes = [], shadow = true, css = '' } = {}) {
  if (customElements.get(tag)) return;
  const sheet = css ? new CSSStyleSheet() : null;
  sheet?.replaceSync(css);

  class ReactElement extends HTMLElement {
    static observedAttributes = attributes;
    #root = null;
    #mountPoint = null;

    connectedCallback() {
      if (this.#root) return;                       // 이동 중 다시 연결된 경우: 이미 마운트되어 있음
      // 섀도 DOM: 바깥의 선택자·스타일·htmx 대상 지정이 안쪽에 닿지 않는다
      const host = shadow ? (this.shadowRoot ?? this.attachShadow({ mode: 'open' })) : this;
      if (shadow && sheet) host.adoptedStyleSheets = [sheet];
      this.#mountPoint = document.createElement('div');
      this.#mountPoint.part = 'root';
      host.append(this.#mountPoint);
      this.#root = createRoot(this.#mountPoint);
      stats.mounts++;
      this.#render();
    }

    // 요소가 문서에서 떨어지면 정리. 단, 옮겨지는 중(떼었다 바로 붙임)일 수 있으므로 한 틱 뒤에 확인한다
    disconnectedCallback() {
      queueMicrotask(() => {
        if (this.isConnected || !this.#root) return;
        this.#root.unmount();
        this.#root = null;
        this.#mountPoint.remove();
        this.#mountPoint = null;
        stats.unmounts++;
      });
    }

    // Element.moveBefore()로 옮겨질 때 브라우저가 disconnected/connected 대신 이것만 부른다 (상태 유지)
    connectedMoveCallback() {}

    attributeChangedCallback(name, oldValue, newValue) {
      if (oldValue !== newValue && this.#root) this.#render();   // 모핑이 속성만 바꿔도 다시 그린다
    }

    #render() {
      stats.renders++;
      this.#root.render(<StrictMode>{render(this)}</StrictMode>);
    }
  }
  customElements.define(tag, ReactElement);
}
