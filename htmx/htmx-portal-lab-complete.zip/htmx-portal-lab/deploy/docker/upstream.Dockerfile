# syntax=docker/dockerfile:1
# 20편: 청구 서비스·레거시 CRM (의존성 없음). --build-arg SERVICE=billing-service 또는 legacy-crm
FROM node:26-slim
ARG SERVICE
ENV NODE_ENV=production
WORKDIR /app
COPY --chown=node:node apps/${SERVICE}/server.js ./server.js
# 숫자 UID로 지정: 파드의 runAsNonRoot는 이름(node)만 있으면 루트가 아님을 확인하지 못해 컨테이너를 거부한다
USER 1000
CMD ["node", "server.js"]
