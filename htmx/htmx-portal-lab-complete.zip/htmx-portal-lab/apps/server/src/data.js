// 실습용 인메모리 저장소. 실제 프로젝트에서는 DB나 클라우드 API 호출로 바뀌는 자리다.
import { EventEmitter } from 'node:events';

// 10편: 변경 알림 버스. SSE 엔드포인트가 구독해 접속한 모든 브라우저에 밀어 준다.
// 실제 서비스에서는 Redis Pub/Sub·Kafka 같은 메시지 브로커가 이 자리를 맡는다(서버가 여러 대일 때)
export const bus = new EventEmitter();
bus.setMaxListeners(0);
const changed = (names, kind = 'vm') => bus.emit('change', { names: [].concat(names), kind });
const SEED = [
  ['web-01', '한빛물산', 'running'], ['web-02', '한빛물산', 'running'], ['db-01', '한빛물산', 'stopped'],
  ['api-01', '누리로지스', 'running'], ['api-02', '누리로지스', 'running'], ['db-02', '누리로지스', 'stopped'],
  ['batch-01', '새솔제약', 'running'], ['web-03', '새솔제약', 'running'], ['cache-01', '새솔제약', 'running'],
  ['mq-01', '다온핀테크', 'running'], ['db-03', '다온핀테크', 'running'], ['gpu-01', '다온핀테크', 'stopped'],
  // 4편: 무한 스크롤 실습을 위해 앱 서버 36대 추가 (5대 중 1대는 중지 상태)
  ...Array.from({ length: 36 }, (_, i) => [
    `app-${String(i + 1).padStart(2, '0')}`,
    ['한빛물산', '누리로지스', '새솔제약', '다온핀테크'][i % 4],
    i % 5 === 4 ? 'stopped' : 'running',
  ]),
];
const SPEC = { web: '2 vCPU · 4 GiB', api: '4 vCPU · 8 GiB', db: '8 vCPU · 32 GiB', batch: '4 vCPU · 16 GiB',
               cache: '2 vCPU · 8 GiB', mq: '2 vCPU · 4 GiB', gpu: '16 vCPU · 64 GiB · L4 x1', app: '2 vCPU · 4 GiB' };
const TRANSITION_MS = 1500;
export const TAG_RULE = /^[0-9a-z가-힣-]{1,20}$/;   // 태그 형식 규칙 (서버가 최종 판단)
export const MEMO_MAX = 500;

let vms = [];
let clock = 0;   // 활동 기록 정렬용 일련번호

function log(vm, text) {
  vm.activity.unshift({ seq: ++clock, at: new Date(), text });
}

export function reset() {
  clock = 0;
  vms = SEED.map(([name, customer, status]) => {
    const vm = { name, customer, status, busyUntil: 0, spec: SPEC[name.split('-')[0]],
                 memo: '', tags: [], monitoring: status === 'running', activity: [],
                 alerts: { cpu: 80, mem: 85, channel: 'email', contact: '' } };
    log(vm, 'VM 등록');
    if (name.startsWith('db')) { vm.tags.push('db', '백업대상'); log(vm, '태그 추가: db, 백업대상'); }
    if (name === 'web-01') {
      vm.memo = '고객사 대표 홈페이지. 배포 전 담당자 확인 필요.';
      for (let i = 1; i <= 7; i++) log(vm, `점검 기록 #${i}`);
    }
    return vm;
  });
  changed([], 'reset');
}
reset();

function settle(vm) {
  if ((vm.status === 'restarting' || vm.status === 'starting') && Date.now() >= vm.busyUntil) {
    vm.status = 'running';
    log(vm, '상태 변경: 실행 중');
  }
  return vm;
}

const isBusy = v => v.status === 'restarting' || v.status === 'starting';
// 4편: 상태 필터 추가 ('' | running | stopped | busy)
export function search(q = '', status = '') {
  const k = q.trim().toLowerCase();
  return vms.map(settle).filter(v =>
    (!k || v.name.includes(k) || v.customer.toLowerCase().includes(k)) &&
    (!status || (status === 'busy' ? isBusy(v) : v.status === status)));
}

// 4편: 페이지 단위 조회 (무한 스크롤)
export const PAGE_SIZE = 15;
export function paginate(list, page = 1) {
  const p = Math.max(1, Number(page) || 1);
  const items = list.slice((p - 1) * PAGE_SIZE, p * PAGE_SIZE);
  return { items, page: p, nextPage: p * PAGE_SIZE < list.length ? p + 1 : null, total: list.length };
}

// 4편: 상단 요약 카드 (폴링 대상)
export function summary() {
  const all = vms.map(settle);
  return {
    total: all.length,
    running: all.filter(v => v.status === 'running').length,
    stopped: all.filter(v => v.status === 'stopped').length,
    busy: all.filter(isBusy).length,
    at: new Date(),
  };
}

export function find(name) {
  const vm = vms.find(v => v.name === name);
  return vm ? settle(vm) : null;
}

// 상태 전이 규칙은 서버 한 곳에만 둔다: 실행 중만 재시작, 중지됨만 시작 가능
export function transition(name, action) {
  const vm = find(name);
  if (!vm) return { error: 404 };
  const allowed = (action === 'restart' && vm.status === 'running') || (action === 'start' && vm.status === 'stopped');
  if (!allowed) return { error: 409, vm };
  vm.status = action === 'restart' ? 'restarting' : 'starting';
  vm.busyUntil = Date.now() + TRANSITION_MS;
  log(vm, action === 'restart' ? '재시작 요청' : '시작 요청');
  changed(name);
  // 전환이 끝나는 시점에 다시 알린다 (4편까지는 행이 스스로 폴링해 알아냈다)
  setTimeout(() => { if (vms.includes(vm)) { settle(vm); changed(name, 'settled'); } }, TRANSITION_MS + 50);
  return { vm };
}

export function remove(name) {
  const before = vms.length;
  vms = vms.filter(v => v.name !== name);
  if (vms.length < before) changed(name, 'removed');
  return vms.length < before;
}

// ---- 3편에서 추가: 메모(PUT), 태그(POST/DELETE), 모니터링(PATCH), 활동 기록(GET 페이지 단위) ----
export function setMemo(vm, memo) {
  const text = String(memo ?? '').trim();
  if (text.length > MEMO_MAX) return { error: `메모는 ${MEMO_MAX}자 이하로 입력하세요. (현재 ${text.length}자)` };
  vm.memo = text;
  log(vm, text ? '메모 수정' : '메모 삭제');
  return { vm };
}

export function addTag(vm, raw) {
  const tag = String(raw ?? '').trim().toLowerCase();
  if (!TAG_RULE.test(tag)) return { error: '태그는 1~20자의 한글·영소문자·숫자·하이픈만 쓸 수 있습니다.' };
  if (vm.tags.includes(tag)) return { error: `이미 있는 태그입니다: ${tag}` };
  if (vm.tags.length >= 8) return { error: '태그는 VM당 최대 8개입니다.' };
  vm.tags.push(tag);
  log(vm, `태그 추가: ${tag}`);
  return { vm };
}

export function removeTag(vm, tag) {
  if (!vm.tags.includes(tag)) return { error: `없는 태그입니다: ${tag}` };
  vm.tags = vm.tags.filter(t => t !== tag);
  log(vm, `태그 삭제: ${tag}`);
  return { vm };
}

export function setMonitoring(vm, on) {
  vm.monitoring = on;
  log(vm, on ? '모니터링 켜짐' : '모니터링 꺼짐');
  return { vm };
}

// ---- 5편: 알림 임계값 설정 (검증 규칙은 서버 한 곳에) ----
export const CHANNELS = { email: '이메일', slack: 'Slack', sms: '문자' };
export function checkAlerts(input) {
  const errors = {};
  const cpu = Number(input.cpu), mem = Number(input.mem);
  const channel = String(input.channel ?? '');
  const contact = String(input.contact ?? '').trim();
  if (!Number.isInteger(cpu) || cpu < 50 || cpu > 99) errors.cpu = 'CPU 임계값은 50~99 사이 정수여야 합니다.';
  if (!Number.isInteger(mem) || mem < 50 || mem > 99) errors.mem = '메모리 임계값은 50~99 사이 정수여야 합니다.';
  if (!(channel in CHANNELS)) errors.channel = '알림 채널을 고르세요.';
  if (channel === 'email' && contact && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(contact)) errors.contact = '이메일 주소 형식이 아닙니다.';
  if (channel === 'slack' && contact && !/^#[0-9a-z가-힣_-]{1,40}$/.test(contact)) errors.contact = 'Slack 채널은 #으로 시작해야 합니다.';
  if (channel === 'sms' && contact && !/^01[0-9]-?\d{3,4}-?\d{4}$/.test(contact)) errors.contact = '휴대폰 번호 형식이 아닙니다.';
  return { values: { cpu: input.cpu ?? '', mem: input.mem ?? '', channel, contact }, errors, ok: Object.keys(errors).length === 0 };
}
export function saveAlerts(vm, input) {
  const r = checkAlerts(input);
  if (r.ok) {
    vm.alerts = { cpu: Number(input.cpu), mem: Number(input.mem), channel: r.values.channel, contact: r.values.contact };
    log(vm, `알림 설정 변경: CPU ${vm.alerts.cpu}% · 메모리 ${vm.alerts.mem}% · ${CHANNELS[vm.alerts.channel]}`);
  }
  return r;
}

// ---- 6편: VM 등록 (검증 규칙은 서버에) ----
export const CUSTOMERS = ['한빛물산', '누리로지스', '새솔제약', '다온핀테크'];
export function createVm(input) {
  const name = String(input.name ?? '').trim().toLowerCase();
  const customer = String(input.customer ?? '');
  const errors = {};
  if (!/^[a-z]+-\d{2}$/.test(name)) errors.name = '이름은 "영소문자-두 자리 숫자" 형식이어야 합니다. (예: web-04)';
  else if (vms.some(v => v.name === name)) errors.name = `이미 있는 VM 이름입니다: ${name}`;
  if (!CUSTOMERS.includes(customer)) errors.customer = '고객사를 고르세요.';
  const values = { name, customer };
  if (Object.keys(errors).length) return { ok: false, values, errors };
  const vm = { name, customer, status: 'stopped', busyUntil: 0, spec: SPEC[name.split('-')[0]] ?? '2 vCPU · 4 GiB',
               memo: '', tags: [], monitoring: false, activity: [], alerts: { cpu: 80, mem: 85, channel: 'email', contact: '' } };
  log(vm, 'VM 등록');
  vms.unshift(vm);
  changed(name, 'created');
  return { ok: true, vm };
}

export const ACTIVITY_PAGE = 3;

// 11편: 아일랜드(React 차트)용 데이터 API. 실제로는 모니터링 시스템(Prometheus 등)에서 읽어 오는 자리.
// 실습에서는 VM 이름과 시각으로 정해지는 의사 난수로 CPU 사용률 30개(10초 간격)를 만든다
function hash(s) { let h = 2166136261; for (const c of s) { h ^= c.codePointAt(0); h = Math.imul(h, 16777619); } return h >>> 0; }
export function metrics(vm, now = Date.now()) {
  const STEP = 10_000, N = 30, base = 20 + (hash(vm.name) % 40);
  const end = Math.floor(now / STEP) * STEP;
  const points = Array.from({ length: N }, (_, i) => {
    const t = end - (N - 1 - i) * STEP;
    const wave = Math.sin((t / STEP + hash(vm.name) % 17) / 3) * 12;
    const noise = (hash(vm.name + t) % 1000) / 1000 * 10;
    const cpu = vm.status === 'stopped' ? 0 : Math.max(1, Math.min(99, Math.round(base + wave + noise)));
    return { t, cpu };
  });
  return { vm: vm.name, status: vm.status, unit: '%', step: STEP / 1000, points };
}
// 10편: 활동 기록의 버전 (hx-ptag 값). 가장 최근 기록의 일련번호로 충분하다
export const activityVersion = vm => `a${vm.activity[0]?.seq ?? 0}`;
// 13편: 차트에서 고른 시점 t 전후 span(ms)의 활동 (아일랜드 → htmx 영역 요청에 답함)
export function activityWindow(vm, t, span = 60_000) {
  return vm.activity.filter(a => Math.abs(a.at.getTime() - t) <= span);
}

export function activityPage(vm, before = Infinity) {
  const items = vm.activity.filter(a => a.seq < before).slice(0, ACTIVITY_PAGE);
  const last = items.at(-1);
  const hasMore = !!last && vm.activity.some(a => a.seq < last.seq);
  return { items, nextBefore: hasMore ? last.seq : null };
}

export const STATUS_LABEL = { running: '실행 중', stopped: '중지됨', restarting: '재시작 중', starting: '시작 중' };
