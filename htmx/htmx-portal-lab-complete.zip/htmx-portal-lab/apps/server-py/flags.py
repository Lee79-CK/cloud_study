"""16편: 기능 플래그 (Express 쪽 flags.js와 같은 규칙)"""
from datetime import datetime

MODES = ["legacy", "shadow", "percent", "new"]
FLAGS = {
    "customers.list": {"mode": "legacy", "percent": 0, "label": "고객사 목록"},
    "customers.detail": {"mode": "legacy", "percent": 0, "label": "고객사 상세"},
}
STATS = {k: {"legacy": 0, "new": 0} for k in FLAGS}
SHADOW: list[dict] = []


def _hash(s: str) -> int:
    h = 2166136261
    for c in s:
        h ^= ord(c)
        h = (h * 16777619) & 0xFFFFFFFF
    return h


def list_flags() -> list[dict]:
    return [{"key": k, **f, "stats": STATS[k]} for k, f in FLAGS.items()]


def set_flag(key: str, mode: str, percent) -> bool:
    f = FLAGS.get(key)
    if not f or mode not in MODES:
        return False
    f["mode"] = mode
    try:
        f["percent"] = max(0, min(100, int(percent or 0)))
    except ValueError:
        f["percent"] = 0
    return True


def reset_flags() -> None:
    for f in FLAGS.values():
        f.update(mode="legacy", percent=0)
    for s in STATS.values():
        s.update(legacy=0, new=0)
    SHADOW.clear()


def decide(key: str, user: dict, override: str | None) -> dict:
    f = FLAGS[key]
    if override in ("legacy", "new"):
        return {"impl": override, "shadow": False, "reason": "override"}
    if f["mode"] == "new":
        return {"impl": "new", "shadow": False, "reason": "mode"}
    if f["mode"] == "shadow":
        return {"impl": "legacy", "shadow": True, "reason": "shadow"}
    if f["mode"] == "percent":
        bucket = _hash(f"{user['id']}:{key}") % 100
        return {"impl": "new" if bucket < f["percent"] else "legacy", "shadow": False, "reason": f"percent bucket={bucket}"}
    return {"impl": "legacy", "shadow": False, "reason": "mode"}


def count(key: str, impl: str) -> None:
    STATS[key][impl] += 1


def record_shadow(entry: dict) -> None:
    SHADOW.insert(0, {"at": datetime.now(), **entry})
    del SHADOW[50:]
