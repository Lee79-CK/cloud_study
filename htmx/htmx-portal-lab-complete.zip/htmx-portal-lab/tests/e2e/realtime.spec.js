// 실시간 E2E: 두 사용자 (10편 SSE, WebSocket)
import { test, expect } from '@playwright/test';
import { login, reset } from './helpers.js';

test('운영자의 재시작이 조회 전용 사용자 화면에 SSE로', async ({ browser, baseURL }) => {
  const a = await (await browser.newContext({ baseURL })).newPage();
  const v = await (await browser.newContext({ baseURL })).newPage();
  await login(a, 'kim'); await reset(a); await login(v, 'lee');
  await a.goto('/vms'); await v.goto('/vms');
  await expect(v.locator('#live')).toHaveAttribute('data-state', 'on');
  await a.click('#row-api-01 button:has-text("재시작")');
  await expect(v.locator('#row-api-01')).toContainText('재시작 중');
  await expect(v.locator('#row-api-01')).toContainText('보기 전용', { timeout: 5000 });
});

test('운영 메모 WebSocket 방송과 이스케이프', async ({ browser, baseURL }) => {
  const a = await (await browser.newContext({ baseURL })).newPage();
  const v = await (await browser.newContext({ baseURL })).newPage();
  await login(a, 'kim'); await login(v, 'lee');
  await a.goto('/lab'); await v.goto('/lab');
  await a.waitForTimeout(500);
  await a.fill('.ops input[name=message]', '<i>e2e</i>');
  await a.press('.ops input[name=message]', 'Enter');
  await expect(v.locator('#ops-log')).toContainText('<i>e2e</i>');
  await expect(v.locator('#ops-log i')).toHaveCount(0);
});
