// 자동 생성: node gen-entries.mjs (react/jsx-runtime)
import M from 'react/jsx-runtime';
export default M;
export const { Fragment, jsx, jsxs } = M;
