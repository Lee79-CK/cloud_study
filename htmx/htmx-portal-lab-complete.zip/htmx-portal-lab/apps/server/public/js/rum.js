// 20편: 실사용자 측정(RUM). web-vitals 6으로 LCP·CLS·INP·FCP·TTFB를 재서 페이지를 떠날 때 한 번에 보낸다.
// 서버는 /rum에서 받아 Prometheus 히스토그램으로 집계한다. 부스트 이동은 새 페이지 로드가 아니므로
// LCP·FCP·TTFB는 처음 로드한 페이지 기준이고, CLS·INP는 부스트로 옮겨 다닌 세션 전체에 누적된다.
import { onCLS, onFCP, onINP, onLCP, onTTFB } from 'web-vitals';

const page = document.body.dataset.page || location.pathname;      // 서버가 넣은 라우트 템플릿 (예: /vms/:name)
const queue = [];
const add = (m) => queue.push({ name: m.name, value: m.value, rating: m.rating, page });
for (const on of [onCLS, onFCP, onINP, onLCP, onTTFB]) on(add);

function flush() {
  if (!queue.length) return;
  navigator.sendBeacon('/rum', new Blob([JSON.stringify(queue.splice(0))], { type: 'application/json' }));
}
addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') flush(); });
addEventListener('pagehide', flush);
