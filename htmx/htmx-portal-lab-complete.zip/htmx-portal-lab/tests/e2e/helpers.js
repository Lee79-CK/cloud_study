// 공용 도우미: 로그인과 상태 초기화
export async function login(page, user = 'kim') {
  await page.goto('/login');
  await page.check(`input[value=${user}]`);
  await page.click('button[type=submit]');
  await page.waitForURL(/\/vms/);
}
export async function reset(page) {
  await page.request.post('/lab/reset');
}
