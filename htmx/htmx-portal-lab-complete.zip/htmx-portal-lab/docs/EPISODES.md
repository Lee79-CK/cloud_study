# 편별 변경 기록

각 편을 마칠 때 저장소에 추가·변경된 내용을 순서대로 모았다. 1편은 개념 편(코드 없음), 2편에서 이 저장소의 뼈대(Express·FastAPI 서버, React·Vue 아일랜드 워크스페이스)를 만들었다.

## 3편에서 추가된 기능
- VM 상세 패널 (GET /vms/:name — 조각/전체 페이지 겸용)
- 메모 click-to-edit (GET 보기·편집 폼, PUT 저장, 422 검증 오류)
- 태그 추가·삭제 (POST/DELETE, 태그 블록 전체 재렌더링)
- 모니터링 토글 (PATCH, 체크 해제 시 값 없음)
- 활동 기록 더 보기 + 새 활동 hx-partial afterbegin
- 스왑 실험실 (/lab/swap)

## 4편에서 추가된 기능
- VM 36대 추가(총 48대) + 15건 단위 무한 스크롤 (revealed root:.table-scroll)
- 검색어 + 상태 필터 폼 (input changed delay:300ms, change changed, hx-sync this:replace)
- 폼 밖 버튼의 hx-include
- 요약 카드 폴링 (every 5s [document.visibilityState === 'visible'], vmChanged from:document)
- 재시작·시작 버튼 중복 클릭 방지 (hx-disable="this")
- hx-confirm을 <dialog>로 처리 (htmx:confirm 이벤트)
- FastAPI /api/vms의 datetime 직렬화 오류 수정 (jsonable_encoder)

## 5편에서 추가된 기능
- 알림 설정 폼: 입력 중 서버 검증 + outerMorph (입력 중인 칸의 글자·포커스 보존)
- 토스트 알림: hx-swap-oob="beforeend:#toasts" + load delay:4s, hx-swap="delete"로 자동 제거
- 행 삭제 버튼 hx-swap="outerHTML swapEmpty" (OOB만 있는 빈 본문 응답에서도 행 제거)
- 재시작·시작 행 교체에 View Transitions (transition:true)
- 랩 점검 패널 새로고침 + hx-preserve로 React 아일랜드 보존
- 레거시 페이지에서 hx-select로 일부만 가져오기 (ignoreTitle:true)

## 6편에서 추가된 기능
- 데모 로그인(비밀번호 없음): 김운영(운영자) / 이조회(조회 전용). 6편부터 모든 화면은 로그인 후 접근
- 세션 만료 시 htmx 요청은 401 + HX-Redirect(돌아올 주소는 HX-Current-URL, 같은 출처만 허용)
- 조회 전용 계정의 쓰기 요청은 403 + HX-Retarget/HX-Reswap으로 토스트 영역에 경고
- VM 등록: 422 검증 오류 / 201 + HX-Location(JSON: path, target)
- 검색 조건을 HX-Replace-Url로 주소창에 반영
- 장애 주입(/lab): 500, 503, 시간 초과(hx-config timeout), 연결 끊김, 302 나쁜 예 + 전역 오류 토스트

## 7편에서 바뀐 점
- 상단 메뉴 hx-boost:inherited (랩 점검은 hx-boost="false": 아일랜드 모듈이 두 번째 부스트 방문부터 다시 실행되지 않음, 12편에서 해결)
- 공통 스크립트를 레이아웃 인라인에서 /js/portal.js(head, defer)로 이동 → 부스트 이동 때 중복 실행 없음
- VM 이름을 진짜 링크로: hx-get + hx-push-url, 상세 조각에 <title> 포함
- /vms/:name 전체 페이지 = 목록 + 상세가 열린 패널 (pages/vm.eta·pages/vm.html 삭제)
- 행 작업 버튼의 대상·스왑을 tr의 hx-target:inherited / hx-swap:inherited로 통합
- 뒤로 가기 복원 요청(HX-History-Restore-Request만 옴)을 htmx 요청으로 인식, 세션 만료 시 401 + HX-Redirect
- htmx 4.0.1에서 htmx 링크의 Ctrl·Cmd·Shift+클릭이 막히는 문제 우회 (portal.js)
- FastAPI: /js 경로도 로그인 없이 제공

## 8편에서 추가된 기능 (이벤트 기반, 대부분 public/js/portal.js)
- 모든 htmx 요청에 X-Request-ID (htmx:config:request), 서버가 응답 헤더·로그(rid=)에 기록, 오류 토스트에 표시
- 전역 진행 표시줄 (htmx:before:request / htmx:finally:request, data-quiet 영역 제외)
- 저장하지 않은 변경 보호: data-guard 폼 + htmx:config:request에서 ctx.confirm 지정 → <dialog> 확인, beforeunload
- 단축키: "/" 검색창, "r" 현재 조건으로 새로고침 (htmx.ajax)
- 랩 점검 페이지 이벤트 모니터 (public/js/event-monitor.js)
- FastAPI: 미들웨어 안에서 예외를 처리해 500 응답에도 요청 ID·로그가 남게 함

## 9편에서 추가된 기능 (hx-on · hx-live)
- hx-live 확장 로드 (/vendor/htmx/ext/hx-live.js)
- VM 일괄 선택·재시작: 선택 수(:text)·버튼 활성화(:disabled)는 hx-live, 전체 선택은 hx-on, 요청은 hx-post + hx-include
- 토스트 닫기 버튼 (hx-on:click)
- 메모 글자 수 표시 (hx-live :text, :.over)
- 알림 설정 미리보기 문장 (hx-live :text, 모핑 후에도 재계산)
- 상세 패널 "이름 복사" (hx-on 안에서 await, timeout())
- FastAPI 0.162.1로 갱신 (2026-11-07 릴리스)

## 10편에서 추가된 기능 (확장과 실시간)
- SSE(/events, hx-sse:connect): 바뀐 행·요약 카드를 <hx-partial>로 푸시. 요약 5초 폴링과 전환 중 행 폴링 제거
  - 사용자 권한별 렌더링, Last-Event-ID 재전송(최근 200건), 15초 하트비트
  - 탭 식별자(X-Client-ID)로 "자기 변경"은 되돌려 보내지 않음 (응답과의 경쟁 방지)
- 활동 기록 10초 폴링 + hx-ptag (변경 없으면 304)
- VM 링크 hx-preload="mouseenter"
- WebSocket 운영 메모 채널(/ws/ops, hx-ws) — Express는 ws 8.22.2, FastAPI는 websockets 17.4 필요
- 직접 만든 확장 public/js/ext/portal-ops.js (요청 ID·탭 ID 헤더, 느린 요청 경고)
- htmx-config의 extensions 허용 목록

## 11편에서 바뀐 점 (DOM 소유권과 아일랜드 배선)
- 아일랜드 등록부(public/js/portal.js의 PortalIslands): 번들은 register만, 마운트는 htmx:after:process, 정리는 MutationObserver
- React·Vue 번들을 레이아웃 head에서 한 번만 로드 → 랩 점검 링크도 부스트 (7편의 hx-boost="false" 제거)
- VM 상세에 React CPU 차트 아일랜드 (data-island="metric-chart", hx-ignore 경계)
- 데이터 API GET /api/vms/:name/metrics (JSON), 세션 없으면 401 JSON
- concurrently 10.0.7 (2026-11-07)

## 12편에서 바뀐 점 (웹 컴포넌트로 아일랜드 감싸기, 패턴 A)
- React: apps/react-islands/src/define-react-element.jsx 도우미로 <metric-chart vm>, <hello-react who> 정의
  (섀도 DOM, connectedCallback 마운트, disconnectedCallback + 마이크로태스크 확인 후 언마운트, connectedMoveCallback, attributeChangedCallback 재렌더)
- Vue: defineCustomElement로 <hello-vue who> 정의
- 11편의 아일랜드 등록부(portal.js) 삭제
- 템플릿: data-island div → 사용자 정의 태그 (태그 안 문단은 번들이 없을 때 보이는 대체 내용)
- FastAPI 0.162.2 (2026-11-07)

## 13편에서 추가된 기능 (이벤트 브리지와 상태 공유, 패턴 A 완성)
- 아일랜드 → htmx: <metric-chart>에서 점을 누르면 호스트가 metric:select 이벤트 발생 →
  상세 패널의 htmx 영역이 hx-trigger="metric:select from:'closest article'"로 받아 GET /vms/:name/activity/window?t=
- htmx(서버) → 아일랜드: 알림 저장 응답에 <hx-partial hx-target="#detail-chart" hx-swap="outerMorph">로 threshold 속성만 갱신
- 서버 이벤트 → 아일랜드: HX-Trigger의 vmChanged를 차트가 document에서 듣고 즉시 다시 읽음
- 아일랜드 ↔ 아일랜드: Vue <metric-summary>가 React 차트의 metric:select를 듣고 선택 시점을 표시 (서로 import하지 않음)
- 차트 id를 detail-chart로 고정 (VM별 id는 다른 VM으로 모핑할 때 새 요소를 만든다)

## 14편에서 추가된 기능 (패턴 B: React SPA 안의 htmx 영역)
- 새 워크스페이스 apps/react-console: React 19.3.1 + React Router 8.5.1 SPA(운영 콘솔), /console 아래에서 서비스
  - npm run build:islands가 콘솔도 함께 빌드 (출력: apps/server/public/console)
  - 개발 빌드: npm run build:dev -w apps/react-console (React 개발 빌드, StrictMode 이중 실행 관찰용)
- <HtmxRegion>: htmx.ajax({source, target})로 서버 조각을 넣고, 언마운트 때 htmx.swap으로 비워 htmx 정리
- 서버: GET /console/fragments/live-summary (SSE 요약 조각), /console/* SPA 대체 라우트 (?hxhistory=on 실습 토글)
- SPA 페이지는 htmx history를 끔 (meta htmx-config "history": false)
- react-router 8은 Node 22.22 이상 필요 → 루트 engines를 ">=22.22"로

## 15편에서 추가된 기능 (패턴 C: 통합 포털 셸)
- apps/billing-service: 다른 팀의 청구 서비스(포트 3101, node:http만 사용). HTML 조각만 응답, 게이트웨이 토큰 없으면 403
- 게이트웨이(BFF): /billing/* → 업스트림. 인증·권한은 포털이 처리, X-Portal-User/Role·X-Request-ID·X-Forwarded-Prefix 전달,
  htmx 부분 요청은 조각 그대로, 전체 페이지 요청은 포털 레이아웃(pages/composed)에 끼움, 업스트림 장애 시 502 조각
  - FastAPI 쪽은 httpx 0.28.1 사용 (requirements.txt)
- 디자인 토큰: public/css/tokens.css (CSS 변수, 섀도 DOM 안까지 상속)
- 공유 런타임: apps/shared-runtime이 React를 ES 모듈로 /shared/에 빌드, 레이아웃·콘솔의 import map으로 연결
  (아일랜드·콘솔 번들에서 React 제외 → 한 페이지에 React 한 벌)
- 내비: "청구"는 부스트, "운영 콘솔"(별도 SPA 문서)은 hx-boost="false"
- npm run dev / npm start가 청구 서비스도 함께 띄움

## 16편에서 추가된 기능 (패턴 D: 점진적 대체, 스트랭글러 피그)
- apps/legacy-crm: 옮겨 갈 레거시 고객사 관리(포트 3102). 자기 레이아웃의 전체 페이지 + 폼 POST(303) + JSON API
- 포털 /customers, /customers/:id: 기능 플래그(src/flags.js)로 레거시 전달 ↔ 새 구현(포털 htmx) 선택
  - 모드: legacy / shadow(레거시 응답 + 뒤에서 새 구현 값 비교) / percent(사용자 해시로 고정 배정) / new
  - 운영자 ?ff=legacy|new|auto 로 자기 브라우저만 강제 (쿠키)
  - 응답 헤더 X-Served-By, X-Flag-Reason, 로그의 served=
- 새 구현의 쓰기(메모)는 레거시 JSON API(데이터 주인)로 → 두 화면이 같은 값
- /lab/flags: 플래그 관리(운영자만 변경), 경로별 응답 수, 그림자 비교 결과
- npm run dev / npm start가 레거시 CRM도 함께 띄움
- 상단 메뉴 줄바꿈 CSS 수정

## 17편에서 바뀐 점 (보안)
- 보안 헤더: 요청마다 CSP nonce (script-src 'self' 'nonce-…' 'unsafe-eval'), nosniff, Referrer-Policy, COOP, frame-ancestors 'none'
  - 인라인 import map에 nonce (레이아웃, 콘솔 index.html은 서버가 주입). 정적 파일 index 자동 제공 끔
- CSRF: Fetch Metadata(Sec-Fetch-Site) + Origin 검사로 같은 출처가 아닌 상태 변경 요청 403 (CSRF_CHECK=off로 비교 가능)
- 게이트웨이 → 업스트림: X-Gateway-Token + 평문 사용자 헤더 → HMAC 서명 신원 주장 X-Portal-Assertion (aud, exp 30초)
  - src/assertion.js (Express), assertion.py (FastAPI), 청구·레거시 서비스가 검증
- /lab/csp: unsafe-eval 없는 엄격 CSP + hx-csp 확장 데모 (hx-nonce, safeEval, 주입 차단)
- ws 8.22.2 (2026-11-08)

## 18편에서 바뀐 점 (성능과 캐싱)
- 응답 압축: Express는 compression 1.8.2(br·gzip, 1KB 이상), FastAPI는 Starlette GZipMiddleware
  - SSE(text/event-stream)는 압축 제외 (Express는 filter로, Starlette는 기본 제외). COMPRESS_SSE=on으로 지연 재현 가능
- 정적 파일 캐시 정책 명시: 해시 파일명(shared/chunks, console/assets)은 1년 immutable, 나머지는 no-cache(ETag 재검증)
- htmx 응답은 Cache-Control: no-store (Express 자동 ETag + 브라우저 캐시가 hx-ptag 304를 200으로 바꾸던 문제 해결)
- vite 8.3.7 (2026-11-09)

## 19편에서 추가된 것 (테스트 전략)
- npm test = 단위 → FastAPI 라우트 → 계약 → E2E
  - test:unit: Node 기본 테스트 러너 (tests/unit, 의존성 없음)
  - test:py: pytest 9.2.0 + Starlette TestClient(httpx2 2.16.0) (tests/py, apps/server-py/requirements-dev.txt)
  - test:contract: 두 서버(3000, 8000)를 띄운 상태에서 htmx가 보는 구조(id·hx-*·class·name·상태 코드·HX 헤더) 비교 (tests/contract)
  - test:e2e: Playwright Test 1.65.0, express·fastapi 두 프로젝트 (tests/e2e). 로컬 브라우저 경로는 CHROMIUM_PATH로 지정 가능
- .github/workflows/ci.yml: fast(단위·라우트) → e2e(서버 4개 기동 후 계약·E2E) — actions/checkout·setup-node·setup-python·upload-artifact v7

## 20편에서 추가된 것 (빌드·배포·관측)
- npm run build = build:islands + build:assets (scripts/build-assets.mjs)
  - 고정 이름 자산에 내용 해시 → public/dist/, Vite 산출물도 해시 파일명 + .vite/manifest.json
  - 논리 이름 → URL 매니페스트 public/dist/manifest.json, 템플릿은 asset('...')로 참조
  - 모든 해시 파일을 br(품질 11)·gzip(9)로 사전 압축, 서버가 Accept-Encoding에 맞춰 그대로 전송
- 아일랜드 번들은 태그가 나타날 때만 로드 (public/js/islands-loader.js), 레이아웃의 <script id="island-bundles"> 지도
- 관측: Prometheus 지표 (Express prom-client 15.1.3, FastAPI prometheus-client 0.26.0), 지표 전용 포트 METRICS_PORT(기본 9464)
  - portal_http_request_duration_seconds, portal_flag_served_total, portal_shadow_compare_total, portal_sse_connections,
    portal_web_vitals_seconds / portal_web_vitals_cls (RUM: public/js/rum.js + web-vitals 6.2.3 → POST /rum)
- 상태 확인: /healthz(살아 있음), /readyz(준비, 운영에서 매니페스트 없으면 503). 업스트림도 /healthz
- 운영 설정: NODE_ENV=production이면 세션 쿠키 Secure, TRUST_PROXY=1이면 프록시 헤더 신뢰 (FastAPI는 APP_ENV=production, uvicorn --proxy-headers)
- deploy/docker: portal-node, portal-python, upstream Dockerfile (node:26-slim, python:3.13-slim, 숫자 UID)
- deploy/k8s: Namespace(restricted), Secret 예시, Deployment·Service, Gateway API v1 Gateway·HTTPRoute (/events 시간 제한 끔)
- 로컬에서 두 서버를 함께 띄울 때 FastAPI는 METRICS_PORT=9465

## 21편에서 추가된 것 (종합 실습: 패치 작업)
- VM 관리에서 VM을 고르고 "패치 작업 만들기" → POST /jobs (201 + HX-Location) → /jobs/:id
  - 서버 타이머가 VM마다 4단계(스냅샷·패치 적용·재부팅·상태 확인) 진행, 중지된 VM은 건너뜀, JOB_TICK_MS(기본 400)
  - 진행은 SSE가 작업 목록 행(#job-row-…)과 상세(#job-…)에 밀어 줌. 새 작업은 목록 맨 위에 추가
  - 취소 POST /jobs/:id/cancel: 응답은 토스트로만(HX-Retarget), 상세는 SSE가 갱신
- src/jobs.js (Express), jobs.py (FastAPI), 지표 portal_jobs_total, portal_job_duration_seconds
- 테스트 추가: 단위 3, 라우트 3, 계약 1(3화면), E2E 2(×두 서버) → npm test 70개
- fastapi 0.162.4 (2026-11-10)

## 22편
- 저장소 통합본: README 재작성, docs/EPISODES.md(이 파일), docs/FINDINGS.md(측정으로 바로잡은 내용)
- vite 8.3.8, @vitejs/plugin-react 6.3.0으로 갱신
