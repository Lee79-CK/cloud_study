// 자동 생성: node gen-entries.mjs (react-dom/client)
import M from 'react-dom/client';
export default M;
export const { createRoot, hydrateRoot, version } = M;
