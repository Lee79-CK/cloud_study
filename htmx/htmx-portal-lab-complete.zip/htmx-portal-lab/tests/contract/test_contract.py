"""19편: 계약 테스트 — Express와 FastAPI가 같은 요청에 "htmx가 보는 구조"가 같은 응답을 내는지 비교한다.
문구·공백·주석은 달라도 되지만, htmx 속성·id·상태 코드·HX 헤더가 다르면 한쪽 화면이 다르게 동작한다.
실행: 두 서버를 띄운 뒤  npm run test:contract   (EXPRESS_URL, FASTAPI_URL로 주소 변경 가능)"""
import json
import os
import re
from html.parser import HTMLParser

import httpx
import pytest

SERVERS = {"express": os.environ.get("EXPRESS_URL", "http://localhost:3000"),
           "fastapi": os.environ.get("FASTAPI_URL", "http://localhost:8000")}
HX = {"HX-Request": "true", "HX-Request-Type": "partial"}
TRACKED_HX_HEADERS = ("hx-trigger", "hx-retarget", "hx-reswap", "hx-redirect", "hx-location", "hx-push-url", "hx-replace-url", "hx-ptag")


class Sig(HTMLParser):
    """htmx가 보는 구조만 뽑는다: id가 있거나 hx-* 속성이 있는 요소, 사용자 정의 요소, 폼 입력의 name"""
    def __init__(self):
        super().__init__()
        self.items = []

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        hx = {k: norm(v) for k, v in a.items() if k.startswith("hx-")}
        if a.get("id") or hx or "-" in tag or (tag in ("input", "select", "textarea") and a.get("name")):
            self.items.append((tag, a.get("id"), tuple(sorted(hx.items())), a.get("name"), " ".join(sorted((a.get("class") or "").split()))))


def norm(v):
    v = v or ""
    v = re.sub(r"a\d+", "a#", v) if re.fullmatch(r"a\d+", v) else v      # hx-ptag 버전 번호
    return re.sub(r"\s+", " ", v).strip()


def sig(html):
    p = Sig()
    p.feed(html)
    return p.items


def session(base, user="kim"):
    c = httpx.Client(base_url=base, follow_redirects=False, timeout=10)
    c.post("/lab/reset")   # 로그인 전이라도 통과하는 경로가 아니면 무시됨
    r = c.post("/login", data={"user": user, "next": "/vms"})
    assert r.status_code == 303, f"{base} 로그인 실패 {r.status_code}"
    c.post("/lab/reset")
    return c


@pytest.fixture(scope="module")
def pair():
    try:
        clients = {k: session(v) for k, v in SERVERS.items()}
    except httpx.ConnectError as e:
        pytest.skip(f"서버가 떠 있지 않음: {e}")
    yield clients
    for c in clients.values():
        c.close()


def both(pair, method, url, **kw):
    return {k: c.request(method, url, **kw) for k, c in pair.items()}


def assert_same(res, label):
    e, f = res["express"], res["fastapi"]
    assert e.status_code == f.status_code, f"{label}: 상태 코드 {e.status_code} != {f.status_code}"
    for h in TRACKED_HX_HEADERS:
        ev, fv = e.headers.get(h), f.headers.get(h)
        if h == "hx-ptag" and ev and fv:
            ev, fv = norm(ev), norm(fv)
        if ev and fv and ev[:1] in "{[":                 # JSON 헤더는 공백 차이를 무시하고 값으로 비교
            ev, fv = json.loads(ev), json.loads(fv)
        assert ev == fv, f"{label}: 헤더 {h} 다름\n  express={ev}\n  fastapi={fv}"
    es, fs = sig(e.text), sig(f.text)
    if es != fs:
        only_e = [x for x in es if x not in fs][:5]
        only_f = [x for x in fs if x not in es][:5]
        pytest.fail(f"{label}: 구조 다름\n  express에만: {only_e}\n  fastapi에만: {only_f}")


CASES = [
    ("GET", "/vms", {"headers": HX}, "VM 목록 조각"),
    ("GET", "/vms?q=web&status=running", {"headers": HX}, "검색 조각"),
    ("GET", "/vms/web-01", {"headers": HX}, "VM 상세 조각"),
    ("GET", "/vms/summary", {"headers": HX}, "요약 조각"),
    ("GET", "/vms/web-01/activity/live", {"headers": HX}, "활동 기록 조각"),
    ("GET", "/vms/web-01/memo/edit", {"headers": HX}, "메모 편집 폼"),
    ("GET", "/vms/nope", {"headers": HX}, "없는 VM"),
    ("GET", "/lab/flags", {}, "플래그 화면(전체 페이지)"),
    ("GET", "/vms", {}, "VM 관리(전체 페이지)"),
    ("GET", "/lab", {}, "랩 점검(전체 페이지)"),
    ("GET", "/billing/invoices", {"headers": HX}, "청구 조각(게이트웨이)"),
]


@pytest.mark.parametrize("method,url,kw,label", CASES, ids=[c[3] for c in CASES])
def test_같은_구조(pair, method, url, kw, label):
    assert_same(both(pair, method, url, **kw), label)


def test_재시작_응답(pair):
    assert_same(both(pair, "POST", "/vms/web-02/restart", headers=HX), "재시작 응답")


def test_알림_검증_오류(pair):
    assert_same(both(pair, "PUT", "/vms/web-01/alerts", headers=HX,
                     data={"cpu": "abc", "mem": "85", "channel": "email", "contact": ""}), "알림 검증 오류")


def test_고객사_새_구현(pair):
    both(pair, "PUT", "/lab/flags/customers.detail", headers=HX, data={"mode": "new", "percent": "0"})
    assert_same(both(pair, "GET", "/customers/2"), "고객사 상세(새 구현)")


def test_비교기_민감도(pair):
    """비교기가 정말 차이를 잡는지 확인: 같은 서버의 서로 다른 VM 상세는 달라야 한다"""
    c = pair["express"]
    a, b = c.get("/vms/web-01", headers=HX), c.get("/vms/web-02", headers=HX)
    assert sig(a.text) != sig(b.text)


def test_패치_작업_화면(pair):
    """21편: 두 서버에서 같은 작업을 만들고 바로 취소해 상태를 고정한 뒤 비교"""
    both(pair, "POST", "/jobs", headers=HX, data={"sel": ["web-01", "db-01"]})
    both(pair, "POST", "/jobs/J-0001/cancel", headers=HX)
    assert_same(both(pair, "GET", "/jobs", headers=HX), "작업 목록 조각")
    assert_same(both(pair, "GET", "/jobs/J-0001", headers=HX), "작업 상세 조각")
    assert_same(both(pair, "GET", "/jobs/J-0001"), "작업 상세(전체 페이지)")
