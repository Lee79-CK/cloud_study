"""실습용 인메모리 저장소 (Express 쪽 data.js와 같은 규칙)."""
import math
import re
import threading
import time
from datetime import datetime

SEED = [
    ("web-01", "한빛물산", "running"), ("web-02", "한빛물산", "running"), ("db-01", "한빛물산", "stopped"),
    ("api-01", "누리로지스", "running"), ("api-02", "누리로지스", "running"), ("db-02", "누리로지스", "stopped"),
    ("batch-01", "새솔제약", "running"), ("web-03", "새솔제약", "running"), ("cache-01", "새솔제약", "running"),
    ("mq-01", "다온핀테크", "running"), ("db-03", "다온핀테크", "running"), ("gpu-01", "다온핀테크", "stopped"),
] + [  # 4편: 무한 스크롤 실습용 앱 서버 36대 (5대 중 1대는 중지)
    (f"app-{i + 1:02d}", ["한빛물산", "누리로지스", "새솔제약", "다온핀테크"][i % 4], "stopped" if i % 5 == 4 else "running")
    for i in range(36)
]
SPEC = {"web": "2 vCPU · 4 GiB", "api": "4 vCPU · 8 GiB", "db": "8 vCPU · 32 GiB", "batch": "4 vCPU · 16 GiB",
        "cache": "2 vCPU · 8 GiB", "mq": "2 vCPU · 4 GiB", "gpu": "16 vCPU · 64 GiB · L4 x1", "app": "2 vCPU · 4 GiB"}
TRANSITION_SEC = 1.5
TAG_RULE = re.compile(r"^[0-9a-z가-힣-]{1,20}$")
MEMO_MAX = 500
ACTIVITY_PAGE = 3
STATUS_LABEL = {"running": "실행 중", "stopped": "중지됨", "restarting": "재시작 중", "starting": "시작 중"}

_vms: list[dict] = []
_clock = 0

# 10편: 변경 알림. SSE 엔드포인트(main.py)가 구독한다. 호출 스레드가 여러 곳이므로 받는 쪽이 스레드 안전하게 처리
listeners: list = []


def _changed(names, kind: str = "vm") -> None:
    ev = {"names": list(names) if isinstance(names, (list, tuple)) else [names], "kind": kind}
    for fn in list(listeners):
        fn(ev)


def _hash(s: str) -> int:
    """FNV-1a 32비트 (Express 쪽 data.js와 같은 값)"""
    h = 2166136261
    for c in s:
        h ^= ord(c)
        h = (h * 16777619) & 0xFFFFFFFF
    return h


def metrics(vm: dict, now_ms: float | None = None) -> dict:
    """11편: 아일랜드용 데이터 API. 실제로는 모니터링 시스템에서 읽어 오는 자리"""
    step, n = 10_000, 30
    now_ms = now_ms if now_ms is not None else time.time() * 1000
    base = 20 + _hash(vm["name"]) % 40
    end = int(now_ms // step) * step
    points = []
    for i in range(n):
        t = end - (n - 1 - i) * step
        wave = math.sin((t / step + _hash(vm["name"]) % 17) / 3) * 12
        noise = (_hash(vm["name"] + str(t)) % 1000) / 1000 * 10
        cpu = 0 if vm["status"] == "stopped" else max(1, min(99, math.floor(base + wave + noise + 0.5)))
        points.append({"t": t, "cpu": cpu})
    return {"vm": vm["name"], "status": vm["status"], "unit": "%", "step": step // 1000, "points": points}


def activity_version(vm: dict) -> str:
    """10편: 활동 기록 버전 (hx-ptag 값)"""
    return f"a{vm['activity'][0]['seq'] if vm['activity'] else 0}"


def _log(vm: dict, text: str) -> None:
    global _clock
    _clock += 1
    vm["activity"].insert(0, {"seq": _clock, "at": datetime.now(), "text": text})


def reset() -> None:
    global _vms, _clock
    _clock = 0
    _vms = []
    for name, customer, status in SEED:
        vm = {"name": name, "customer": customer, "status": status, "busy_until": 0.0,
              "spec": SPEC[name.split("-")[0]], "memo": "", "tags": [], "monitoring": status == "running",
              "activity": [], "alerts": {"cpu": 80, "mem": 85, "channel": "email", "contact": ""}}
        _log(vm, "VM 등록")
        if name.startswith("db"):
            vm["tags"] += ["db", "백업대상"]
            _log(vm, "태그 추가: db, 백업대상")
        if name == "web-01":
            vm["memo"] = "고객사 대표 홈페이지. 배포 전 담당자 확인 필요."
            for i in range(1, 8):
                _log(vm, f"점검 기록 #{i}")
        _vms.append(vm)
    _changed([], "reset")


def _settle(vm: dict) -> dict:
    if vm["status"] in ("restarting", "starting") and time.time() >= vm["busy_until"]:
        vm["status"] = "running"
        _log(vm, "상태 변경: 실행 중")
    return vm


def _is_busy(v: dict) -> bool:
    return v["status"] in ("restarting", "starting")


def search(q: str = "", status: str = "") -> list[dict]:
    """4편: 상태 필터 추가 ('' | running | stopped | busy)"""
    k = q.strip().lower()
    return [v for v in map(_settle, _vms)
            if (not k or k in v["name"] or k in v["customer"].lower())
            and (not status or (_is_busy(v) if status == "busy" else v["status"] == status))]


PAGE_SIZE = 15


def paginate(items: list[dict], page: int = 1) -> dict:
    p = max(1, page)
    chunk = items[(p - 1) * PAGE_SIZE: p * PAGE_SIZE]
    return {"items": chunk, "page": p, "next_page": p + 1 if p * PAGE_SIZE < len(items) else None, "total": len(items)}


def summary() -> dict:
    allv = list(map(_settle, _vms))
    return {"total": len(allv), "running": sum(v["status"] == "running" for v in allv),
            "stopped": sum(v["status"] == "stopped" for v in allv), "busy": sum(_is_busy(v) for v in allv),
            "at": datetime.now()}


def find(name: str) -> dict | None:
    vm = next((v for v in _vms if v["name"] == name), None)
    return _settle(vm) if vm else None


def transition(name: str, action: str) -> tuple[int, dict | None]:
    vm = find(name)
    if vm is None:
        return 404, None
    allowed = (action == "restart" and vm["status"] == "running") or (action == "start" and vm["status"] == "stopped")
    if not allowed:
        return 409, vm
    vm["status"] = "restarting" if action == "restart" else "starting"
    vm["busy_until"] = time.time() + TRANSITION_SEC
    _log(vm, "재시작 요청" if action == "restart" else "시작 요청")
    _changed(name)

    def done():   # 전환이 끝나는 시점에 다시 알림
        if vm in _vms:
            _settle(vm)
            _changed(name, "settled")
    threading.Timer(TRANSITION_SEC + 0.05, done).start()
    return 200, vm


def remove(name: str) -> bool:
    global _vms
    before = len(_vms)
    _vms = [v for v in _vms if v["name"] != name]
    if len(_vms) < before:
        _changed(name, "removed")
    return len(_vms) < before


# ---- 3편에서 추가 ----
def set_memo(vm: dict, memo: str) -> str | None:
    text = (memo or "").strip()
    if len(text) > MEMO_MAX:
        return f"메모는 {MEMO_MAX}자 이하로 입력하세요. (현재 {len(text)}자)"
    vm["memo"] = text
    _log(vm, "메모 수정" if text else "메모 삭제")
    return None


def add_tag(vm: dict, raw: str) -> str | None:
    tag = (raw or "").strip().lower()
    if not TAG_RULE.match(tag):
        return "태그는 1~20자의 한글·영소문자·숫자·하이픈만 쓸 수 있습니다."
    if tag in vm["tags"]:
        return f"이미 있는 태그입니다: {tag}"
    if len(vm["tags"]) >= 8:
        return "태그는 VM당 최대 8개입니다."
    vm["tags"].append(tag)
    _log(vm, f"태그 추가: {tag}")
    return None


def remove_tag(vm: dict, tag: str) -> str | None:
    if tag not in vm["tags"]:
        return f"없는 태그입니다: {tag}"
    vm["tags"].remove(tag)
    _log(vm, f"태그 삭제: {tag}")
    return None


def set_monitoring(vm: dict, on: bool) -> None:
    vm["monitoring"] = on
    _log(vm, "모니터링 켜짐" if on else "모니터링 꺼짐")


# ---- 5편: 알림 임계값 설정 ----
CHANNELS = {"email": "이메일", "slack": "Slack", "sms": "문자"}


def _int(v):
    try:
        return int(str(v))
    except ValueError:
        return None


def check_alerts(form: dict) -> dict:
    errors = {}
    cpu, mem = _int(form.get("cpu", "")), _int(form.get("mem", ""))
    channel = str(form.get("channel", ""))
    contact = str(form.get("contact", "")).strip()
    if cpu is None or not 50 <= cpu <= 99:
        errors["cpu"] = "CPU 임계값은 50~99 사이 정수여야 합니다."
    if mem is None or not 50 <= mem <= 99:
        errors["mem"] = "메모리 임계값은 50~99 사이 정수여야 합니다."
    if channel not in CHANNELS:
        errors["channel"] = "알림 채널을 고르세요."
    if channel == "email" and contact and not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", contact):
        errors["contact"] = "이메일 주소 형식이 아닙니다."
    if channel == "slack" and contact and not re.match(r"^#[0-9a-z가-힣_-]{1,40}$", contact):
        errors["contact"] = "Slack 채널은 #으로 시작해야 합니다."
    if channel == "sms" and contact and not re.match(r"^01[0-9]-?\d{3,4}-?\d{4}$", contact):
        errors["contact"] = "휴대폰 번호 형식이 아닙니다."
    values = {"cpu": form.get("cpu", ""), "mem": form.get("mem", ""), "channel": channel, "contact": contact}
    return {"values": values, "errors": errors, "ok": not errors}


def save_alerts(vm: dict, form: dict) -> dict:
    r = check_alerts(form)
    if r["ok"]:
        vm["alerts"] = {"cpu": int(form["cpu"]), "mem": int(form["mem"]), "channel": r["values"]["channel"],
                        "contact": r["values"]["contact"]}
        a = vm["alerts"]
        _log(vm, f"알림 설정 변경: CPU {a['cpu']}% · 메모리 {a['mem']}% · {CHANNELS[a['channel']]}")
    return r


# ---- 6편: VM 등록 ----
CUSTOMERS = ["한빛물산", "누리로지스", "새솔제약", "다온핀테크"]


def create_vm(form: dict) -> dict:
    name = str(form.get("name", "")).strip().lower()
    customer = str(form.get("customer", ""))
    errors = {}
    if not re.match(r"^[a-z]+-\d{2}$", name):
        errors["name"] = '이름은 "영소문자-두 자리 숫자" 형식이어야 합니다. (예: web-04)'
    elif any(v["name"] == name for v in _vms):
        errors["name"] = f"이미 있는 VM 이름입니다: {name}"
    if customer not in CUSTOMERS:
        errors["customer"] = "고객사를 고르세요."
    values = {"name": name, "customer": customer}
    if errors:
        return {"ok": False, "values": values, "errors": errors}
    vm = {"name": name, "customer": customer, "status": "stopped", "busy_until": 0.0,
          "spec": SPEC.get(name.split("-")[0], "2 vCPU · 4 GiB"), "memo": "", "tags": [], "monitoring": False,
          "activity": [], "alerts": {"cpu": 80, "mem": 85, "channel": "email", "contact": ""}}
    _log(vm, "VM 등록")
    _vms.insert(0, vm)
    _changed(name, "created")
    return {"ok": True, "vm": vm}


def activity_window(vm: dict, t_ms: int, span_ms: int = 60_000) -> list:
    """13편: 차트에서 고른 시점 전후 1분의 활동"""
    return [a for a in vm["activity"] if abs(a["at"].timestamp() * 1000 - t_ms) <= span_ms]


def activity_page(vm: dict, before: float = float("inf")) -> dict:
    items = [a for a in vm["activity"] if a["seq"] < before][:ACTIVITY_PAGE]
    has_more = bool(items) and any(a["seq"] < items[-1]["seq"] for a in vm["activity"])
    return {"items": items, "next_before": items[-1]["seq"] if has_more else None}


reset()
