// htmx 상호작용 E2E: 검색, 상세, 메모 저장, 재시작 토스트
import { test, expect } from '@playwright/test';
import { login, reset } from './helpers.js';

test.beforeEach(async ({ page }) => { await login(page); await reset(page); await page.goto('/vms'); });

test('검색어 입력 → 목록 조각만 교체 (페이지 이동 없음)', async ({ page }) => {
  await page.evaluate(() => { window.__same = true; });
  await page.fill('input[name=q]', 'db');
  await expect(page.locator('#vm-body')).not.toContainText('web-01');      // 입력 지연(4편) 뒤 목록 조각 교체
  await expect(page.locator('#vm-body')).toContainText('db-01');
  expect(await page.evaluate(() => window.__same)).toBe(true);           // 같은 문서
  await expect(page).toHaveURL(/q=db/);                                    // 7편: 주소 갱신
});

test('상세 열기 → 아일랜드 차트, 메모 저장 → 토스트', async ({ page }) => {
  await page.click('#row-web-01 a');
  await expect(page.locator('#detail h2')).toContainText('web-01');
  await expect(page.locator('#detail-chart svg polyline')).toBeVisible();  // 섀도 DOM도 기본으로 관통
  await page.click('#detail .memo button:has-text("편집")');
  await page.fill('#detail textarea[name=memo]', 'E2E 메모');
  await page.click('#detail .memo button[type=submit]');
  await expect(page.locator('#detail .memo')).toContainText('E2E 메모');
});

test('재시작 → 토스트와 행 상태, 1.6초 뒤 실행 중', async ({ page }) => {
  await page.click('#row-web-02 button:has-text("재시작")');
  await expect(page.locator('#toasts')).toContainText('web-02 재시작 요청을 보냈습니다');
  await expect(page.locator('#row-web-02')).toContainText('재시작 중');
  await expect(page.locator('#row-web-02')).toContainText('실행 중', { timeout: 5000 });   // SSE가 밀어 줌
});
