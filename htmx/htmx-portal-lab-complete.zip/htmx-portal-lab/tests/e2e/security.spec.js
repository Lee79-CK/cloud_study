// 보안 E2E: CSP 위반 없음, CSRF 차단 (17편)
import { test, expect } from '@playwright/test';
import { login } from './helpers.js';

test('주요 화면에서 CSP 위반 0건', async ({ page }) => {
  const violations = [];
  page.on('console', m => { if (/Content Security Policy|Refused to/.test(m.text())) violations.push(m.text()); });
  await login(page);
  for (const url of ['/vms/web-01', '/lab', '/console', '/billing/invoices']) {
    await page.goto(url);
    // SSE·폴링이 있는 페이지는 네트워크가 영원히 "바쁨"이라 networkidle을 기다리면 안 된다 → 고정 대기
    await page.waitForTimeout(800);
  }
  expect(violations).toEqual([]);
});

test('같은 사이트 다른 출처의 상태 변경 요청은 403', async ({ page }) => {
  await login(page);
  const r = await page.request.post('/vms/web-01/restart', { headers: { 'Sec-Fetch-Site': 'same-site', Origin: 'http://localhost:3999' } });
  expect(r.status()).toBe(403);
});
