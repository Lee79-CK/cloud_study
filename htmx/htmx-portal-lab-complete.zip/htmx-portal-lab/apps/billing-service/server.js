// 15편: "다른 팀"의 청구 서비스. 포털과 별개로 배포되는 업스트림이라고 가정한다.
// 의존성 없이 node:http만 쓴다. 레이아웃 없이 HTML 조각만 돌려주고, 포털 게이트웨이가 셸에 끼워 넣는다.
// 계약: 게이트웨이가 X-Gateway-Token(공유 비밀), X-Portal-User/Role(인증 결과), X-Forwarded-Prefix(공개 경로)를 보낸다.
import { createServer } from 'node:http';
// 17편: 게이트웨이가 HMAC으로 서명한 신원 주장 검증 (포털 apps/server/src/assertion.js와 같은 규칙)
import { createHmac, timingSafeEqual } from 'node:crypto';
const ASSERTION_KEY = process.env.ASSERTION_KEY ?? 'lab-assertion-key-change-me';
function verifyAssertion(token, aud) {
  const [body, sig] = String(token ?? '').split('.');
  if (!body || !sig) return { ok: false, reason: 'missing' };
  const expected = createHmac('sha256', ASSERTION_KEY).update(body).digest();
  const given = Buffer.from(sig, 'base64url');
  if (given.length !== expected.length || !timingSafeEqual(given, expected)) return { ok: false, reason: 'bad-signature' };
  const claims = JSON.parse(Buffer.from(body, 'base64url').toString());
  if (claims.aud !== aud) return { ok: false, reason: 'wrong-audience' };
  if (claims.exp < Math.floor(Date.now() / 1000)) return { ok: false, reason: 'expired' };
  return { ok: true, claims };
}

const PORT = Number(process.env.PORT ?? 3101);
const esc = (s) => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const won = (n) => n.toLocaleString('ko-KR') + '원';

let invoices = [];
function reset() {
  const rows = [['한빛물산', 1240000], ['한빛물산', 980000], ['누리로지스', 2310000], ['새솔제약', 455000], ['다온핀테크', 3120000]];
  invoices = rows.map(([customer, amount], i) => ({ id: `INV-2026-${String(i + 101).padStart(4, '0')}`, customer, amount, month: '2026-10', paid: i % 3 === 1, paidBy: null }));
}
reset();

function list(prefix, customer) {
  const rows = invoices.filter(v => !customer || v.customer === customer);
  return `<section class="billing" id="billing">
  <h2>청구 내역 <small class="muted">청구 서비스 (별도 서버) · ${rows.length}건</small></h2>
  <table><thead><tr><th>번호</th><th>고객사</th><th>월</th><th>금액</th><th>상태</th></tr></thead><tbody>
  ${rows.map(v => `<tr><td><a href="${prefix}/invoices/${v.id}" hx-get="${prefix}/invoices/${v.id}" hx-target="#billing-detail">${v.id}</a></td>
    <td>${esc(v.customer)}</td><td>${v.month}</td><td class="num">${won(v.amount)}</td>
    <td>${v.paid ? '<span class="badge ok">납부</span>' : '<span class="badge warn">미납</span>'}</td></tr>`).join('')}
  </tbody></table>
  <div id="billing-detail" class="box"><p class="muted">청구서 번호를 누르면 상세가 여기에 표시됩니다.</p></div>
</section>`;
}
function detail(prefix, v, who) {
  return `<h3>${v.id} <small class="muted">${esc(v.customer)} · ${v.month}</small></h3>
<p>금액 <b>${won(v.amount)}</b> · ${v.paid ? `납부 완료${v.paidBy ? ` (처리: ${esc(v.paidBy)})` : ''}` : '미납'}</p>
${v.paid ? '' : `<button hx-post="${prefix}/invoices/${v.id}/pay" hx-target="#billing-detail" hx-confirm="${v.id}를 납부 처리할까요?">납부 처리</button>`}
<p class="muted">요청 사용자: ${esc(who)} (게이트웨이가 전달)</p>`;
}

createServer(async (req, res) => {
  const url = new URL(req.url, 'http://upstream');
  const send = (status, html, headers = {}) => { res.writeHead(status, { 'Content-Type': 'text/html; charset=utf-8', ...headers }); res.end(html); };
  console.log(`BILLING ${req.method} ${url.pathname}${url.search} rid=${String(req.headers['x-request-id'] ?? '-').slice(0, 8)} hx=${req.headers['hx-request'] ?? '-'}`);
  // 17편: 게이트웨이가 서명한 신원 주장만 믿는다. 평문 X-Portal-User 헤더는 더 이상 읽지 않는다
  // 20편: Kubernetes 프로브용 상태 확인 (신원 확인 전)
  if (url.pathname === '/healthz') { res.writeHead(200, { 'Content-Type': 'text/plain' }); return res.end('ok'); }
  const v = verifyAssertion(req.headers['x-portal-assertion'], 'billing');
  if (!v.ok) { console.log(`BILLING 거부 reason=${v.reason}`); return send(403, `<p>신원 확인 실패 (${v.reason})</p>`); }
  const prefix = String(req.headers['x-forwarded-prefix'] ?? '');
  const who = v.claims.sub;
  if (req.method === 'GET' && url.pathname === '/invoices') return send(200, list(prefix, url.searchParams.get('customer')));
  let m = url.pathname.match(/^\/invoices\/([\w-]+)$/);
  if (req.method === 'GET' && m) {
    const v = invoices.find(x => x.id === m[1]);
    return v ? send(200, detail(prefix, v, who)) : send(404, '<p>청구서를 찾을 수 없습니다.</p>');
  }
  m = url.pathname.match(/^\/invoices\/([\w-]+)\/pay$/);
  if (req.method === 'POST' && m) {
    const v = invoices.find(x => x.id === m[1]);
    if (!v) return send(404, '<p>청구서를 찾을 수 없습니다.</p>');
    v.paid = true; v.paidBy = who;
    return send(200, detail(prefix, v, who), { 'HX-Trigger': JSON.stringify({ invoicePaid: { id: v.id } }) });
  }
  if (req.method === 'POST' && url.pathname === '/reset') { reset(); return send(200, 'ok'); }
  send(404, '<p>없는 경로</p>');
}).listen(PORT, () => console.log(`▶ 청구 서비스 http://localhost:${PORT} (업스트림, 직접 접근 불가)`));
