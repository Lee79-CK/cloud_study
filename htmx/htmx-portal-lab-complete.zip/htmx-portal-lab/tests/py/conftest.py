# 19편: FastAPI 라우트 테스트. 서버를 띄우지 않고 TestClient(httpx)로 앱을 직접 호출한다.
import os
import sys
from pathlib import Path

import pytest

APP_DIR = Path(__file__).resolve().parents[2] / "apps" / "server-py"
sys.path.insert(0, str(APP_DIR))
os.environ.setdefault("METRICS_PORT", "off")   # 20편: 테스트에서는 지표 포트를 열지 않는다

import main  # noqa: E402
import store  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402


@pytest.fixture()
def client():
    store.reset()
    with TestClient(main.app) as c:
        yield c


def login(c, user="kim"):
    r = c.post("/login", data={"user": user, "next": "/vms"}, follow_redirects=False)
    assert r.status_code == 303
    return c


@pytest.fixture()
def kim(client):
    return login(client, "kim")


@pytest.fixture()
def lee(client):
    return login(client, "lee")


HX = {"HX-Request": "true", "HX-Request-Type": "partial"}
