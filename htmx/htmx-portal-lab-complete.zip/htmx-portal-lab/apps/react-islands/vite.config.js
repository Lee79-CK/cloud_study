import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// 서버(Express/FastAPI)가 /islands/react/ 경로로 제공할 수 있도록 서버의 public 폴더에 바로 빌드한다
export default defineConfig({
  plugins: [react()],
  build: {
    manifest: true,         // 20편: 해시 파일명을 서버가 찾을 수 있게 .vite/manifest.json 생성
    outDir: '../server/public/islands/react',
    emptyOutDir: true,
    rolldownOptions: {   // Vite 8: Rolldown 번들러 옵션 (rollupOptions는 deprecated 별칭)
      input: 'src/main.jsx',
      // 15편: React는 번들에 넣지 않는다. 페이지의 import map이 /shared/의 공유 런타임으로 연결한다
      external: ['react', 'react/jsx-runtime', 'react-dom/client'],
      output: {
        entryFileNames: 'react-islands-[hash].js',   // 20편: 내용 해시 → 1년 immutable 캐시
        chunkFileNames: 'chunks/[name]-[hash].js',
        assetFileNames: 'react-islands[extname]',
      },
    },
  },
});
