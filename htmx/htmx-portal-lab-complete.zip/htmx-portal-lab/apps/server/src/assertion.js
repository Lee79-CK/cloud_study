// 17편: 게이트웨이 → 업스트림 신원 주장(assertion). 15편의 고정 공유 비밀(X-Gateway-Token) + 평문 사용자 헤더를
// HMAC-SHA256으로 서명한 짧은 수명의 토큰 하나로 바꾼다. 형식은 JWT의 HS256과 같은 "본문.서명"(base64url).
// 실서비스에서는 JWT 라이브러리·키 관리(회전)·mTLS를 함께 쓴다. 여기서는 node:crypto만으로 원리를 보인다.
import { createHmac, timingSafeEqual } from 'node:crypto';

const KEY = process.env.ASSERTION_KEY ?? 'lab-assertion-key-change-me';
const b64u = (buf) => Buffer.from(buf).toString('base64url');

export function signAssertion({ sub, role, rid, aud }, ttlSec = 30) {
  const now = Math.floor(Date.now() / 1000);
  const body = b64u(JSON.stringify({ sub, role, rid, aud, iat: now, exp: now + ttlSec }));
  const sig = b64u(createHmac('sha256', KEY).update(body).digest());
  return `${body}.${sig}`;
}

// 업스트림 쪽 검증 (같은 코드를 각 업스트림 서비스에 복사해 둔다)
export function verifyAssertion(token, aud) {
  const [body, sig] = String(token ?? '').split('.');
  if (!body || !sig) return { ok: false, reason: 'missing' };
  const expected = createHmac('sha256', KEY).update(body).digest();
  const given = Buffer.from(sig, 'base64url');
  if (given.length !== expected.length || !timingSafeEqual(given, expected)) return { ok: false, reason: 'bad-signature' };
  const claims = JSON.parse(Buffer.from(body, 'base64url').toString());
  if (claims.aud !== aud) return { ok: false, reason: 'wrong-audience' };
  if (claims.exp < Math.floor(Date.now() / 1000)) return { ok: false, reason: 'expired' };
  return { ok: true, claims };
}
