// 8편: 랩 점검 페이지 전용 이벤트 모니터. htmx 4.0.1이 발생시키는 이벤트를 document에서 듣고 목록에 쌓는다.
(() => {
  if (window.__evmon) return;            // 같은 문서에서 두 번 실행되지 않게
  window.__evmon = true;
  const NAMES = ['config:request', 'confirm', 'before:request', 'before:response', 'after:request', 'response:error',
    'error', 'before:swap', 'before:settle', 'after:settle', 'before:process', 'after:process', 'after:swap',
    'finally:swap', 'finally:request', 'before:cleanup', 'after:cleanup', 'before:history:update',
    'after:history:push', 'after:history:replace', 'before:viewTransition', 'after:viewTransition'];
  let on = true, t0 = null;
  const label = (el) => el === document ? 'document'
    : (el?.tagName?.toLowerCase() ?? '?') + (el?.id ? '#' + el.id : '');
  NAMES.forEach(n => document.addEventListener('htmx:' + n, (e) => {
    const list = document.getElementById('evmon');
    if (!on || !list) return;
    const now = performance.now();
    if (n === 'config:request' || t0 === null) t0 = now;
    const ctx = e.detail?.ctx;
    const li = document.createElement('li');
    li.className = n.includes('error') ? 'err' : n.startsWith('before') || n === 'config:request' || n === 'confirm' ? 'pre' : 'post';
    li.textContent = `+${(now - t0).toFixed(0).padStart(4)}ms  htmx:${n}  @${label(e.target)}`
      + (ctx?.request?.method ? `  ${ctx.request.method} ${ctx.request.action}` : '')
      + (ctx?.response?.status ? `  → ${ctx.response.status}` : '');
    list.prepend(li);
    while (list.children.length > 80) list.lastChild.remove();
  }));
  document.addEventListener('click', (e) => {
    if (e.target.id === 'evmon-toggle') { on = !on; e.target.textContent = on ? '기록 중지' : '기록 시작'; }
    if (e.target.id === 'evmon-clear') document.getElementById('evmon').innerHTML = '';
  });
})();
