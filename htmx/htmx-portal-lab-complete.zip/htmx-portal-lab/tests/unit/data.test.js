// 19편: 서버 순수 로직 단위 테스트 (Node 기본 테스트 러너, 의존성 없음). 실행: npm run test:unit
import { test } from 'node:test';
import assert from 'node:assert/strict';
import * as store from '../../apps/server/src/data.js';

test('metrics는 같은 시각에 같은 값 (FastAPI와 같은 해시 → 계약 테스트의 기준값)', () => {
  store.reset();
  const m = store.metrics(store.find('web-01'), 1762500000000);
  assert.equal(m.points.length, 30);
  assert.deepEqual(m.points.slice(0, 3).map(p => p.cpu), [50, 46, 40]);
});

test('중지된 VM의 CPU는 0', () => {
  store.reset();
  const vm = store.search('', 'stopped')[0];
  assert.ok(vm, '중지된 VM이 하나 이상 있어야 한다');
  assert.ok(store.metrics(vm).points.every(p => p.cpu === 0));
});

test('재시작 요청 → 전환 중, 변경 알림이 2번(요청 시점·완료 시점) 온다', async () => {
  store.reset();
  const events = [];
  const on = (e) => events.push(e);
  store.bus.on('change', on);
  const r = store.transition('web-01', 'restart');
  assert.ok(r.vm, '전환 성공');
  assert.equal(store.find('web-01').status, 'restarting');
  await new Promise(res => setTimeout(res, 1700));
  store.bus.off('change', on);
  assert.deepEqual(events.map(e => e.kind), ['vm', 'settled']);
  assert.equal(store.find('web-01').status, 'running');
});

test('activityWindow는 t 전후 span 안의 기록만', () => {
  store.reset();
  const vm = store.find('web-01');
  const t = vm.activity[0].at.getTime();
  assert.ok(store.activityWindow(vm, t).length >= 1);
  assert.equal(store.activityWindow(vm, t + 10 * 60_000).length, 0);
});
