# syntax=docker/dockerfile:1
# 20편: 포털(Express) 이미지. 저장소 루트에서:  docker build -f deploy/docker/portal-node.Dockerfile -t htmx-portal-node .
# 1단계: 전체 의존성으로 아일랜드·공유 런타임·콘솔 빌드 + 자산 파이프라인(해시·사전 압축·매니페스트)
FROM node:26-slim AS build
WORKDIR /app
COPY package.json package-lock.json ./
COPY apps/server/package.json apps/server/
COPY apps/server/scripts apps/server/scripts
COPY apps/shared-runtime/package.json apps/shared-runtime/
COPY apps/react-islands/package.json apps/react-islands/
COPY apps/vue-islands/package.json apps/vue-islands/
COPY apps/react-console/package.json apps/react-console/
COPY apps/billing-service/package.json apps/billing-service/
COPY apps/legacy-crm/package.json apps/legacy-crm/
RUN npm ci
COPY . .
RUN npm run build
# 2단계 준비: 포털 서버의 운영 의존성만 다시 설치 (빌드 도구·테스트 도구 제외)
RUN rm -rf node_modules && npm ci --omit=dev --workspace apps/server --include-workspace-root=false

# 실행 이미지
FROM node:26-slim
ENV NODE_ENV=production PORT=3000 METRICS_PORT=9464
WORKDIR /app
COPY --from=build --chown=node:node /app/package.json ./
COPY --from=build --chown=node:node /app/node_modules ./node_modules
COPY --from=build --chown=node:node /app/apps/server ./apps/server
# 숫자 UID로 지정: 파드의 runAsNonRoot는 이름(node)만 있으면 루트가 아님을 확인하지 못해 컨테이너를 거부한다
USER 1000
EXPOSE 3000 9464
CMD ["node", "apps/server/src/app.js"]
