import express from 'express';
import compression from 'compression';
import { Eta } from 'eta';
import { dirname, join } from 'node:path';
import { randomUUID, randomBytes } from 'node:crypto';
import { signAssertion } from './assertion.js';
import { existsSync, readFileSync, statSync } from 'node:fs';
import { createServer } from 'node:http';
import client from 'prom-client';
import { WebSocketServer } from 'ws';
import { fileURLToPath } from 'node:url';
import * as store from './data.js';
import * as flags from './flags.js';
import * as jobs from './jobs.js';
import { USERS, ROLE_LABEL, als, parseCookies, createSession, getSession, destroySession, currentUser, safeNext } from './auth.js';

const here = dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT ?? 3000);
const isProd = process.env.NODE_ENV === 'production';
// 20편: 운영 배포 설정. 게이트웨이(TLS 종료) 뒤에서 req.protocol·출처 비교가 https로 보이게 프록시 헤더를 믿고,
// 세션 쿠키에 Secure를 붙인다
const COOKIE_SECURE = isProd ? '; Secure' : '';

const app = express();
if (process.env.TRUST_PROXY) app.set('trust proxy', Number(process.env.TRUST_PROXY));   // 20편: 앞단 프록시 수 (Kubernetes 배포에서 1)

// 20편: 관측 지표 (Prometheus 형식). 업무 포트와 분리된 포트(METRICS_PORT, 기본 9464)에서만 노출한다
const metrics = new client.Registry();
client.collectDefaultMetrics({ register: metrics });
const httpDuration = new client.Histogram({
  name: 'portal_http_request_duration_seconds', help: 'HTTP 요청 처리 시간 (라우트 템플릿·htmx 요청 종류별)',
  labelNames: ['method', 'route', 'status', 'htmx'], buckets: [0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1, 2.5], registers: [metrics],
});
const flagServed = new client.Counter({ name: 'portal_flag_served_total', help: '16편 기능 플래그 경로별 응답 구현', labelNames: ['flag', 'impl'], registers: [metrics] });
const shadowCompare = new client.Counter({ name: 'portal_shadow_compare_total', help: '16편 그림자 비교 결과', labelNames: ['flag', 'result'], registers: [metrics] });
const webVitals = new client.Histogram({
  name: 'portal_web_vitals_seconds', help: '실사용자 Web Vitals (LCP·INP·FCP·TTFB, 초)', labelNames: ['name', 'page', 'rating'],
  buckets: [0.1, 0.2, 0.5, 0.8, 1, 1.8, 2.5, 3, 4, 6], registers: [metrics],
});
const jobsTotal = new client.Counter({ name: 'portal_jobs_total', help: '21편 패치 작업 종료 수', labelNames: ['result'], registers: [metrics] });
const jobDuration = new client.Histogram({ name: 'portal_job_duration_seconds', help: '21편 패치 작업 소요 시간', labelNames: ['result'],
  buckets: [1, 2, 5, 10, 20, 30, 60, 120], registers: [metrics] });
const webVitalsCls = new client.Histogram({
  name: 'portal_web_vitals_cls', help: '실사용자 CLS (단위 없음)', labelNames: ['page', 'rating'],
  buckets: [0.01, 0.05, 0.1, 0.15, 0.25, 0.5], registers: [metrics],
});
const eta = new Eta({
  views: join(here, '..', 'views'),
  cache: isProd,          // 개발 중에는 템플릿을 매번 다시 읽어 수정이 바로 반영됨
});

// ① 정적 파일 (htmx 배포본, CSS, Vite가 빌드한 아일랜드 번들)
// ⓪ 17편: 보안 헤더. 요청마다 새 nonce를 만들어 CSP와 템플릿(인라인 import map)에 같이 쓴다
//   - script-src: 같은 출처 파일 + 이 응답의 nonce를 가진 인라인 스크립트만. 'unsafe-eval'은 hx-on·hx-live 때문에 남긴다
//     (없애려면 hx-csp 확장 — 3절, /lab/csp 데모)
//   - style-src 'unsafe-inline': htmx가 넣는 지시자 <style>, Vue 사용자 정의 요소의 <style>, style 속성 때문
app.use((req, res, next) => {
  res.locals.nonce = randomBytes(16).toString('base64');
  if (!req.path.startsWith('/lab/csp')) {
    res.set('Content-Security-Policy', [
      "default-src 'self'", `script-src 'self' 'nonce-${res.locals.nonce}' 'unsafe-eval'`, "style-src 'self' 'unsafe-inline'",
      "img-src 'self' data:", "connect-src 'self'", "object-src 'none'", "base-uri 'self'", "form-action 'self'", "frame-ancestors 'none'",
    ].join('; '));
  }
  res.set({ 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'same-origin', 'Cross-Origin-Opener-Policy': 'same-origin' });
  next();
});
// ⓪-3 18편: 응답 압축 (br·gzip). HTML 조각은 반복이 많아 잘 줄어든다(측정 2절).
//   SSE(text/event-stream)는 압축하면 압축기가 메시지를 모아 두었다가 늦게 내보내므로 제외한다(측정 4절).
//   COMPRESS_SSE=on은 그 지연을 재현하기 위한 실습용 스위치
app.use(compression({
  threshold: 1024,
  filter: (req, res) => {
    if (process.env.COMPRESS_SSE !== 'on' && String(res.getHeader('Content-Type') ?? '').startsWith('text/event-stream')) return false;
    return compression.filter(req, res);
  },
}));
// ⓪-2 17편: CSRF 방어 (Fetch Metadata). 상태를 바꾸는 요청은 같은 출처에서 온 것만 받는다.
//   SameSite=Lax 쿠키는 "다른 사이트"만 막는다. localhost:3999 같은 "같은 사이트, 다른 출처"는 못 막는다(측정 2절)
app.use((req, res, next) => {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method) || process.env.CSRF_CHECK === 'off') return next();   // off는 실습 비교용
  const site = req.get('Sec-Fetch-Site');                 // 최신 브라우저가 자동으로 붙임 (위조 불가: 금지된 헤더)
  const origin = req.get('Origin');
  const self = `${req.protocol}://${req.get('host')}`;
  const bad = site ? !['same-origin', 'none'].includes(site) : (origin && origin !== self);
  if (bad) {
    console.log(`CSRF   차단 ${req.method} ${req.originalUrl} Sec-Fetch-Site=${site ?? '-'} Origin=${origin ?? '-'}`);
    return res.status(403).type('text').send('Forbidden: cross-origin request');
  }
  next();
});
// 20편: 자산 매니페스트 (npm run build:assets가 만든 public/dist/manifest.json). 논리 이름 → 해시 URL.
//   운영(NODE_ENV=production) 또는 USE_DIST=1이면 매니페스트를 쓴다. 개발 중에는 원본 경로(/vendor, /js, /css)를 그대로 쓰고,
//   아일랜드·공유 런타임은 Vite 감시 빌드가 갱신하는 .vite/manifest.json을 그때그때 읽는다(이름에 해시가 들어가므로)
const PUBLIC_DIR = join(here, '..', 'public');
const MANIFEST_FILE = join(PUBLIC_DIR, 'dist', 'manifest.json');
const MANIFEST = existsSync(MANIFEST_FILE) ? JSON.parse(readFileSync(MANIFEST_FILE, 'utf8')) : {};
const USE_DIST = isProd || process.env.USE_DIST === '1';
const VITE_ENTRIES = {
  'islands/react.js': ['islands/react', 'src/main.jsx'], 'islands/vue.js': ['islands/vue', 'src/main.js'],
  'shared/react.js': ['shared', 'src/react.js'], 'shared/react-jsx-runtime.js': ['shared', 'src/react-jsx-runtime.js'],
  'shared/react-dom-client.js': ['shared', 'src/react-dom-client.js'],
};
function viteEntry(dir, src) {
  try { return `/${dir}/${JSON.parse(readFileSync(join(PUBLIC_DIR, dir, '.vite/manifest.json'), 'utf8'))[src].file}`; } catch { return null; }
}
export const asset = (name) => USE_DIST
  ? (MANIFEST[name] ?? `/${name}`)
  : (VITE_ENTRIES[name] ? (viteEntry(...VITE_ENTRIES[name]) ?? `/${name}`) : `/${name}`);
const islandBundles = () => ({                                // 태그 → 번들 (islands-loader.js가 사용)
  'metric-chart': asset('islands/react.js'), 'hello-react': asset('islands/react.js'),
  'metric-summary': asset('islands/vue.js'), 'hello-vue': asset('islands/vue.js'),
});
console.log(`[assets] ${USE_DIST ? `매니페스트 ${Object.keys(MANIFEST).length}개 항목 사용` : '개발 모드: 원본 경로 + Vite 매니페스트'}`);

// 20편: 사전 압축 파일 제공. 해시 폴더의 파일에 .br/.gz가 있고 브라우저가 받으면 그것을 보낸다(압축 미들웨어보다 앞)
const HASHED = /^\/(dist|islands|shared|console\/assets)\//;
const TYPES = { '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8' };
app.use((req, res, next) => {
  if (!['GET', 'HEAD'].includes(req.method) || !HASHED.test(req.path)) return next();
  const type = TYPES[req.path.slice(req.path.lastIndexOf('.'))];
  if (!type) return next();
  const accept = req.get('Accept-Encoding') ?? '';
  for (const [enc, ext] of [['br', '.br'], ['gzip', '.gz']]) {
    if (!new RegExp(`\\b${enc}\\b`).test(accept)) continue;
    const file = join(PUBLIC_DIR, req.path + ext);
    if (!file.startsWith(PUBLIC_DIR) || !existsSync(file)) continue;
    res.set({ 'Content-Type': type, 'Content-Encoding': enc, 'Vary': 'Accept-Encoding',
              'Cache-Control': 'public, max-age=31536000, immutable', 'Content-Length': statSync(file).size });
    return res.sendFile(file, { headers: { 'Content-Type': type } });
  }
  next();
});
// 18편→20편: 정적 파일 캐시 정책. 해시 폴더(dist·islands·shared·console/assets)는 1년 immutable,
//   이름이 고정된 원본(/vendor, /js, /css — 매니페스트 이전 경로)은 no-cache로 재검증
app.use(express.static(PUBLIC_DIR, {
  index: false,
  setHeaders(res, path) {
    const rel = '/' + path.slice(PUBLIC_DIR.length + 1).replaceAll('\\', '/');
    res.setHeader('Cache-Control', HASHED.test(rel) && !rel.includes('/.vite/') ? 'public, max-age=31536000, immutable' : 'no-cache');
  },
}));

// ①-1 8편: 요청 ID. 클라이언트(portal.js)가 htmx:config:request에서 붙인 X-Request-ID를 쓰고, 없으면 만든다.
// 응답 헤더로 돌려주고 로그에 남겨, 사용자가 보는 오류 메시지와 서버 로그를 이어 준다
app.use((req, res, next) => {
  const rid = req.get('X-Request-ID');
  req.id = /^[0-9a-f-]{8,64}$/i.test(rid ?? '') ? rid : randomUUID();
  res.set('X-Request-ID', req.id);
  next();
});

// ①-2 폼 본문 파싱: htmx 4는 POST·PUT·PATCH 본문을 application/x-www-form-urlencoded로 보낸다
app.use(express.urlencoded({ extended: false }));

// ② htmx 요청 판별 + 관찰용 로그
app.use((req, res, next) => {
  // 7편: 뒤로 가기 복원 요청은 htmx 4.0.1에서 HX-Request 없이 HX-History-Restore-Request만 붙어 온다(실측).
  // 그래서 두 헤더 중 하나라도 있으면 htmx 요청으로 본다
  const restore = req.get('HX-History-Restore-Request') === 'true';
  req.htmx = req.get('HX-Request') === 'true' || restore
    ? {
        type: req.get('HX-Request-Type') ?? 'full',   // 'partial' | 'full' (htmx 4)
        source: req.get('HX-Source'),            // 예: 'button#save'
        target: req.get('HX-Target'),            // 예: 'tbody#vm-body'
        boosted: req.get('HX-Boosted') === 'true',
        restore,
      }
    : null;
  // 18편: htmx 응답은 브라우저 HTTP 캐시에 저장하지 않는다. Express가 자동으로 붙이는 ETag 때문에, 한 번 받은 200이
  // 저장되면 다음 폴링이 자동 재검증되고 서버의 304(hx-ptag의 "바뀐 것 없음")가 브라우저에서 캐시된 200으로 바뀌어
  // htmx가 같은 내용을 매번 다시 스왑했다(측정 6절). 라우트가 필요하면 덮어쓴다
  if (req.htmx) res.set('Cache-Control', 'no-store');
  const t0 = performance.now();
  res.on('finish', () => {
    const ms = (performance.now() - t0).toFixed(1);
    // 20편: 라우트 템플릿(/vms/:name)으로 묶는다. 실제 경로를 라벨에 넣으면 시계열이 끝없이 늘어난다
    httpDuration.observe({ method: req.method, route: req.route?.path ?? (HASHED.test(req.path) ? 'static' : 'unmatched'),
                           status: res.statusCode, htmx: req.htmx?.type ?? 'none' }, (performance.now() - t0) / 1000);
    const tag = req.htmx
      ? `[htmx:${req.htmx.type}${req.htmx.boosted ? ' boosted' : ''}${req.htmx.restore ? ' history-restore' : ''}] source=${req.htmx.source ?? '-'} target=${req.htmx.target ?? '-'}`
      : '[page]';
    let url = req.originalUrl;
    try { url = decodeURIComponent(url); } catch {}
    const body = req.body && Object.keys(req.body).length ? ` body=${JSON.stringify(req.body)}` : '';
    const who = (req.user ? ` user=${req.user.id}` : '') + ` rid=${req.id.slice(0, 8)}`
      + (res.get('X-Served-By') ? ` served=${res.get('X-Served-By')}` : '');
    console.log(`${req.method.padEnd(6)} ${url} → ${res.statusCode} (${ms}ms) ${tag}${who}${body}`);
  });
  next();
});

// ②-2 6편: 세션 확인. 로그인·로그아웃·레거시 페이지·토스트용 noop는 예외
const PUBLIC_PATHS = [/^\/login/, /^\/logout/, /^\/legacy\//, /^\/noop$/, /^\/rum$/, /^\/(healthz|readyz)$/];   // 20편: RUM·상태 확인
app.use((req, res, next) => {
  const sid = parseCookies(req.headers.cookie).sid;
  const session = getSession(sid);
  req.user = session ? { id: session.userId, name: USERS[session.userId].name, role: session.role, sid } : null;
  if (!req.user && !PUBLIC_PATHS.some(r => r.test(req.path))) {
    // 11편: 데이터 API(JSON)는 리다이렉트도 HX-Redirect도 아닌 401 JSON. 호출한 아일랜드가 스스로 처리한다
    if (req.path.startsWith('/api/')) return res.status(401).json({ error: 'unauthenticated' });
    const origin = `${req.protocol}://${req.get('host')}`;
    if (req.htmx) {
      // htmx 요청에 302를 주면 fetch가 리다이렉트를 따라가 로그인 페이지 HTML이 조각 자리에 들어간다.
      // 401 + HX-Redirect로 브라우저 전체를 로그인 페이지로 보낸다. 돌아올 곳은 HX-Current-URL에서 얻는다
      // 복원 요청에는 HX-Current-URL이 없으므로 요청 주소(=복원하려는 화면 주소)를 쓴다
      const next = safeNext(req.htmx.restore ? req.originalUrl : req.get('HX-Current-URL'), origin);
      return res.status(401).set('HX-Redirect', '/login?next=' + encodeURIComponent(next)).send('');
    }
    return res.redirect('/login?next=' + encodeURIComponent(safeNext(req.originalUrl, origin)));
  }
  // 10편: 탭 식별자도 함께 요청 문맥에 둔다 (SSE가 "변경을 일으킨 탭"을 가려낼 때 사용)
  const cid = req.get('X-Client-ID');
  req.clientId = /^[0-9a-f-]{8,64}$/i.test(cid ?? '') ? cid : null;
  als.run({ user: req.user, clientId: req.clientId, nonce: res.locals.nonce }, next);
});

// ②-3 6편: 쓰기 요청은 운영자만. 화면에서 버튼을 숨기지만(HATEOAS) 화면이 오래되어 버튼이 남아 있을 수 있으므로
// 서버가 최종 판단한다. htmx 요청이면 응답 위치를 토스트 영역으로 바꿔(HX-Retarget·HX-Reswap) 경고만 보여 준다
const ROLE_FREE = [/^\/login/, /^\/logout/, /^\/session\//, /\/alerts\/check$/];
app.use((req, res, next) => {
  const isWrite = ['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method);
  if (!isWrite || !req.user || req.user.role === 'operator' || ROLE_FREE.some(r => r.test(req.path))) return next();
  if (req.htmx) {
    return res.status(403)
      .set({ 'HX-Retarget': '#toasts', 'HX-Reswap': 'beforeend' })
      .type('html')
      .send(eta.render('./partials/toast-item', { msg: `권한이 없습니다. ${ROLE_LABEL[req.user.role]} 계정은 변경할 수 없습니다.`, kind: 'warn' }));
  }
  res.status(403).type('text').send('Forbidden');
});

// ③ 렌더링 도우미
const render = (res, view, data = {}, status = 200) =>
  res.status(status).type('html').send(eta.render(view, { ...data, ...viewGlobals(), page: res.req?.route?.path ?? '' }));
const wantsFragment = req => req.htmx?.type === 'partial';
// 6편: 모든 템플릿에 공통으로 넘기는 값 (현재 사용자와 쓰기 권한)
function viewGlobals() {
  const user = currentUser();
  return { labels: store.STATUS_LABEL, channels: store.CHANNELS, user, roleLabel: ROLE_LABEL, canEdit: user?.role === 'operator',
           activityVersion: store.activityVersion, nonce: als.getStore()?.nonce,
           asset, islandBundles: islandBundles() };              // 20편
}

// ④ 화면 라우트 (애플리케이션 API: HTML을 응답)
app.get('/', (req, res) => res.redirect('/vms'));

app.get('/vms', (req, res) => {
  const q = String(req.query.q ?? '');
  const status = String(req.query.status ?? '');
  const page = store.paginate(store.search(q, status), req.query.page);
  // 다음 페이지 주소: 현재 필터를 그대로 유지한 채 page만 바꾼다
  const more = page.nextPage ? '/vms?' + new URLSearchParams({ q, status, page: page.nextPage }) : null;
  res.vary('HX-Request').vary('HX-Request-Type');   // 같은 URL이 두 종류의 응답을 내므로 캐시에 알려 준다
  if (wantsFragment(req)) {
    // 2페이지 이후(무한 스크롤)는 행만, 1페이지(새 검색)는 행 + 건수 배지
    const view = page.page > 1 ? './partials/vm-rows' : './partials/vm-rows-response';
    // 6편: 검색 조건을 주소창에 반영 (기록을 쌓지 않고 바꾸기만). 새로고침·공유해도 같은 화면이 나온다
    if (page.page === 1) {
      const qs = new URLSearchParams(Object.entries({ q, status }).filter(([, v]) => v)).toString();
      res.set('HX-Replace-Url', '/vms' + (qs ? '?' + qs : ''));
    }
    return render(res, view, { list: page.items, more, q, total: page.total });
  }
  render(res, './pages/vms', { title: 'VM 관리', list: page.items, more, q, status, total: page.total, sum: store.summary() });
});

// 6편: VM 등록 — 폼(GET)과 생성(POST). 성공하면 201 + HX-Location으로 새 VM 상세를 연다
app.get('/vms/new', (req, res) => render(res, './partials/vm-new-form', { values: { customer: '' }, errors: {} }));
app.post('/vms', (req, res) => {
  const r = store.createVm(req.body ?? {});
  if (!r.ok) return render(res, './partials/vm-new-form', { values: r.values, errors: r.errors }, 422);
  // HX-Location은 본문을 무시하고 새 GET 요청을 보낸다(기본으로 주소도 push). 토스트 대신 이벤트만 함께 보낸다
  res.status(201).set({
    'HX-Location': JSON.stringify({ path: `/vms/${r.vm.name}`, target: '#detail' }),
    'HX-Trigger': JSON.stringify({ vmChanged: { name: r.vm.name } }),
  }).send('');
});

// 9편: 일괄 재시작. /vms/:name/:action보다 먼저 선언해야 bulk가 VM 이름으로 해석되지 않는다
app.post('/vms/bulk/restart', (req, res) => {
  const names = [].concat(req.body?.sel ?? []);          // 체크된 값이 하나면 문자열, 여러 개면 배열
  const done = [], skipped = [];
  for (const n of names) (store.transition(String(n), 'restart').error ? skipped : done).push(n);
  const q = String(req.body?.q ?? ''), status = String(req.body?.status ?? '');
  const page = store.paginate(store.search(q, status), 1);
  const more = page.nextPage ? '/vms?' + new URLSearchParams({ q, status, page: page.nextPage }) : null;
  const msg = `${done.length}대 재시작 요청` + (skipped.length ? `, ${skipped.length}대 건너뜀(실행 중이 아님): ${skipped.join(', ')}` : '');
  if (done.length) res.set('HX-Trigger', JSON.stringify({ vmChanged: { names: done } }));
  send(res, part('./partials/vm-rows-response', { list: page.items, more, q, total: page.total })
            + toast(msg, skipped.length ? 'warn' : 'ok'));
});

// 4편: 요약 카드 (폴링 대상). /vms/:name보다 먼저 선언해야 'summary'가 VM 이름으로 해석되지 않는다
app.get('/vms/summary', (req, res) => render(res, './partials/summary', { sum: store.summary() }));

// ---- 3편: VM 상세 (GET) — 같은 URL이 조각과 전체 페이지를 모두 낸다 ----
app.get('/vms/:name', (req, res) => {
  const vm = store.find(req.params.name);
  res.vary('HX-Request').vary('HX-Request-Type');
  if (!vm) {
    const message = `${req.params.name}은(는) 없는 VM입니다.`;
    return wantsFragment(req) ? render(res, './partials/error', { message }, 404)
                              : render(res, './pages/not-found', { title: '페이지 없음', message }, 404);
  }
  const activity = store.activityPage(vm);
  if (wantsFragment(req)) {
    // 7편: 주소를 push하는 상세 조각에 <title>을 넣어 탭 제목도 함께 바꾼다 (htmx가 스왑 후 document.title에 적용)
    return send(res, part('./partials/doc-title', { text: `${vm.name} · VM 관리` }) + part('./partials/vm-detail', { vm, activity }));
  }
  // 7편: 주소창·새로고침·뒤로 가기로 /vms/web-01을 열면 "목록 + 상세가 열린 패널"을 한 번에 그린다.
  // 상세를 열 때 hx-push-url로 이 주소를 기록하므로, 이 주소만으로 같은 화면을 재현할 수 있어야 한다
  const page = store.paginate(store.search('', ''), 1);
  const more = page.nextPage ? '/vms?' + new URLSearchParams({ q: '', status: '', page: page.nextPage }) : null;
  render(res, './pages/vms', { title: `${vm.name} · VM 관리`, list: page.items, more, q: '', status: '', total: page.total,
                               sum: store.summary(), detail: { vm, activity } });
});

// 공통: 이름으로 VM을 찾아 req.vm에 넣는다. 없으면 404 조각
const loadVm = (req, res, next) => {
  const vm = store.find(req.params.name);
  if (!vm) return render(res, './partials/error', { message: `${req.params.name}은(는) 없는 VM입니다.` }, 404);
  req.vm = vm;
  next();
};
// 응답 끝에 "새 활동 한 줄"을 hx-partial로 덧붙이는 도우미 (활동 목록 맨 위에 afterbegin으로 삽입)
const withActivity = (vm, html) =>
  html + eta.render('./partials/activity-new', { vm, item: vm.activity[0] });
const send = (res, html, status = 200) => res.status(status).type('html').send(html);
// 5편: 토스트 알림을 OOB(hx-swap-oob="beforeend:#toasts")로 응답 끝에 덧붙인다
const toast = (msg, kind = 'ok') => eta.render('./partials/toast', { msg, kind });
const part = (view, data) => eta.render(view, { ...data, ...viewGlobals() });

// 메모: 보기(GET) · 편집 폼(GET) · 저장(PUT)
app.get('/vms/:name/memo', loadVm, (req, res) => send(res, part('./partials/memo-view', { vm: req.vm })));
app.get('/vms/:name/memo/edit', loadVm, (req, res) => send(res, part('./partials/memo-edit', { vm: req.vm, draft: req.vm.memo })));
app.put('/vms/:name/memo', loadVm, (req, res) => {
  const result = store.setMemo(req.vm, req.body?.memo);
  if (result.error) {
    // 422: 검증 실패. htmx 4는 4xx도 스왑하므로 오류 메시지가 담긴 폼이 그대로 다시 그려진다
    return send(res, part('./partials/memo-edit', { vm: req.vm, draft: req.body?.memo, error: result.error }), 422);
  }
  send(res, withActivity(req.vm, part('./partials/memo-view', { vm: req.vm })) + toast('메모를 저장했습니다.'));
});

// 태그: 추가(POST) · 삭제(DELETE) — 둘 다 태그 블록 전체를 다시 그려서 돌려준다
app.post('/vms/:name/tags', loadVm, (req, res) => {
  const result = store.addTag(req.vm, req.body?.tag);
  if (result.error) return send(res, part('./partials/tags', { vm: req.vm, draft: req.body?.tag, error: result.error }), 422);
  send(res, withActivity(req.vm, part('./partials/tags', { vm: req.vm })) + toast(`태그를 추가했습니다: ${req.body.tag.trim().toLowerCase()}`));
});
app.delete('/vms/:name/tags/:tag', loadVm, (req, res) => {
  const result = store.removeTag(req.vm, req.params.tag);
  if (result.error) return send(res, part('./partials/tags', { vm: req.vm, error: result.error }), 404);
  send(res, withActivity(req.vm, part('./partials/tags', { vm: req.vm })));
});

// 모니터링: 부분 수정(PATCH). 체크 해제된 체크박스는 아무 값도 보내지 않는다는 점에 주의
app.patch('/vms/:name', loadVm, (req, res) => {
  const on = req.body?.monitoring === 'on';
  store.setMonitoring(req.vm, on);
  send(res, withActivity(req.vm, part('./partials/monitoring', { vm: req.vm })) + toast(`모니터링을 ${on ? '켰' : '껐'}습니다.`));
});

// ---- 5편: 알림 설정 — 입력 중 검증(POST check)과 저장(PUT). 응답은 폼 전체, 클라이언트는 outerMorph ----
app.get('/vms/:name/alerts', loadVm, (req, res) =>
  send(res, part('./partials/alerts-form', { vm: req.vm, values: req.vm.alerts, errors: {}, channels: store.CHANNELS })));
app.post('/vms/:name/alerts/check', loadVm, (req, res) => {
  const r = store.checkAlerts(req.body ?? {});
  send(res, part('./partials/alerts-form', { vm: req.vm, values: r.values, errors: r.errors, channels: store.CHANNELS, dirty: true }));
});
app.put('/vms/:name/alerts', loadVm, (req, res) => {
  const r = store.saveAlerts(req.vm, req.body ?? {});
  if (!r.ok) return send(res, part('./partials/alerts-form', { vm: req.vm, values: r.values, errors: r.errors, channels: store.CHANNELS, dirty: true }), 422);
  // 13편: 서버 → 아일랜드. 같은 응답에 차트 요소를 partial + outerMorph로 실어 threshold 속성만 바꾼다
  //       (모핑이라 같은 요소가 유지되고 attributeChangedCallback으로 임계선만 다시 그린다)
  const chart = `<hx-partial hx-target="#detail-chart" hx-swap="outerMorph">${part('./partials/metric-chart', { vm: req.vm })}</hx-partial>`;
  send(res, withActivity(req.vm, part('./partials/alerts-form', { vm: req.vm, values: req.vm.alerts, errors: {}, channels: store.CHANNELS, saved: true }))
            + chart + toast('알림 설정을 저장했습니다.'));
});

// 5편: 토스트가 스스로 사라질 때 쓰는 빈 응답 (hx-swap="delete"는 응답 내용과 무관하게 요소를 지운다)
app.get('/noop', (req, res) => res.status(200).send(''));

// 활동 기록: 더 보기(GET) — "더 보기" 줄을 다음 묶음 + 새 "더 보기" 줄로 교체
app.get('/vms/:name/activity', loadVm, (req, res) => {
  const before = Number(req.query.before ?? Infinity);
  send(res, part('./partials/activity-items', { vm: req.vm, activity: store.activityPage(req.vm, before) }));
});

app.get('/vms/:name/row', (req, res) => {
  const vm = store.find(req.params.name);
  if (!vm) return res.status(200).send('');           // 이미 삭제된 행은 빈 응답으로 사라지게
  render(res, './partials/vm-row', { vm });
});

app.post('/vms/:name/:action', (req, res) => {
  const { name, action } = req.params;
  if (action !== 'restart' && action !== 'start') return render(res, './partials/error', { message: `알 수 없는 작업: ${action}` }, 400);
  const result = store.transition(name, action);
  if (result.error === 404) return render(res, './partials/error', { message: `${name}은(는) 없는 VM입니다.` }, 404);
  // 409여도 현재 상태의 행을 돌려준다. htmx 4는 4xx 응답도 스왑하므로 화면이 서버 상태와 다시 맞춰진다.
  // 4편: 상태가 바뀌었음을 알리는 이벤트. 요약 카드가 from:document로 듣고 즉시 갱신한다
  if (!result.error) res.set('HX-Trigger', JSON.stringify({ vmChanged: { name } }));
  const msg = result.error ? `${name}: 지금 상태에서는 할 수 없는 작업입니다.` : `${name} ${action === 'restart' ? '재시작' : '시작'} 요청을 보냈습니다.`;
  send(res, part('./partials/vm-row', { vm: result.vm }) + toast(msg, result.error ? 'warn' : 'ok'), result.error ?? 200);
});

app.delete('/vms/:name', (req, res) => {
  const ok = store.remove(req.params.name);
  if (!ok) return render(res, './partials/error', { message: '이미 삭제된 VM입니다.' }, 404);
  // 삭제된 행 안의 버튼은 문서에서 떨어져 나가므로, 이벤트를 받을 요소를 target으로 지정한다
  res.set('HX-Trigger', JSON.stringify({
    vmRemoved: { name: req.params.name, target: '#vm-app' },
    vmChanged: { name: req.params.name },
  }));
  // 본문은 비어 있고 OOB 토스트만 있다. OOB가 있으면 htmx 4는 빈 본문 스왑을 건너뛰므로
  // 행 삭제 버튼에 hx-swap="outerHTML swapEmpty"를 달아 "빈 내용으로 교체"를 명시한다 (5편)
  send(res, toast(`${req.params.name}을(를) 삭제했습니다.`));
});

app.post('/lab/reset', async (req, res) => {
  store.reset();
  flags.resetFlags();                                           // 16편: 플래그도 처음 상태(전부 레거시)로
  jobs.resetJobs();                                             // 21편
  await fetch((process.env.LEGACY_URL ?? 'http://localhost:3102') + '/reset', { method: 'POST', headers: { 'X-Portal-Assertion': signAssertion({ sub: 'system', role: 'operator', rid: req.id, aud: 'legacy-crm' }) } }).catch(() => {});
  res.set('HX-Refresh', 'true').status(200).send('');
});

// ---- 10편: 실시간 갱신 (SSE). 폴링 대신 서버가 바뀐 행과 요약 카드를 밀어 준다 ----
const sseLog = [];          // 최근 변경 200건 (재접속 시 Last-Event-ID 이후를 다시 보내기 위해)
let sseSeq = 0;
const sseClients = new Set();
store.bus.on('change', (ev) => {
  // 요청 처리 중에 생긴 변경이면 그 요청을 보낸 탭이 origin. 전환 완료(settled)는 타이머가 만든 변경이라 모두에게 보낸다
  const origin = ev.kind === 'settled' ? null : als.getStore()?.clientId ?? null;
  const entry = { id: ++sseSeq, ...ev, origin };
  sseLog.push(entry);
  if (sseLog.length > 200) sseLog.shift();
  for (const client of sseClients) client.send([entry]);
});
// 21편: 패치 작업 진행도 같은 SSE로. 작업 타이머가 만든 변경은 origin 없음(모두에게)
//   (AsyncLocalStorage는 setInterval 콜백에도 문맥을 이어 주므로, 종류로 구분해야 한다 — 10편과 같은 이유)
jobs.bus.on('change', (ev) => {
  // 생성은 요청한 탭에 보내지 않는다(그 탭은 HX-Location으로 상세로 이동). 취소를 포함한 나머지는 모두에게 —
  // 작업 상세는 SSE가 "소유"하는 영역이라 취소 응답은 그 영역을 건드리지 않고 토스트만 낸다(7절 측정)
  const origin = ev.kind === 'created' ? als.getStore()?.clientId ?? null : null;
  const entry = { id: ++sseSeq, names: [], job: ev.id, kind: 'job', jobKind: ev.kind, origin };
  sseLog.push(entry);
  if (sseLog.length > 200) sseLog.shift();
  for (const client of sseClients) client.send([entry]);
  if (ev.kind === 'done' || ev.kind === 'cancelled') {
    const job = jobs.findJob(ev.id);
    jobsTotal.inc({ result: ev.kind });
    jobDuration.observe({ result: ev.kind }, (job.finishedAt - job.createdAt) / 1000);
  }
});
// 한 번의 변경을 <hx-partial> 묶음으로. 사용자마다 권한(canEdit)이 다르므로 그 사용자 문맥에서 렌더링한다
function sseMessage(entries, user) {
  return als.run({ user }, () => {
    const names = [...new Set(entries.flatMap(e => e.names))];
    let html = `<hx-partial hx-target="#summary" hx-swap="innerHTML">${part('./partials/summary', { sum: store.summary() })}</hx-partial>`;
    for (const name of names) {
      const vm = store.find(name);
      html += vm
        ? `<hx-partial hx-target="#row-${name}" hx-swap="outerHTML">${part('./partials/vm-row', { vm })}</hx-partial>`
        : `<hx-partial hx-target="#row-${name}" hx-swap="delete"></hx-partial>`;   // 삭제된 VM
    }
    // 21편: 작업 목록의 행과 작업 상세를 갱신 (그 화면을 보고 있지 않으면 대상이 없어 조용히 건너뜀 — 10편 측정)
    const jobEntries = entries.filter(e => e.kind === 'job');
    for (const id of new Set(jobEntries.map(e => e.job))) {
      const job = jobs.findJob(id);
      if (!job) continue;
      const row = part('./partials/job-row', { job, p: jobs.progress(job) });
      // 새 작업: 목록 맨 위에 행을 넣고 "아직 없음" 안내 행을 지운다. 그 뒤로는 같은 id의 행을 교체
      if (jobEntries.some(e => e.job === id && e.jobKind === 'created')) {
        html += `<hx-partial hx-target="#job-empty" hx-swap="delete"></hx-partial>`
              + `<hx-partial hx-target="#job-table tbody" hx-swap="afterbegin">${row}</hx-partial>`;
      } else {
        html += `<hx-partial hx-target="#job-row-${id}" hx-swap="outerHTML">${row}</hx-partial>`;
      }
      html += `<hx-partial hx-target="#job-${id}" hx-swap="outerHTML">${part('./partials/job-detail', { job, p: jobs.progress(job), steps: jobs.STEPS })}</hx-partial>`;
    }
    return html;
  });
}
const sseFrame = (id, html) => `id: ${id}\n` + html.split('\n').map(l => `data: ${l}`).join('\n') + '\n\n';
app.get('/events', (req, res) => {
  res.set({ 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', 'X-Accel-Buffering': 'no' });
  res.flushHeaders();
  const user = req.user;
  // 자기가 일으킨 변경은 빼고 보낸다. 그 탭은 자기 요청의 응답으로 이미 화면을 바꾸고 있으며,
  // SSE가 먼저 도착해 행을 바꿔 버리면 원래 응답의 대상이 문서에서 떨어져 htmx가 응답(토스트 포함)을 버린다
  const client = { clientId: req.clientId, send: (entries) => {
    const mine = entries.filter(e => !e.origin || e.origin !== req.clientId);
    if (mine.length) res.write(sseFrame(entries.at(-1).id, sseMessage(mine, user)));
  } };
  // 재접속이면 놓친 변경을 다시 보낸다. 처음 접속이면 지금 요약만 보낸다
  const last = Number(req.get('Last-Event-ID'));
  const missed = Number.isFinite(last) && last > 0 ? sseLog.filter(e => e.id > last) : [];
  if (missed.length) client.send(missed);
  else res.write(sseFrame(sseSeq, sseMessage([{ names: [] }], user)));
  sseClients.add(client);
  const ping = setInterval(() => res.write(': ping\n\n'), 15000);   // 프록시가 유휴 연결을 끊지 않게
  req.on('close', () => { clearInterval(ping); sseClients.delete(client); });
});
app.get('/lab/sse-clients', (req, res) => res.type('text').send(String(sseClients.size)));

// ---- 13편: 차트(아일랜드)가 고른 시점 전후 1분의 활동. 요청은 htmx 영역이 metric:select 이벤트로 보낸다 ----
app.get('/vms/:name/activity/window', loadVm, (req, res) => {
  const t = Number(req.query.t);
  if (!Number.isFinite(t)) return send(res, '<p class="muted">시점이 올바르지 않습니다.</p>', 422);
  const point = store.metrics(req.vm).points.find(p => p.t === t);
  render(res, './partials/activity-window', { vm: req.vm, t, cpu: point?.cpu ?? null, items: store.activityWindow(req.vm, t) });
});

// ---- 10편: 활동 기록 폴링 + hx-ptag. 바뀐 게 없으면 304로 스왑을 건너뛴다 ----
app.get('/vms/:name/activity/live', loadVm, (req, res) => {
  const version = store.activityVersion(req.vm);
  res.set('HX-PTag', version);
  if (req.get('HX-PTag') === version) return res.status(304).end();
  render(res, './partials/activity-live', { vm: req.vm, activity: store.activityPage(req.vm), version });
});

// ---- 15편: 패턴 C. 게이트웨이(BFF) — 다른 팀 서비스의 HTML 조각을 포털 셸에 조합 ----
// 브라우저는 /billing/... 만 안다. 포털이 인증·권한(앞의 미들웨어)을 끝낸 뒤 업스트림에 대신 묻고,
// htmx 부분 요청이면 조각을 그대로, 전체 페이지 요청(주소창·부스트)이면 포털 레이아웃에 끼워서 돌려준다
const UPSTREAMS = {
  billing: { url: process.env.BILLING_URL ?? 'http://localhost:3101', title: '청구' },
};
const GATEWAY_TOKEN = process.env.GATEWAY_TOKEN ?? 'lab-gateway-secret';
const PASS_REQ = ['hx-request', 'hx-request-type', 'hx-target', 'hx-source', 'hx-current-url', 'hx-boosted', 'hx-history-restore-request'];
app.all('/billing/{*rest}', async (req, res) => {
  const up = UPSTREAMS.billing;
  const path = req.originalUrl.slice('/billing'.length) || '/';
  const headers = {
    // 17편: 고정 공유 비밀 + 평문 사용자 헤더 → 서명된 짧은 수명의 신원 주장 하나 (대상 서비스 지정)
    'X-Portal-Assertion': signAssertion({ sub: req.user.id, role: req.user.role, rid: req.id, aud: 'billing' }),
    'X-Forwarded-Prefix': '/billing',                // 업스트림이 링크를 공개 경로로 만들 수 있게
    'X-Request-ID': req.id, Accept: 'text/html',
  };
  for (const h of PASS_REQ) if (req.get(h)) headers[h] = req.get(h);
  let body;
  if (!['GET', 'HEAD'].includes(req.method)) {
    body = new URLSearchParams(req.body ?? {}).toString();
    headers['Content-Type'] = 'application/x-www-form-urlencoded';
  }
  let upRes, html;
  try {
    upRes = await fetch(up.url + path, { method: req.method, headers, body, signal: AbortSignal.timeout(5000) });
    html = await upRes.text();
  } catch (e) {
    // 업스트림 장애는 포털 전체 장애가 되지 않게: 해당 영역만 오류 조각으로
    console.error(`GATEWAY billing 실패 rid=${req.id.slice(0, 8)} ${e.name}: ${e.message}`);
    const msg = `<div class="box"><p class="field-error">${up.title} 서비스에 연결할 수 없습니다. 잠시 후 다시 시도하세요. (요청 ID ${req.id.slice(0, 8)})</p></div>`;
    return wantsFragment(req) ? send(res, msg, 502) : render(res, './pages/composed', { title: up.title, fragment: msg }, 502);
  }
  for (const [k, v] of upRes.headers) if (k.toLowerCase().startsWith('hx-')) res.set(k, v);   // HX-Trigger 등은 그대로
  if (wantsFragment(req)) return send(res, html, upRes.status);
  render(res, './pages/composed', { title: up.title, fragment: html }, upRes.status);
});

// ---- 16편: 패턴 D. 점진적 대체 (스트랭글러 피그) ----
// /customers/* 는 원래 레거시 CRM이 전부 담당한다. 경로마다 기능 플래그로 "새 구현(포털 htmx)"에 조금씩 넘긴다.
const LEGACY = process.env.LEGACY_URL ?? 'http://localhost:3102';
async function legacyFetch(req, method, path, { body, type } = {}) {
  const headers = {
    'X-Portal-Assertion': signAssertion({ sub: req.user.id, role: req.user.role, rid: req.id, aud: 'legacy-crm' }),
    'X-Request-ID': req.id,
  };
  if (type) headers['Content-Type'] = type;
  return fetch(LEGACY + path, { method, headers, body, redirect: 'manual', signal: AbortSignal.timeout(5000) });
}
const legacyJson = async (req, path) => {
  const r = await legacyFetch(req, 'GET', path);
  if (!r.ok) throw Object.assign(new Error(`legacy ${r.status}`), { status: r.status });
  return r.json();
};
// 운영자만 ?ff=legacy|new로 이 브라우저의 구현을 강제할 수 있다 (쿠키에 저장, ?ff=auto로 해제)
function ffOverride(req, res) {
  const q = String(req.query.ff ?? '');
  if (req.user.role === 'operator' && ['legacy', 'new', 'auto'].includes(q)) {
    res.set('Set-Cookie', q === 'auto' ? 'ff=; Path=/; Max-Age=0' : `ff=${q}; Path=/; SameSite=Lax`);
    return q === 'auto' ? null : q;
  }
  return parseCookies(req.headers.cookie).ff ?? null;
}
// 레거시 응답을 그대로 전달 (자기 레이아웃을 가진 전체 페이지)
async function passLegacy(req, res, key) {
  const r = await legacyFetch(req, 'GET', req.path);
  flags.count(key, 'legacy'); flagServed.inc({ flag: key, impl: 'legacy' });
  res.status(r.status).set({ 'X-Served-By': 'legacy', 'Content-Type': r.headers.get('content-type') ?? 'text/html' }).send(await r.text());
}
// 새 구현이 쓰는 데이터: 고객사 정보는 레거시(데이터 주인)의 JSON API, VM 목록은 포털 저장소
async function customerView(req, id) {
  const c = await legacyJson(req, `/api/customers/${id}`);
  const vms = store.search('', '').filter(v => v.customer === c.name);
  return { c, vms };
}

app.get('/customers', async (req, res, next) => {
  try {
    const d = flags.decide('customers.list', req.user, ffOverride(req, res));
    res.set('X-Flag-Reason', d.reason);              // 왜 이쪽으로 왔는지 (디버깅용)
    if (d.impl === 'legacy') return await passLegacy(req, res, 'customers.list');
    const list = await legacyJson(req, '/api/customers');
    const counts = Object.fromEntries(list.map(c => [c.name, store.search('', '').filter(v => v.customer === c.name).length]));
    flags.count('customers.list', 'new'); flagServed.inc({ flag: 'customers.list', impl: 'new' });
    res.set('X-Served-By', 'new');
    render(res, './pages/customers', { title: '고객사', list, counts });
  } catch (e) { next(e); }
});

app.get('/customers/:id', async (req, res, next) => {
  try {
    const id = Number(req.params.id);
    const d = flags.decide('customers.detail', req.user, ffOverride(req, res));
    res.set('X-Flag-Reason', d.reason);
    if (d.impl === 'legacy') {
      await passLegacy(req, res, 'customers.detail');
      // 그림자 비교: 사용자는 레거시를 보고, 뒤에서 새 구현이 같은 화면의 핵심 값을 계산해 비교한다
      if (d.shadow) {
        customerView(req, id).then(({ c, vms }) => {
          const diff = c.vmCount === vms.length ? null : `VM 수: 레거시 ${c.vmCount} / 새 구현 ${vms.length}`;
          flags.recordShadow({ key: 'customers.detail', id, name: c.name, ok: !diff, diff, rid: req.id.slice(0, 8) });
          shadowCompare.inc({ flag: 'customers.detail', result: diff ? 'mismatch' : 'match' });   // 20편: 불일치율 지표
        }).catch(e => { flags.recordShadow({ key: 'customers.detail', id, ok: false, diff: `새 구현 오류: ${e.message}`, rid: req.id.slice(0, 8) });
                        shadowCompare.inc({ flag: 'customers.detail', result: 'error' }); });
      }
      return;
    }
    const { c, vms } = await customerView(req, id);
    flags.count('customers.detail', 'new'); flagServed.inc({ flag: 'customers.detail', impl: 'new' });
    res.set('X-Served-By', 'new');
    render(res, './pages/customer', { title: c.name, c, vms, labels: store.STATUS_LABEL });
  } catch (e) {
    if (e.status === 404) return render(res, './partials/error', { message: '고객사를 찾을 수 없습니다.' }, 404);
    next(e);
  }
});

// 쓰기: 레거시 폼(전체 새로고침)은 레거시로 그대로 보낸다. 303 Location도 그대로 전달
app.post('/customers/:id/memo', async (req, res) => {
  const r = await legacyFetch(req, 'POST', req.path, { body: new URLSearchParams(req.body ?? {}).toString(), type: 'application/x-www-form-urlencoded' });
  res.status(r.status).set('X-Served-By', 'legacy');
  if (r.headers.get('location')) res.set('Location', r.headers.get('location'));
  res.send(await r.text());
});
// 새 구현의 메모 저장(htmx): 같은 데이터 주인(레거시 JSON API)에 쓴다. 저장소가 하나라 두 화면이 늘 같은 값을 본다
app.patch('/customers/:id/memo', async (req, res) => {
  const r = await legacyFetch(req, 'PATCH', `/api/customers/${req.params.id}`, { body: JSON.stringify({ memo: String(req.body?.memo ?? '') }), type: 'application/json' });
  const c = await r.json();
  res.set('X-Served-By', 'new');
  send(res, part('./partials/customer-memo', { c }) + toast('메모를 저장했습니다. (레거시 화면에도 같은 값)'));
});

// 플래그 관리 화면 (운영자만 변경 — 6편 역할 미들웨어가 PUT을 막는다)
app.get('/lab/flags', (req, res) => render(res, './pages/flags', { title: '기능 플래그', list: flags.listFlags(), shadow: flags.shadowResults() }));
app.put('/lab/flags/:key', (req, res) => {
  if (!flags.setFlag(req.params.key, req.body ?? {})) return send(res, '<p class="field-error">잘못된 값</p>', 422);
  console.log(`FLAG   ${req.params.key} → mode=${req.body.mode} percent=${req.body.percent ?? 0} by=${req.user.id}`);
  render(res, './partials/flags-table', { list: flags.listFlags(), shadow: flags.shadowResults() });
});

// ---- 17편: 엄격한 CSP + hx-csp 확장 데모 (unsafe-eval 없이 hx-on, 주입된 htmx 속성 차단) ----
const strictCsp = (nonce) => [
  "default-src 'self'", `script-src 'self' 'nonce-${nonce}'`, "style-src 'self' 'unsafe-inline'",
  "connect-src 'self'", "object-src 'none'", "base-uri 'self'", "frame-ancestors 'none'",
].join('; ');
app.get('/lab/csp', (req, res) => {
  res.set('Content-Security-Policy', strictCsp(res.locals.nonce));
  res.type('html').send(eta.render('./pages/csp-demo', { nonce: res.locals.nonce, ext: req.query.ext !== 'off', asset }));
});
// 각 조각 응답은 자기 CSP(새 nonce)를 갖고, 서버가 만든 htmx 요소에 그 nonce를 찍는다.
// hx-csp는 같은 출처 응답의 nonce를 페이지 nonce로 바꿔 끼우고(승격), 페이지 nonce가 그대로 들어 있으면 지운다(도난 방지)
app.get('/lab/csp/echo', (req, res) => {
  const n = res.locals.nonce;
  res.set('Content-Security-Policy', strictCsp(n)).type('html')
    .send(`<p>서버 조각 ${new Date().toTimeString().slice(0, 8)}</p><button id="again" hx-get="/lab/csp/echo" hx-target="#out" hx-nonce="${n}">다시 (서버가 찍은 nonce)</button>`);
});
app.get('/lab/csp/inject', (req, res) => {
  // 이스케이프 실수로 사용자 입력이 HTML로 들어갔다고 가정한 조각: nonce 없는 htmx 속성
  res.set('Content-Security-Policy', strictCsp(res.locals.nonce)).type('html')
    .send(`<p>주입된 조각</p><button id="evil" hx-get="/lab/csp/pwn" hx-target="#out">주입된 hx-get</button><button id="evil2" hx-on:click="document.title='pwned'">주입된 hx-on</button>`);
});
app.get('/lab/csp/stolen', (req, res) => {
  // 공격자가 어떻게든 페이지 nonce를 알아내 찍어 보낸 경우
  res.set('Content-Security-Policy', strictCsp(res.locals.nonce)).type('html')
    .send(`<button id="stolen" hx-get="/lab/csp/pwn" hx-target="#out" hx-nonce="${String(req.query.n ?? '').replace(/[^A-Za-z0-9+/=]/g, '')}">훔친 nonce</button>`);
});
app.get('/lab/csp/pwn', (req, res) => send(res, '<p class="field-error">이 요청이 나가면 안 된다</p>'));

// ---- 14편: 패턴 B. React SPA(운영 콘솔)와 그 안에 끼워 넣을 서버 조각 ----
// SPA 안 "실시간 요약" 영역용 조각. 10편의 SSE를 그대로 쓴다 (요약 카드 #summary를 서버가 밀어 줌)
app.get('/console/fragments/live-summary', (req, res) =>
  render(res, './partials/console-live-summary', { sum: store.summary() }));
// SPA 대체 라우트: /console 아래 모든 주소에 index.html (주소 해석은 브라우저의 React Router가 한다)
// (실습: ?hxhistory=on이면 htmx history를 켠 채로 보내 7절의 충돌을 재현한다)
app.get(['/console', '/console/{*rest}'], (req, res) => {
  const file = join(here, '..', 'public', 'console', 'index.html');
  // 17편: 정적 index.html의 인라인 import map에 이 응답의 nonce를 붙여야 CSP를 통과한다
  let html = readFileSync(file, 'utf8').replace('<script type="importmap">', `<script type="importmap" nonce="${res.locals.nonce}">`);
  // 20편: 콘솔 index.html이 가리키는 고정 경로를 매니페스트의 해시 URL로 바꿔 낸다
  html = html.replace(/(["'])\/(vendor\/htmx\/[\w./-]+|js\/[\w./-]+|css\/[\w.-]+|shared\/[\w.-]+)\1/g, (m, q, p) => q + asset(p) + q)
             .replaceAll('/islands/react/react-islands.js', asset('islands/react.js'))
             .replaceAll('/islands/vue/vue-islands.js', asset('islands/vue.js'));
  if (req.query.hxhistory === 'on') html = html.replace('"history": false', '"history": true');
  res.type('html').send(html);
});

// ---- 20편: 상태 확인(Kubernetes 프로브)과 실사용자 측정 수신 ----
const startedAt = new Date();
app.get('/healthz', (req, res) => res.type('text').send('ok'));          // 살아 있음 (liveness)
app.get('/readyz', (req, res) => {                                     // 받을 준비 됨 (readiness): 운영에서는 매니페스트가 있어야 자산 URL이 맞다
  const ready = !USE_DIST || Object.keys(MANIFEST).length > 0;
  res.status(ready ? 200 : 503).json({ ready, startedAt, assets: Object.keys(MANIFEST).length });
});
app.post('/rum', express.json({ limit: '16kb', type: ['application/json', 'text/plain'] }), (req, res) => {
  const items = Array.isArray(req.body) ? req.body.slice(0, 20) : [];
  for (const m of items) {
    const page = /^\/[\w/:.-]{0,60}$/.test(m?.page ?? '') ? m.page : 'other';      // 라벨 값은 정해진 모양만
    const rating = ['good', 'needs-improvement', 'poor'].includes(m?.rating) ? m.rating : 'unknown';
    const v = Number(m?.value);
    if (!Number.isFinite(v) || v < 0) continue;
    if (m.name === 'CLS') webVitalsCls.observe({ page, rating }, v);
    else if (['LCP', 'INP', 'FCP', 'TTFB'].includes(m.name)) webVitals.observe({ name: m.name, page, rating }, v / 1000);
  }
  res.status(204).end();
});

// ---- 21편: 종합 실습 — 패치 작업 ----
app.get('/jobs', (req, res) => {
  const list = jobs.listJobs().map(job => ({ job, p: jobs.progress(job) }));
  if (wantsFragment(req)) return render(res, './partials/job-table', { list });
  render(res, './pages/jobs', { title: '패치 작업', list });
});
// 만들기: VM 관리 화면의 선택(9편)에서. 성공하면 201 + HX-Location으로 작업 상세로 이동(6편 VM 등록과 같은 방식)
app.post('/jobs', (req, res) => {
  const r = jobs.createJob([].concat(req.body?.sel ?? []), req.user);
  if (r.error) {
    return res.status(r.status).set({ 'HX-Retarget': '#toasts', 'HX-Reswap': 'beforeend' })
      .type('html').send(part('./partials/toast-item', { msg: r.error, kind: 'warn' }));
  }
  res.status(201).set('HX-Location', JSON.stringify({ path: `/jobs/${r.job.id}`, target: 'body' })).end();
});
app.get('/jobs/:id', (req, res) => {
  const job = jobs.findJob(req.params.id);
  if (!job) return render(res, './partials/error', { message: '작업을 찾을 수 없습니다.' }, 404);
  const data = { job, p: jobs.progress(job), steps: jobs.STEPS };
  if (wantsFragment(req)) return render(res, './partials/job-detail', data);
  render(res, './pages/job', { title: `패치 작업 ${job.id}`, ...data });
});
app.post('/jobs/:id/cancel', (req, res) => {
  const r = jobs.cancelJob(req.params.id);
  if (r.error) {
    return res.status(r.status).set({ 'HX-Retarget': '#toasts', 'HX-Reswap': 'beforeend' })
      .type('html').send(part('./partials/toast-item', { msg: r.error, kind: 'warn' }));
  }
  // 작업 상세는 SSE가 갱신한다. 응답은 토스트 영역으로만 (응답과 SSE가 같은 요소를 바꾸면 경쟁 — 7절)
  res.set({ 'HX-Retarget': '#toasts', 'HX-Reswap': 'beforeend' })
     .type('html').send(part('./partials/toast-item', { msg: `${r.job.id} 작업을 취소했습니다.`, kind: 'warn' }));
});

// ---- 6편: 로그인·세션 ----
app.get('/login', (req, res) => render(res, './pages/login', { title: '로그인', users: USERS, next: safeNext(req.query.next, `${req.protocol}://${req.get('host')}`) }));
app.post('/login', (req, res) => {
  const userId = String(req.body?.user ?? '');
  if (!USERS[userId]) return render(res, './pages/login', { title: '로그인', users: USERS, next: '/vms', error: '사용자를 고르세요.' }, 422);
  const sid = createSession(userId);
  res.set('Set-Cookie', `sid=${sid}; HttpOnly; SameSite=Lax; Path=/${COOKIE_SECURE}`);
  res.redirect(303, safeNext(req.body?.next, `${req.protocol}://${req.get('host')}`));
});
app.get('/logout', (req, res) => {
  destroySession(parseCookies(req.headers.cookie).sid);
  res.set('Set-Cookie', `sid=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0${COOKIE_SECURE}`).redirect('/login');
});
// 실습 도구: 화면을 새로고침하지 않고 역할만 바꿔 "오래된 화면" 상황을 만든다
app.post('/session/role', (req, res) => {
  const s = getSession(req.user.sid);
  s.role = s.role === 'operator' ? 'viewer' : 'operator';
  req.user.role = s.role;
  send(res, eta.render('./partials/whoami', { user: req.user, roleLabel: ROLE_LABEL, note: '역할만 바뀌었다. 화면은 그대로' }));
});
app.post('/session/expire', (req, res) => {
  destroySession(req.user.sid);
  send(res, eta.render('./partials/whoami', { user: req.user, roleLabel: ROLE_LABEL, expired: true }));
});

// ---- 6편: 장애 주입 (클라이언트 오류 처리 실습) ----
app.get('/lab/fault', async (req, res) => {
  const kind = String(req.query.kind ?? '');
  if (kind === '500') throw new Error('일부러 낸 서버 오류');             // Express 5가 오류 처리기로 전달
  if (kind === '503') return res.status(503).set('Retry-After', '30').type('html').send('<p>점검 중입니다 (503)</p>');
  if (kind === 'slow') { await new Promise(r => setTimeout(r, 5000)); return send(res, '<p>5초 뒤 도착한 응답</p>'); }
  if (kind === 'drop') return req.socket.destroy();                       // 응답 없이 연결을 끊음 → 네트워크 오류
  if (kind === '302') return res.redirect('/login');                      // 하지 말아야 할 패턴 (htmx 요청에 302)
  send(res, '<p>정상 응답</p>');
});

// ⑤-2 3편: 스왑 실험실
let pieceNo = 0;
app.get('/lab/swap', (req, res) => render(res, './pages/swap-lab', { title: '스왑 실험실' }));
app.get('/lab/swap/stage', (req, res) => { pieceNo = 0; send(res, part('./partials/swap-stage', {})); });
app.get('/lab/swap/piece', (req, res) => {
  pieceNo += 1;
  const style = String(req.query.style ?? 'innerHTML');
  send(res, part('./partials/swap-piece', { no: pieceNo, style, keepId: style === 'outerHTML' || style === 'outerMorph' }));
});

// ⑤ 랩 점검 페이지: 서버가 받은 헤더를 그대로 보여 준다
app.get('/lab', (req, res) => render(res, './pages/lab', { title: '랩 점검' }));
// 5편: 랩 점검 패널만 다시 그리기 (hx-preserve 실험)
let panelNo = 0;
app.get('/lab/panel', (req, res) => render(res, './partials/lab-panel', { no: ++panelNo }));
// 5편: htmx를 모르는 "레거시" 페이지. 포털은 hx-select로 필요한 부분만 가져간다
app.get('/legacy/notice', (req, res) => render(res, './pages/legacy-notice', {}));
app.get('/lab/echo', (req, res) => {
  const headers = Object.entries(req.headers)
    .filter(([k]) => k.startsWith('hx-') || k === 'accept')
    .sort(([a], [b]) => a.localeCompare(b));
  res.vary('HX-Request');
  render(res, './partials/echo', { headers, at: new Date().toLocaleTimeString('ko-KR') });
});

// ⑥ 데이터 API (JSON) — 다음 편들에서 React·Vue 아일랜드가 사용
// 11편: 아일랜드용 데이터 API. 화면용 HTML 엔드포인트(/vms/...)와 경로를 나눈다 (1편 "데이터 API와 애플리케이션 API")
app.get('/api/vms/:name/metrics', (req, res) => {
  const vm = store.find(req.params.name);
  if (!vm) return res.status(404).json({ error: 'not_found', vm: req.params.name });
  res.set('Cache-Control', 'no-store').json(store.metrics(vm));
});
app.get('/api/vms', (req, res) => res.json(store.search(String(req.query.q ?? ''), String(req.query.status ?? ''))));

// ⑦ 404와 오류 처리: htmx 요청이면 조각, 아니면 전체 페이지
app.use((req, res) => {
  const message = `${req.method} ${req.path} 경로가 없습니다.`;
  if (req.htmx) return render(res, './partials/error', { message }, 404);
  render(res, './pages/not-found', { title: '페이지 없음', message }, 404);
});
app.use((err, req, res, next) => {          // Express 5는 async 핸들러의 예외도 여기로 전달한다
  console.error(err);
  render(res, './partials/error', { message: '서버 오류가 발생했습니다.' }, 500);
});

// 10편: WebSocket (운영 메모 채널). 같은 HTTP 서버의 upgrade 요청을 받아 세션을 확인한 뒤 연결한다
const server = app.listen(PORT, () => console.log(`▶ http://localhost:${PORT}  (htmx 포털 랩, NODE_ENV=${process.env.NODE_ENV ?? 'development'})`));

const wss = new WebSocketServer({ noServer: true });
server.on('upgrade', (req, socket, head) => {
  const session = getSession(parseCookies(req.headers.cookie).sid);
  if (new URL(req.url, 'http://x').pathname !== '/ws/ops' || !session) {
    socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n'); return socket.destroy();
  }
  wss.handleUpgrade(req, socket, head, (ws) => {
    ws.user = { id: session.userId, name: USERS[session.userId].name };
    wss.emit('connection', ws);
  });
});
wss.on('connection', (ws) => {
  console.log(`WS     /ws/ops 연결 user=${ws.user.id} (접속 ${wss.clients.size}명)`);
  ws.on('message', (raw) => {
    let msg;
    try { msg = JSON.parse(raw); } catch { return; }       // hx-ws:send는 {...폼 값, headers}를 JSON으로 보낸다
    const text = String(msg.message ?? '').trim().slice(0, 200);
    if (!text) return;
    console.log(`WS     메시지 user=${ws.user.id} source=${msg.headers?.['HX-Source'] ?? '-'} "${text}"`);
    // 받은 글은 반드시 이스케이프한 뒤 HTML로 방송한다 (Eta 템플릿이 처리)
    const html = eta.render('./partials/ops-line', { who: ws.user.name, text, at: new Date() });
    for (const c of wss.clients) if (c.readyState === 1) c.send(html);
  });
});

// 20편: 지표 전용 포트. 업무 포트(PORT)와 분리해 클러스터 안의 수집기(Prometheus)만 접근하게 한다
const METRICS_PORT = Number(process.env.METRICS_PORT ?? 9464);
createServer(async (req, res) => {
  if (req.url !== '/metrics') { res.statusCode = 404; return res.end(); }
  res.setHeader('Content-Type', metrics.contentType);
  res.end(await metrics.metrics());
}).on('error', (e) => console.error(`[metrics] 지표 포트를 열 수 없음: ${e.message}`))
  .listen(METRICS_PORT, () => console.log(`▶ 지표 http://localhost:${METRICS_PORT}/metrics`));
// SSE 접속 수는 지표를 읽는 순간 계산
new client.Gauge({ name: 'portal_sse_connections', help: '10편 SSE 연결 수', registers: [metrics], collect() { this.set(sseClients.size); } });
