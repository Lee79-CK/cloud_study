import { StrictMode, useEffect, useState, version } from 'react';
import { defineReactElement } from './define-react-element.jsx';

function HelloIsland({ who }) {
  const [count, setCount] = useState(0);
  return (
    <div>
      <p>{who} {version}이(가) 이 상자를 소유합니다.</p>
      <button onClick={() => setCount(c => c + 1)}>클릭 {count}</button>
    </div>
  );
}

// 11편: 데이터 API(JSON)를 스스로 읽어 그리는 CPU 차트. 서버가 그린 HTML(htmx 영역) 안에 박힌 "섬"이다
// 13편: 이벤트 브리지
//  - 아일랜드 → 바깥: 점을 누르면 호스트 요소에서 metric:select 이벤트(bubbles)를 발생시킨다
//  - 바깥 → 아일랜드: 서버의 HX-Trigger로 오는 vmChanged를 document에서 듣고 즉시 다시 읽는다
//  - 서버 → 아일랜드: threshold 속성(서버가 partial + outerMorph로 바꿈)을 그대로 prop으로 받는다
function MetricChart({ vm, threshold, host, intervalMs = 5000 }) {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [selected, setSelected] = useState(null);
  useEffect(() => {
    const ac = new AbortController();
    async function load() {
      try {
        const res = await fetch(`/api/vms/${encodeURIComponent(vm)}/metrics`, {
          headers: { Accept: 'application/json' }, signal: ac.signal,
        });
        if (res.status === 401) { setError('세션이 만료되었습니다. 새로고침 후 다시 로그인하세요.'); return; }
        if (!res.ok) { setError(`데이터를 불러오지 못했습니다 (${res.status})`); return; }
        setData(await res.json()); setError(null);
      } catch (e) {
        if (e.name !== 'AbortError') setError('네트워크 오류');
      }
    }
    load();
    const timer = setInterval(load, intervalMs);
    // htmx 영역에서 온 신호: 이 VM의 상태가 바뀌었으면 5초를 기다리지 않고 바로 다시 읽기
    const onChanged = (e) => { if (e.detail?.name === vm) load(); };
    document.addEventListener('vmChanged', onChanged);
    return () => { clearInterval(timer); ac.abort(); document.removeEventListener('vmChanged', onChanged); };
  }, [vm, intervalMs]);
  useEffect(() => setSelected(null), [vm]);           // 다른 VM이 되면 선택 해제

  if (error) return <p className="island-error">{error}</p>;
  if (!data) return <p className="muted">불러오는 중…</p>;
  const W = 300, H = 70, pts = data.points, X = (i) => (i / (pts.length - 1)) * W, Y = (v) => H - (v / 100) * H;
  const xy = pts.map((p, i) => `${X(i)},${Y(p.cpu)}`).join(' ');
  const last = pts.at(-1).cpu;
  const th = threshold != null && threshold !== '' ? Number(threshold) : null;
  function pick(i) {
    const p = pts[i];
    setSelected(p.t);
    // 호스트(라이트 DOM에 있는 <metric-chart>)에서 발생시키므로 섀도 경계 문제 없이 바깥으로 버블링된다
    host.dispatchEvent(new CustomEvent('metric:select', { bubbles: true, composed: true, detail: { vm, t: p.t, cpu: p.cpu } }));
  }
  const si = selected == null ? -1 : pts.findIndex(p => p.t === selected);
  return (
    <figure className="metric-chart" aria-label={`${vm} CPU 사용률`}>
      <svg viewBox={`0 0 ${W} ${H}`} width="100%" height={H} role="img" aria-hidden="true">
        {th != null && <line className="th" x1="0" x2={W} y1={Y(th)} y2={Y(th)} />}
        <polyline points={xy} fill="none" stroke="currentColor" strokeWidth="2" />
        {si >= 0 && <circle className="sel" cx={X(si)} cy={Y(pts[si].cpu)} r="4" />}
        {pts.map((p, i) => (
          <rect key={p.t} className="hit" x={X(i) - W / pts.length / 2} y="0" width={W / pts.length} height={H}
                data-i={i} onClick={() => pick(i)} />
        ))}
      </svg>
      <figcaption>CPU {last}%{th != null ? ` · 임계값 ${th}%` : ''} · 최근 {pts.length * data.step / 60}분 · 점을 누르면 그 시점의 활동 · React {version}</figcaption>
    </figure>
  );
}

// 12편: 웹 컴포넌트로 정의. 서버 템플릿은 <metric-chart vm="web-01">처럼 태그만 쓰면 된다
const CHART_CSS = `
  /* 15편: 색은 포털 디자인 토큰(CSS 변수)을 쓴다. 변수는 섀도 경계를 넘어 상속된다 */
  :host { display: block; color: var(--portal-accent, #3aa6c9); }
  figure { margin: 0; }
  figcaption { font: 12px/1.4 var(--portal-font, system-ui, sans-serif); color: var(--portal-muted, #8a93a6); }
  .island-error { color: #c8402f; font: 13px system-ui, sans-serif; margin: 0; }
  .muted { color: #8a93a6; font: 13px system-ui, sans-serif; margin: 0; }
  .th { stroke: var(--portal-danger, #c8402f); stroke-dasharray: 4 3; stroke-width: 1; }
  .sel { fill: #f5b942; }
  .hit { fill: transparent; cursor: pointer; }
`;
defineReactElement('metric-chart', (el) => <MetricChart vm={el.getAttribute('vm')} threshold={el.getAttribute('threshold')} host={el} />, {
  attributes: ['vm', 'threshold'], css: CHART_CSS,
});
defineReactElement('hello-react', (el) => <HelloIsland who={el.getAttribute('who') ?? 'React'} />, {
  attributes: ['who'],
  css: ':host { display: block; } p { margin: 0 0 .4rem; } button { font: inherit; padding: .2rem .6rem; }',
});
