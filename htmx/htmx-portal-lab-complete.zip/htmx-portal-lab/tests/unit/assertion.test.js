import { test } from 'node:test';
import assert from 'node:assert/strict';
import { signAssertion, verifyAssertion } from '../../apps/server/src/assertion.js';

test('정상 토큰 검증', () => {
  const t = signAssertion({ sub: 'kim', role: 'operator', rid: 'r1', aud: 'billing' });
  const v = verifyAssertion(t, 'billing');
  assert.equal(v.ok, true);
  assert.equal(v.claims.sub, 'kim');
});

test('본문 변조 → bad-signature', () => {
  const [body, sig] = signAssertion({ sub: 'kim', role: 'viewer', rid: 'r1', aud: 'billing' }).split('.');
  const claims = JSON.parse(Buffer.from(body, 'base64url').toString());
  claims.role = 'operator';
  const forged = Buffer.from(JSON.stringify(claims)).toString('base64url') + '.' + sig;
  assert.equal(verifyAssertion(forged, 'billing').reason, 'bad-signature');
});

test('만료·대상 불일치·누락', () => {
  assert.equal(verifyAssertion(signAssertion({ sub: 'kim', role: 'operator', rid: 'r', aud: 'billing' }, -1), 'billing').reason, 'expired');
  assert.equal(verifyAssertion(signAssertion({ sub: 'kim', role: 'operator', rid: 'r', aud: 'legacy-crm' }), 'billing').reason, 'wrong-audience');
  assert.equal(verifyAssertion(undefined, 'billing').reason, 'missing');
});
