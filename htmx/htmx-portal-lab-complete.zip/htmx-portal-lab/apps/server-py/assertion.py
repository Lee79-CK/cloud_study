"""17편: 게이트웨이 → 업스트림 신원 주장 (Express 쪽 assertion.js와 같은 형식: base64url(JSON).base64url(HMAC-SHA256))"""
import base64
import hashlib
import hmac
import json
import os
import time

KEY = os.environ.get("ASSERTION_KEY", "lab-assertion-key-change-me").encode()


def _b64u(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).decode().rstrip("=")


def sign_assertion(sub: str, role: str, rid: str, aud: str, ttl: int = 30) -> str:
    now = int(time.time())
    body = _b64u(json.dumps({"sub": sub, "role": role, "rid": rid, "aud": aud, "iat": now, "exp": now + ttl},
                            separators=(",", ":"), ensure_ascii=False).encode())
    sig = _b64u(hmac.new(KEY, body.encode(), hashlib.sha256).digest())
    return f"{body}.{sig}"
