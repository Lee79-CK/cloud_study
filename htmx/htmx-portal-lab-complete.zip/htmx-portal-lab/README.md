# HTMX 포털 랩 — 통합 실습 저장소 (HTMX로 React·Vue 웹사이트 통합하기, 1~22편)

htmx 4 하이퍼미디어 포털에 React·Vue를 함께 쓰는 MSP 운영 포털 실습 저장소다.
같은 화면과 같은 URL을 **Express(Node)**와 **FastAPI(Python)** 두 서버로 구현했고, 두 서버가 같은 HTML 구조를 내는지 계약 테스트로 확인한다.
편별 변경 기록은 `docs/EPISODES.md`, 측정으로 바로잡은 내용은 `docs/FINDINGS.md`에 있다.

## 요구 사항
- Node.js 22.22 이상 (권장: Node.js 26 LTS). react-router 8.5.1이 22.22 이상을 요구한다
- Python 3.11 이상 (FastAPI 서버·테스트용. python-multipart 0.0.33, websockets 17.4가 3.11 이상 요구)
- E2E 테스트: Playwright가 쓰는 Chromium (`npx playwright install chromium`)

## 빠른 시작
```bash
npm ci                      # 의존성 설치 + htmx·web-vitals를 apps/server/public/vendor로 복사 (postinstall)
npm run build               # 공유 React 런타임·아일랜드·운영 콘솔 빌드 + 자산 파이프라인(해시 이름·매니페스트·사전 압축)
npm run dev                 # 포털(Express) 3000 + 청구 서비스 3101 + 레거시 CRM 3102 + 아일랜드 감시 빌드
```
브라우저에서 http://localhost:3000 → 로그인 화면에서 **김운영(운영자)** 또는 **이조회(조회 전용)**를 고른다 (비밀번호 없는 데모 로그인).

FastAPI 서버 (같은 화면, 포트 8000):
```bash
cd apps/server-py
python3 -m venv .venv
.venv/bin/pip install -r requirements-dev.txt     # 운영만이면 requirements.txt
METRICS_PORT=9465 .venv/bin/uvicorn main:app --reload --port 8000
```
FastAPI는 Express가 만든 `apps/server/public`(자산)과 청구·레거시 서비스를 함께 쓴다. 먼저 루트에서 `npm ci`와 `npm run build`를 해 둔다.

## 포트
| 포트 | 서비스 |
|---|---|
| 3000 | 포털 (Express) |
| 8000 | 포털 (FastAPI 대안) |
| 3101 | 청구 서비스 (15편, 게이트웨이 뒤 업스트림) |
| 3102 | 레거시 CRM (16편, 점진적 대체 대상) |
| 9464 | Express 지표 `/metrics` (20편) |
| 9465 | FastAPI 지표 (로컬에서 함께 띄울 때) |

## 테스트 (19편)
네 서버(3000, 8000, 3101, 3102)를 띄운 상태에서:
```bash
npm test                    # 단위 → FastAPI 라우트 → 두 서버 계약 → E2E (Express·FastAPI 두 프로젝트)
npm run test:unit           # node --test (의존성 없음)
npm run test:py             # pytest + Starlette TestClient (서버 없이)
npm run test:contract       # 두 서버 응답의 htmx 구조 비교
npm run test:e2e            # Playwright Test. 설치된 다른 Chromium을 쓰려면 CHROMIUM_PATH=/경로/chrome
```
운영과 같은 해시 자산으로 테스트하려면 포털 두 서버를 `USE_DIST=1`로 띄운다.

## 운영 모드와 배포 (20편)
| 환경 변수 | 서버 | 의미 |
|---|---|---|
| `NODE_ENV=production` | Express | 해시 자산 매니페스트 사용, 세션 쿠키 `Secure` |
| `APP_ENV=production` | FastAPI | 같은 의미 |
| `USE_DIST=1` | 둘 다 | 개발 중에도 해시 자산 사용 |
| `TRUST_PROXY=1` | Express | TLS를 끝내는 프록시 한 단계를 신뢰 (FastAPI는 uvicorn `--proxy-headers --forwarded-allow-ips`) |
| `ASSERTION_KEY` | 포털·업스트림 | 게이트웨이 서명 키 (17편). 반드시 바꿔서 주입 |
| `BILLING_URL`, `LEGACY_URL` | 포털 | 업스트림 주소 (기본 localhost:3101, 3102) |
| `METRICS_PORT` | 포털 | 지표 포트 (FastAPI 테스트에서는 `off`) |
| `JOB_TICK_MS` | 포털 | 21편 패치 작업 한 단계 간격 (기본 400) |
| `CSRF_CHECK=off`, `COMPRESS_SSE=on` | Express | 실습 비교용 스위치 (운영에서 쓰지 않음) |

```bash
docker build -f deploy/docker/portal-node.Dockerfile   -t htmx-portal-node .
docker build -f deploy/docker/portal-python.Dockerfile -t htmx-portal-python .
docker build -f deploy/docker/upstream.Dockerfile --build-arg SERVICE=billing-service -t htmx-portal-billing .
docker build -f deploy/docker/upstream.Dockerfile --build-arg SERVICE=legacy-crm      -t htmx-portal-legacy-crm .
kubectl apply -f deploy/k8s/00-namespace.yaml
kubectl -n htmx-portal create secret generic portal-secrets --from-literal=ASSERTION_KEY="$(openssl rand -base64 32)"
kubectl apply -f deploy/k8s/20-portal.yaml -f deploy/k8s/30-billing.yaml -f deploy/k8s/31-legacy-crm.yaml -f deploy/k8s/40-gateway.yaml
```
`40-gateway.yaml`의 `gatewayClassName`, 호스트 이름, TLS 시크릿과 매니페스트의 이미지 이름은 환경에 맞게 바꾼다.
세션·SSE 변경 버스·기능 플래그가 메모리에 있으므로 포털은 replicas 1로만 배포한다 (20편).

## 구조
| 경로 | 내용 | 주로 다룬 편 |
|---|---|---|
| `apps/server` | Express 5 + Eta: 셸 페이지, HTML 조각, 데이터 API, SSE·WebSocket, 게이트웨이, 지표 | 2~21 |
| `apps/server-py` | FastAPI + Jinja2: 같은 URL·같은 동작의 대안 서버 | 2~21 |
| `apps/shared-runtime` | React를 ES 모듈로 한 번만 내보내는 공유 런타임 (import map) | 15 |
| `apps/react-islands` | React 19 아일랜드 (웹 컴포넌트: metric-chart, hello-react) | 2, 11~13 |
| `apps/vue-islands` | Vue 3 아일랜드 (hello-vue, metric-summary) | 2, 12~13 |
| `apps/react-console` | React Router SPA 안의 htmx 영역 (패턴 B) | 14 |
| `apps/billing-service` | 다른 팀 서비스 흉내 (패턴 C 게이트웨이 업스트림) | 15, 17 |
| `apps/legacy-crm` | 옮겨 갈 레거시 (패턴 D) | 16, 17 |
| `scripts/build-assets.mjs` | 자산 파이프라인 | 20 |
| `tests/` | unit · py · contract · e2e | 19~21 |
| `deploy/` | Dockerfile, Kubernetes·Gateway API 매니페스트 | 20 |
| `.github/workflows/ci.yml` | CI (fast → e2e, manifests) | 19~20 |

## 고정 버전 (2026-11-11 재확인)
htmx.org 4.0.1, express 5.3.0, eta 4.6.0, compression 1.8.2, ws 8.22.2, prom-client 15.1.3, web-vitals 6.2.3,
vite 8.3.8, @vitejs/plugin-react 6.3.0, @vitejs/plugin-vue 6.0.10, react·react-dom 19.3.1, vue 3.5.45, react-router 8.5.1,
concurrently 10.0.7, @playwright/test 1.65.0 /
fastapi 0.162.4, uvicorn 0.54.0, jinja2 3.1.6, python-multipart 0.0.33, websockets 17.4, httpx 0.28.1,
prometheus-client 0.26.0, pytest 9.2.0, httpx2 2.16.0 /
컨테이너 node:26-slim, python:3.13-slim / Gateway API v1 (최신 릴리스 v1.7.0)

## 알려진 한계
- 상태(세션·VM·작업·플래그)가 프로세스 메모리에 있다. 재시작하면 초기화되고, 여러 인스턴스로 늘릴 수 없다
- 데모 로그인은 비밀번호가 없다. 실제 인증(OIDC 등)으로 바꿔야 한다
- 컨테이너 이미지 빌드와 클러스터 적용, GitHub Actions 실행은 강의 제작 환경에서 직접 하지 못했다 (명령 재현·스키마 검사까지 확인)
