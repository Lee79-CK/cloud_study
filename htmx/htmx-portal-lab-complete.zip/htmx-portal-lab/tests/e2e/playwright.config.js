// 19편: E2E 테스트 (Playwright Test). 같은 시나리오를 Express·FastAPI 두 서버에 각각 돌린다(projects).
// 로컬: 서버들을 띄워 둔 채 npm run test:e2e  /  CI: webServer가 서버를 띄운다
import { defineConfig } from '@playwright/test';

const launchOptions = process.env.CHROMIUM_PATH ? { executablePath: process.env.CHROMIUM_PATH } : {};
// CI에서는 워크플로가 서버를 먼저 띄우고(계약 테스트도 같은 서버를 쓰므로) 그대로 재사용한다
const reuse = true;

export default defineConfig({
  testDir: '.',
  outputDir: 'test-results',
  fullyParallel: false,          // 서버 메모리 상태(/lab/reset)를 공유하므로 순서대로
  workers: 1,
  retries: process.env.CI ? 1 : 0,
  reporter: process.env.CI ? [['list'], ['html', { open: 'never', outputFolder: 'playwright-report' }]] : 'list',
  use: { trace: 'retain-on-failure', launchOptions },
  projects: [
    { name: 'express', use: { baseURL: process.env.EXPRESS_URL ?? 'http://localhost:3000' } },
    { name: 'fastapi', use: { baseURL: process.env.FASTAPI_URL ?? 'http://localhost:8000' } },
  ],
  webServer: [
    { command: 'npm run start -w apps/billing-service', port: 3101, reuseExistingServer: reuse, cwd: '../..' },
    { command: 'npm run start -w apps/legacy-crm', port: 3102, reuseExistingServer: reuse, cwd: '../..' },
    { command: 'npm run start -w apps/server', port: 3000, reuseExistingServer: reuse, cwd: '../..' },
    { command: '.venv/bin/uvicorn main:app --port 8000', port: 8000, reuseExistingServer: reuse, cwd: '../../apps/server-py' },
  ],
});
