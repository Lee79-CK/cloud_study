// 21편: 종합 실습 E2E — VM 선택 → 패치 작업 → SSE 진행 → 완료 / 취소, 다른 사용자 화면 실시간 반영
import { test, expect } from '@playwright/test';
import { login, reset } from './helpers.js';

test('선택한 VM으로 작업을 만들면 상세로 이동하고 SSE로 완료까지', async ({ browser, baseURL }) => {
  const a = await (await browser.newContext({ baseURL })).newPage();
  const v = await (await browser.newContext({ baseURL })).newPage();
  await login(a, 'kim'); await reset(a); await login(v, 'lee');
  await v.goto('/jobs');
  await expect(v.locator('#live')).toHaveAttribute('data-state', 'on');
  await a.goto('/vms');
  for (const n of ['web-01', 'web-02', 'db-01']) await a.check(`#row-${n} input[name=sel]`);
  await a.click('button:has-text("패치 작업 만들기")');
  await expect(a).toHaveURL(/\/jobs\/J-0001$/);
  await expect(a.locator('#job-J-0001')).toContainText('건너뜀 (중지된 VM)');
  await expect(v.locator('#job-row-J-0001')).toBeVisible();                 // 조회 전용 화면에 새 행 (SSE)
  await expect(a.locator('#job-J-0001 .job-percent')).toHaveText('100%', { timeout: 10000 });
  await expect(v.locator('#job-row-J-0001')).toContainText('완료');
});

test('작업 취소 → 토스트, 상세는 SSE로 취소됨', async ({ page }) => {
  await login(page); await reset(page);
  await page.goto('/vms');
  for (const n of ['api-01', 'api-02']) await page.check(`#row-${n} input[name=sel]`);
  await page.click('button:has-text("패치 작업 만들기")');
  await expect(page).toHaveURL(/\/jobs\/J-0001$/);
  await page.click('#job-J-0001 button:has-text("작업 취소")');
  await page.click('#confirm-dialog button[value=ok]');
  await expect(page.locator('#toasts')).toContainText('J-0001 작업을 취소했습니다');
  await expect(page.locator('#job-J-0001 .job-state')).toHaveText('취소됨');
});
