<script setup>
// 13편: Vue 아일랜드. React 차트가 보낸 metric:select를 document에서 듣고(프레임워크 중립인 DOM 이벤트),
// 같은 데이터 API를 직접 읽어 최근 5분 요약을 보여 준다. React와 Vue는 서로를 import하지 않는다
import { ref, computed, onMounted, onUnmounted, watch, version } from 'vue';
const props = defineProps({ vm: { type: String, required: true } });
const data = ref(null);
const picked = ref(null);
async function load() {
  const res = await fetch(`/api/vms/${encodeURIComponent(props.vm)}/metrics`, { headers: { Accept: 'application/json' } });
  if (res.ok) data.value = await res.json();
}
const onSelect = (e) => { if (e.detail?.vm === props.vm) picked.value = e.detail; };
onMounted(() => { load(); document.addEventListener('metric:select', onSelect); });
onUnmounted(() => document.removeEventListener('metric:select', onSelect));
watch(() => props.vm, () => { picked.value = null; load(); });
const stats = computed(() => {
  if (!data.value) return null;
  const v = data.value.points.map(p => p.cpu);
  return { avg: Math.round(v.reduce((a, b) => a + b, 0) / v.length), max: Math.max(...v) };
});
const fmt = (t) => new Date(t).toTimeString().slice(0, 8);
</script>

<template>
  <div class="sum">
    <span v-if="stats">5분 평균 <b>{{ stats.avg }}%</b> · 최대 <b>{{ stats.max }}%</b></span>
    <span v-if="picked"> · 선택 {{ fmt(picked.t) }} <b>{{ picked.cpu }}%</b></span>
    <small> · Vue {{ version }}</small>
  </div>
</template>

<style>
.sum { font: 13px system-ui, sans-serif; color: #2e8b5e; }
b { font-weight: 700; }
small { color: #8a93a6; }
</style>
