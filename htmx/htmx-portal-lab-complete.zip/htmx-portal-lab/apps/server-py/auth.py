"""6편: 실습용 세션·역할 관리 (Express 쪽 auth.js와 같은 규칙). 비밀번호 없는 데모 로그인."""
import time
import uuid
from contextvars import ContextVar
from urllib.parse import urlsplit

USERS = {"kim": {"name": "김운영", "role": "operator"}, "lee": {"name": "이조회", "role": "viewer"}}
ROLE_LABEL = {"operator": "운영자", "viewer": "조회 전용"}
SESSION_TTL = 30 * 60
_sessions: dict[str, dict] = {}
current_user: ContextVar[dict | None] = ContextVar("current_user", default=None)
current_client: ContextVar[str | None] = ContextVar("current_client", default=None)   # 10편: 탭 식별자
current_nonce: ContextVar[str | None] = ContextVar("current_nonce", default=None)     # 17편: CSP nonce


def create_session(user_id: str) -> str:
    sid = str(uuid.uuid4())
    _sessions[sid] = {"user_id": user_id, "role": USERS[user_id]["role"], "expires_at": time.time() + SESSION_TTL}
    return sid


def get_session(sid: str | None) -> dict | None:
    s = _sessions.get(sid or "")
    if not s:
        return None
    if time.time() > s["expires_at"]:
        _sessions.pop(sid, None)
        return None
    return s


def destroy_session(sid: str | None) -> None:
    _sessions.pop(sid or "", None)


def safe_next(raw: str | None, self_origin: str) -> str:
    """같은 출처(origin)의 경로만 허용해 열린 리다이렉트를 막는다"""
    if not raw:
        return "/vms"
    try:
        u = urlsplit(raw)
    except ValueError:
        return "/vms"
    if u.scheme or u.netloc:
        if f"{u.scheme}://{u.netloc}" != self_origin:
            return "/vms"
    elif not raw.startswith("/") or raw.startswith("//") or raw.startswith("/\\"):
        return "/vms"
    path = (u.path or "/") + (f"?{u.query}" if u.query else "")
    return "/vms" if path.startswith("/login") else path
