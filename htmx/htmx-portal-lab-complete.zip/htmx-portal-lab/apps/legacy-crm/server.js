// 16편: 옮겨 갈 대상인 "레거시 고객사 관리(CRM)". 몇 년 전에 만든 서버 렌더링 앱이라고 가정한다.
// 자기 레이아웃을 가진 전체 페이지를 돌려주고, 폼은 전체 새로고침(POST → 303)으로 동작한다.
// 데이터의 주인이므로 새 구현이 읽고 쓸 수 있게 JSON API도 연다. 게이트웨이 토큰 규칙은 15편과 같다.
import { createServer } from 'node:http';
// 17편: 게이트웨이가 HMAC으로 서명한 신원 주장 검증 (포털 apps/server/src/assertion.js와 같은 규칙)
import { createHmac, timingSafeEqual } from 'node:crypto';
const ASSERTION_KEY = process.env.ASSERTION_KEY ?? 'lab-assertion-key-change-me';
function verifyAssertion(token, aud) {
  const [body, sig] = String(token ?? '').split('.');
  if (!body || !sig) return { ok: false, reason: 'missing' };
  const expected = createHmac('sha256', ASSERTION_KEY).update(body).digest();
  const given = Buffer.from(sig, 'base64url');
  if (given.length !== expected.length || !timingSafeEqual(given, expected)) return { ok: false, reason: 'bad-signature' };
  const claims = JSON.parse(Buffer.from(body, 'base64url').toString());
  if (claims.aud !== aud) return { ok: false, reason: 'wrong-audience' };
  if (claims.exp < Math.floor(Date.now() / 1000)) return { ok: false, reason: 'expired' };
  return { ok: true, claims };
}

const PORT = Number(process.env.PORT ?? 3102);
const esc = (s) => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

let customers = [];
function reset() {
  customers = [
    { id: 1, name: '한빛물산', owner: '박담당', contract: '2026-12-31', vmCount: 12, memo: '연말 갱신 협의 중' },
    // 레거시 DB의 VM 수는 야간 배치로 갱신되는 사본이라 실제(포털)와 어긋날 수 있다 (6절 그림자 비교에서 드러남)
    { id: 2, name: '누리로지스', owner: '최담당', contract: '2027-03-31', vmCount: 11, memo: '' },
    { id: 3, name: '새솔제약', owner: '정담당', contract: '2027-06-30', vmCount: 12, memo: 'GPU 증설 문의' },
    { id: 4, name: '다온핀테크', owner: '한담당', contract: '2026-11-30', vmCount: 12, memo: '보안 감사 일정 확인' },
  ];
}
reset();

const page = (title, body) => `<!DOCTYPE html><html lang="ko"><head><meta charset="utf-8"><title>${esc(title)} - 고객사 관리 v1</title>
<style>body{font-family:serif;background:#f3efe4;color:#222;margin:0} .bar{background:#4a3b6b;color:#fff;padding:8px 14px}
table{border-collapse:collapse} td,th{border:1px solid #aaa;padding:4px 10px} .wrap{padding:14px} .legacy-note{color:#7a5a00}</style></head>
<body><div class="bar">고객사 관리 v1 (레거시) · <a style="color:#fff" href="/vms">포털로</a></div><div class="wrap" id="content">${body}</div></body></html>`;

function listPage() {
  return page('고객사 목록', `<h2>고객사 목록</h2><table><tr><th>ID</th><th>고객사</th><th>담당</th><th>계약 만료</th><th>VM 수</th></tr>
${customers.map(c => `<tr><td>${c.id}</td><td><a href="/customers/${c.id}">${esc(c.name)}</a></td><td>${esc(c.owner)}</td><td>${c.contract}</td><td class="vm-count">${c.vmCount}</td></tr>`).join('')}
</table><p class="legacy-note">※ 이 화면은 레거시 시스템입니다.</p>`);
}
function detailPage(c, who) {
  return page(c.name, `<h2 class="cust-name">${esc(c.name)}</h2>
<p>담당: <span class="cust-owner">${esc(c.owner)}</span> · 계약 만료: <span class="cust-contract">${c.contract}</span> · VM: <span class="vm-count">${c.vmCount}</span>대</p>
<form method="post" action="/customers/${c.id}/memo"><p>메모<br><textarea name="memo" rows="3" cols="50">${esc(c.memo)}</textarea></p>
<button type="submit">저장 (전체 새로고침)</button></form>
<p><a href="/customers">← 목록</a></p><p class="legacy-note">요청 사용자: ${esc(who)} · 레거시 화면</p>`);
}

async function readBody(req) {
  let s = ''; for await (const ch of req) s += ch; return s;
}

createServer(async (req, res) => {
  const url = new URL(req.url, 'http://legacy');
  const send = (status, body, type = 'text/html; charset=utf-8', headers = {}) => { res.writeHead(status, { 'Content-Type': type, ...headers }); res.end(body); };
  const json = (status, obj) => send(status, JSON.stringify(obj), 'application/json; charset=utf-8');
  console.log(`LEGACY ${req.method} ${url.pathname} rid=${String(req.headers['x-request-id'] ?? '-').slice(0, 8)}`);
  // 17편: 게이트웨이가 서명한 신원 주장만 믿는다
  // 20편: Kubernetes 프로브용 상태 확인 (신원 확인 전)
  if (url.pathname === '/healthz') { res.writeHead(200, { 'Content-Type': 'text/plain' }); return res.end('ok'); }
  const v = verifyAssertion(req.headers['x-portal-assertion'], 'legacy-crm');
  if (!v.ok) { console.log(`LEGACY 거부 reason=${v.reason}`); return send(403, `신원 확인 실패 (${v.reason})`); }
  const who = v.claims.sub;
  let m;
  // ---- 화면 (전체 페이지) ----
  if (req.method === 'GET' && url.pathname === '/customers') return send(200, listPage());
  if (req.method === 'GET' && (m = url.pathname.match(/^\/customers\/(\d+)$/))) {
    const c = customers.find(x => x.id === Number(m[1]));
    return c ? send(200, detailPage(c, who)) : send(404, page('없음', '<p>고객사를 찾을 수 없습니다.</p>'));
  }
  if (req.method === 'POST' && (m = url.pathname.match(/^\/customers\/(\d+)\/memo$/))) {
    const c = customers.find(x => x.id === Number(m[1]));
    if (!c) return send(404, '없음');
    c.memo = new URLSearchParams(await readBody(req)).get('memo') ?? '';
    return send(303, '', 'text/plain', { Location: `/customers/${c.id}` });
  }
  // ---- 데이터 API (새 구현이 사용) ----
  if (req.method === 'GET' && url.pathname === '/api/customers') return json(200, customers);
  if ((m = url.pathname.match(/^\/api\/customers\/(\d+)$/))) {
    const c = customers.find(x => x.id === Number(m[1]));
    if (!c) return json(404, { error: 'not_found' });
    if (req.method === 'GET') return json(200, c);
    if (req.method === 'PATCH') {
      const body = JSON.parse(await readBody(req) || '{}');
      if (typeof body.memo === 'string') c.memo = body.memo.slice(0, 500);
      return json(200, c);
    }
  }
  if (req.method === 'POST' && url.pathname === '/reset') { reset(); return send(200, 'ok', 'text/plain'); }
  send(404, page('없음', '<p>없는 경로</p>'));
}).listen(PORT, () => console.log(`▶ 레거시 CRM http://localhost:${PORT} (업스트림, 직접 접근 불가)`));
