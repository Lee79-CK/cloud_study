"""21편: 종합 실습 — 패치 작업 (Express 쪽 jobs.js와 같은 규칙). 진행은 타이머 스레드가, 알림은 listeners로"""
import math
import os
import threading
from datetime import datetime

import store

STEPS = ["스냅샷", "패치 적용", "재부팅", "상태 확인"]
MAX_VMS = 20
TICK = int(os.environ.get("JOB_TICK_MS", "400")) / 1000
listeners: list = []
_jobs: list[dict] = []
_seq = 0
_lock = threading.Lock()
_timers: dict = {}


def _emit(job_id: str, kind: str) -> None:
    for fn in list(listeners):
        fn({"id": job_id, "kind": kind})


def reset_jobs() -> None:
    global _jobs, _seq
    for t in _timers.values():
        t.cancel()
    _timers.clear()
    _jobs, _seq = [], 0


def list_jobs() -> list:
    return _jobs


def find_job(job_id: str):
    return next((j for j in _jobs if j["id"] == job_id), None)


def create_job(names, user: dict) -> dict:
    global _seq
    uniq = list(dict.fromkeys(str(n) for n in (names or [])))
    if not uniq:
        return {"error": "VM을 하나 이상 선택하세요.", "status": 422}
    if len(uniq) > MAX_VMS:
        return {"error": f"한 번에 {MAX_VMS}대까지 선택할 수 있습니다.", "status": 422}
    missing = [n for n in uniq if not store.find(n)]
    if missing:
        return {"error": f"없는 VM: {', '.join(missing)}", "status": 422}
    with _lock:
        _seq += 1
        job = {"id": f"J-{_seq:04d}", "created_by": user["id"], "created_at": datetime.now(), "finished_at": None,
               "state": "running",
               # 중지된 VM은 패치하지 않고 건너뛴다
               "targets": [{"name": n, "step": 0, "state": "skipped" if store.find(n)["status"] == "stopped" else "pending"} for n in uniq]}
        _jobs.insert(0, job)
    _schedule(job)
    _emit(job["id"], "created")
    return {"job": job}


def _schedule(job: dict) -> None:
    t = threading.Timer(TICK, _tick, args=(job,))
    t.daemon = True
    _timers[job["id"]] = t
    t.start()


def _tick(job: dict) -> None:
    with _lock:
        if job["state"] != "running":
            return
        cur = next((t for t in job["targets"] if t["state"] in ("pending", "running")), None)
        if cur:
            cur["state"] = "running"
            cur["step"] += 1
            if cur["step"] >= len(STEPS):
                cur["state"] = "done"
    if cur:
        _emit(job["id"], "progress")
    if not any(t["state"] in ("pending", "running") for t in job["targets"]):
        _finish(job, "done")
    else:
        _schedule(job)


def _finish(job: dict, state: str) -> None:
    with _lock:
        t = _timers.pop(job["id"], None)
        if t:
            t.cancel()
        if job["state"] != "running":
            return
        job["state"] = state
        job["finished_at"] = datetime.now()
        if state == "cancelled":
            for t in job["targets"]:
                if t["state"] in ("pending", "running"):
                    t["state"] = "cancelled"
    _emit(job["id"], state)


def cancel_job(job_id: str) -> dict:
    job = find_job(job_id)
    if not job:
        return {"error": "작업을 찾을 수 없습니다.", "status": 404}
    if job["state"] != "running":
        return {"error": "이미 끝난 작업입니다.", "status": 409}
    _finish(job, "cancelled")
    return {"job": job}


def progress(job: dict) -> dict:
    active = [t for t in job["targets"] if t["state"] != "skipped"]
    total = len(active) * len(STEPS)
    done = sum(min(t["step"], len(STEPS)) for t in active)
    # Python round()는 .5에서 짝수로 반올림하므로 JavaScript Math.round와 맞추려고 floor(x + 0.5) (11편과 같은 이유)
    return {"done": done, "total": total, "percent": math.floor(done / total * 100 + 0.5) if total else 100}
