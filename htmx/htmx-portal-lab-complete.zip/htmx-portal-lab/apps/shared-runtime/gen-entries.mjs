// 15편: npm의 react·react-dom은 CommonJS라 `export * from 'react'`로는 이름 있는 내보내기가 생기지 않는다(측정).
// 실제 내보내기 이름을 읽어 ES 모듈 진입점을 만들어 둔다. 의존성 버전을 올리면 다시 실행한다
import { createRequire } from 'node:module';
import { writeFileSync } from 'node:fs';
const require = createRequire(import.meta.url);
const entries = { react: 'react', 'react-jsx-runtime': 'react/jsx-runtime', 'react-dom-client': 'react-dom/client' };
for (const [file, spec] of Object.entries(entries)) {
  const names = Object.keys(require(spec)).filter(n => /^[A-Za-z_$][\w$]*$/.test(n) && n !== 'default');
  const src = `// 자동 생성: node gen-entries.mjs (${spec})\nimport M from '${spec}';\nexport default M;\nexport const { ${names.join(', ')} } = M;\n`;
  writeFileSync(`src/${file}.js`, src);
  console.log(file, names.length, 'names');
}
