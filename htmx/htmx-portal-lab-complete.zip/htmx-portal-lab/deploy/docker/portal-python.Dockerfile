# syntax=docker/dockerfile:1
# 20편: 포털(FastAPI) 이미지. 자산은 Node 단계에서 같은 파이프라인으로 만든다 (두 서버가 같은 매니페스트를 씀)
FROM node:26-slim AS assets
WORKDIR /app
COPY package.json package-lock.json ./
COPY apps/server/package.json apps/server/
COPY apps/server/scripts apps/server/scripts
COPY apps/shared-runtime/package.json apps/shared-runtime/
COPY apps/react-islands/package.json apps/react-islands/
COPY apps/vue-islands/package.json apps/vue-islands/
COPY apps/react-console/package.json apps/react-console/
COPY apps/billing-service/package.json apps/billing-service/
COPY apps/legacy-crm/package.json apps/legacy-crm/
RUN npm ci
COPY . .
RUN npm run build

FROM python:3.13-slim
ENV APP_ENV=production PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1 METRICS_PORT=9464
WORKDIR /app/apps/server-py
COPY apps/server-py/requirements.txt ./
RUN pip install --no-cache-dir -r requirements.txt && useradd --system --uid 10001 app
COPY apps/server-py/ ./
COPY --from=assets /app/apps/server/public /app/apps/server/public
USER 10001
EXPOSE 8000 9464
# 게이트웨이(TLS 종료) 뒤: X-Forwarded-* 를 믿어야 https 출처·리다이렉트가 맞다
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000", "--proxy-headers", "--forwarded-allow-ips", "*"]
