// 포털 공통 스크립트 (7편에서 레이아웃 인라인 스크립트를 이 파일로 옮김)
// <head>에서 defer로 한 번만 실행된다. hx-boost로 페이지를 이동하면 <body>만 바뀌고 <head>의 스크립트는
// 다시 실행되지 않으므로, 여기서 건 document 리스너는 중복 없이 한 벌만 유지된다.
// 반대로 <body> 안의 인라인 스크립트는 부스트 이동 때마다 다시 실행된다(7편 4절).

function showHtmxVersion() {
  const el = document.getElementById('htmx-ver');
  if (el) el.textContent = window.htmx ? htmx.version : '로드 실패';
}
document.addEventListener('DOMContentLoaded', showHtmxVersion);
document.addEventListener('htmx:after:swap', showHtmxVersion);   // 부스트로 헤더가 새로 그려진 뒤에도

// 4편: hx-confirm을 <dialog>로 처리. 대화상자 요소는 부스트 때마다 새로 그려지므로 매번 찾는다
document.addEventListener('htmx:confirm', (e) => {
  const dialog = document.getElementById('confirm-dialog');
  if (!dialog) return;                                  // 대화상자가 없는 페이지면 기본 window.confirm
  e.preventDefault();
  const { ctx, issueRequest, dropRequest } = e.detail;
  document.getElementById('confirm-message').textContent = ctx.confirm;
  dialog.returnValue = '';
  dialog.addEventListener('close', () => {
    dialog.returnValue === 'ok' ? issueRequest() : dropRequest();
  }, { once: true });
  dialog.showModal();
});

// 4편: 서버가 HX-Trigger로 보낸 vmRemoved를 받아 삭제 카운터 증가 (이전에는 vms 페이지의 인라인 스크립트)
document.addEventListener('vmRemoved', (e) => {
  const el = document.getElementById('rm-count');
  if (el) el.textContent = Number(el.textContent) + 1;
  console.log('삭제됨:', e.detail.name);
});

// 6편: 서버가 응답하지 못한 경우는 클라이언트가 처리한다
function localToast(msg) {
  const box = document.getElementById('toasts');
  if (!box) return;
  const t = document.createElement('div');
  t.className = 'toast warn'; t.setAttribute('role', 'status'); t.textContent = msg;
  box.append(t);
  setTimeout(() => t.remove(), 5000);
}
document.addEventListener('htmx:response:error', (e) => {
  const s = e.detail.ctx.response.status;
  if (s >= 500) localToast(`서버 오류가 발생했습니다 (${s}). 잠시 후 다시 시도하세요.${ridOf(e)}`);
});
document.addEventListener('htmx:error', (e) => {
  const timedOut = e.detail.ctx?.request?.signal?.reason === 'timeout';
  localToast((timedOut ? '응답 시간이 초과되었습니다.' : '서버에 연결할 수 없습니다.') + ridOf(e));
});

// 7편: htmx 4.0.1에서 htmx가 처리하는 링크(hx-get 링크, 부스트 링크)를 Ctrl·Cmd·Shift+클릭하면
// 기본 동작(새 탭·새 창)이 막히고 htmx 요청도 나가지 않는 것을 실측으로 확인했다.
// 캡처 단계에서 이벤트가 링크의 htmx 리스너까지 내려가지 않게 막아 브라우저 기본 동작을 살린다.
// htmx를 올릴 때 이 동작이 고쳐졌는지 다시 확인하고, 고쳐졌다면 이 블록을 지운다.
document.addEventListener('click', (e) => {
  if (e.button !== 0 || !(e.ctrlKey || e.metaKey || e.shiftKey)) return;
  const link = e.target.closest?.('a[href]');
  if (link) e.stopPropagation();
}, true);

// ===================== 8편: 이벤트로 모든 요청에 공통 동작 붙이기 =====================

// ① 요청 ID: 모든 htmx 요청에 X-Request-ID를 붙인다. 오류 토스트에 함께 보여 주면
//    사용자가 "요청 ID 3f9a…"를 운영팀에 알려 줄 수 있고, 운영팀은 서버 로그에서 바로 찾는다
// (10편: 요청 ID를 붙이는 일은 /js/ext/portal-ops.js 확장으로 옮겼다. 여기서는 읽기만 한다)
function ridOf(e) {
  const id = e.detail.ctx?.request?.headers?.['X-Request-ID'];
  return id ? ` (요청 ID ${id.slice(0, 8)})` : '';
}

// ② 전역 진행 표시줄: 진행 중인 요청을 Set으로 센다. before:request에서 넣고 finally:request에서 뺀다
//    (config:request에서 취소되면 finally:request도 오지 않으므로 before:request에서 넣는 것이 짝이 맞다)
//    폴링처럼 조용히 돌아야 하는 요청은 data-quiet가 붙은 요소 안에서 시작하면 제외
const active = new Set();
function paintProgress() {
  document.getElementById('global-progress')?.classList.toggle('on', active.size > 0);
}
document.addEventListener('htmx:before:request', (e) => {
  if (e.detail.ctx.sourceElement?.closest?.('[data-quiet]')) return;
  active.add(e.detail.ctx); paintProgress();
});
document.addEventListener('htmx:finally:request', (e) => {
  if (active.delete(e.detail.ctx)) paintProgress();
});

// ③ 저장하지 않은 변경 보호: data-guard 폼에 입력이 생기면 표시(요소 속성. 모핑이 지우지 않도록 DOM 속성이 아닌 JS 속성)
document.addEventListener('input', (e) => {
  const form = e.target.closest?.('form[data-guard]');
  if (form) form.__dirty = true;
});
const dirtyIn = (root) => [...(root ?? document).querySelectorAll('form[data-guard]')].some(f => f.__dirty);
document.addEventListener('htmx:config:request', (e) => {
  const { ctx } = e.detail;
  const src = ctx.sourceElement;
  // 바뀔 영역(대상) 안에 저장 안 된 폼이 있고, 요청이 그 폼 자신에서 나온 것이 아니면 확인을 요구한다.
  // ctx.confirm을 여기서 정하면 htmx가 이어서 htmx:confirm(4편의 <dialog>)으로 처리한다
  const scope = ctx.target === document.body ? document : ctx.target;
  if (scope && dirtyIn(scope) && !src?.closest?.('form[data-guard]')) {
    ctx.confirm = '저장하지 않은 변경 사항이 있습니다. 버리고 이동할까요?';
  }
});
document.addEventListener('htmx:after:request', (e) => {
  const { ctx } = e.detail;
  if (ctx.request.method === 'PUT' && ctx.response?.status < 400) {
    const form = ctx.sourceElement?.closest?.('form[data-guard]');
    if (form) form.__dirty = false;        // 저장 성공
  }
});
window.addEventListener('beforeunload', (e) => {   // htmx 밖의 이동(새로고침, 주소 입력)도 보호
  if (dirtyIn(document)) e.preventDefault();
});

// ④ 키보드 단축키: "/" 검색창으로, "r" 현재 조건으로 목록 새로고침 (htmx.ajax 사용)
document.addEventListener('keydown', (e) => {
  if (e.ctrlKey || e.metaKey || e.altKey || e.target.closest?.('input, textarea, select, [contenteditable]')) return;
  const filters = document.getElementById('filters');
  if (!filters) return;
  if (e.key === '/') { e.preventDefault(); filters.querySelector('input[name=q]')?.focus(); }
  if (e.key === 'r') {
    // source를 폼으로 지정하면 GET이어도 폼 값이 함께 간다(3편 규칙: GET은 요소 자신이 폼일 때 폼을 포함)
    htmx.ajax('GET', '/vms', { source: filters, target: '#vm-body' });
  }
});

// (12편: 11편의 아일랜드 등록부는 웹 컴포넌트로 대체되어 삭제했다. 마운트·정리·속성 변화는
//  각 사용자 정의 요소의 connectedCallback·disconnectedCallback·attributeChangedCallback이 맡는다)
