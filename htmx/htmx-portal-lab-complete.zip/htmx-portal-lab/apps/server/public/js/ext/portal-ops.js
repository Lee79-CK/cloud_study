// 10편: 직접 만든 htmx 확장. 8편에서 portal.js의 이벤트 리스너로 했던 "요청 ID"를 확장으로 옮기고,
// 느린 요청을 콘솔에 경고하는 기능을 더했다. 확장 메서드 이름은 이벤트 이름의 ':'를 '_'로 바꾼 것이다.
(() => {
  const SLOW_MS = 1000;
  // 이 탭(문서)의 식별자. 서버는 이 값으로 "변경을 일으킨 탭"을 알아내 그 탭에는 같은 변경을 SSE로 되돌려 보내지 않는다
  const CLIENT_ID = crypto.randomUUID();
  let api;
  htmx.registerExtension('portal-ops', {
    init(internalAPI) { api = internalAPI; },   // htmx 내부 API (triggerHtmxEvent 등)

    // htmx:config:request → 모든 요청에 X-Request-ID
    htmx_config_request(elt, { ctx }) {
      ctx.request.headers['X-Request-ID'] = crypto.randomUUID();
      ctx.request.headers['X-Client-ID'] = CLIENT_ID;
    },
    // htmx:before:request → 시작 시각 기록
    htmx_before_request(elt, { ctx }) {
      ctx.portalStartedAt = performance.now();
    },
    // htmx:finally:request → 느린 요청 경고. 내부 API의 triggerHtmxEvent로 detail.warn을 담아 보내면
    // htmx가 console.warn으로 기록한다 (공개 htmx.trigger()는 이 자동 기록을 하지 않는다)
    htmx_finally_request(elt, { ctx }) {
      if (ctx.portalStartedAt == null) return;
      const ms = performance.now() - ctx.portalStartedAt;
      if (ms > SLOW_MS) {
        api.triggerHtmxEvent(elt, 'portal:slow', { warn: `느린 요청 ${Math.round(ms)}ms ${ctx.request.method} ${ctx.request.action}`, ms });
      }
    },
  });
})();
