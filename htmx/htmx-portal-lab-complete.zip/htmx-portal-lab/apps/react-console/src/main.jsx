import { StrictMode, useEffect, useRef, useState, version } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Routes, Route, Link, NavLink, useParams } from 'react-router';

// 14편: 패턴 B. React SPA가 바깥(라우팅·레이아웃)을 소유하고, 그 안의 한 영역을 서버 HTML + htmx에 맡긴다.
// 11편 소유권 규칙을 뒤집어 적용: React는 <HtmxRegion>의 div 안쪽을 절대 렌더링하지 않는다.

const stats = (window.__regionStats ??= { loads: 0, cleanups: 0 });

/**
 * 서버 HTML 조각을 받아 htmx가 관리하게 하는 영역.
 * - 마운트: htmx.ajax로 조각을 받아 넣는다 (htmx가 스왑했으므로 hx-* 속성이 바로 살아 있음)
 * - 정리: htmx.swap으로 비운다. React가 div를 지우기 전에 htmx에게 "이 안의 요소를 정리하라"고 알리는 것
 *   (그냥 지우면 htmx 정리 이벤트가 없어 SSE 연결 등이 다음 메시지까지 남는다 → 측정 7절)
 * - 이벤트: 영역 안 htmx 이벤트는 이 div로 버블링되므로 addEventListener로 받는다
 */
function HtmxRegion({ id, url, onSwap, className }) {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current;
    stats.loads++;
    // source를 영역 div로 지정해야 htmx 이벤트가 이 div에서 발생·버블링된다 (지정하지 않으면 body가 출처)
    htmx.ajax('GET', url, { source: el, target: el, swap: 'innerHTML' });
    const onAfterSwap = () => onSwap?.(new Date());
    el.addEventListener('htmx:after:swap', onAfterSwap);
    return () => {
      el.removeEventListener('htmx:after:swap', onAfterSwap);
      stats.cleanups++;
      if (window.__regionCleanup !== 'none') htmx.swap({ target: el, swap: 'innerHTML', text: '' });
    };
  }, [url]);
  // children 없음: React는 이 div의 안쪽을 건드리지 않는다
  return <div ref={ref} id={id} className={className} />;
}

function Dashboard() {
  const [vms, setVms] = useState([]);
  useEffect(() => {
    fetch('/api/vms', { headers: { Accept: 'application/json' } }).then(r => r.ok ? r.json() : []).then(setVms);
  }, []);
  return (
    <>
      <h1>운영 콘솔 <small className="muted">React {version} SPA</small></h1>
      <section className="box">
        <h2>실시간 요약 <small className="muted">서버 HTML + htmx(SSE) 영역</small></h2>
        <HtmxRegion url="/console/fragments/live-summary" className="htmx-region" />
      </section>
      <section className="box">
        <h2>VM <small className="muted">React가 데이터 API로 그린 목록</small></h2>
        <ul className="console-list">
          {vms.slice(0, 12).map(v => (
            <li key={v.name}><Link to={`/console/vms/${v.name}`}>{v.name}</Link> <span className="muted">{v.customer} · {v.status}</span></li>
          ))}
        </ul>
      </section>
    </>
  );
}

function VmPage() {
  const { name } = useParams();
  const [lastSwap, setLastSwap] = useState(null);
  return (
    <div>
      <p><Link to="/console">← 콘솔 홈</Link></p>
      <h1>{name} <small className="muted">React 헤더 · 아래는 서버 HTML</small></h1>
      <p className="muted">마지막 서버 영역 갱신: {lastSwap ? lastSwap.toTimeString().slice(0, 8) : '-'}
        {' '}<button type="button" onClick={() => htmx.ajax('GET', `/vms/${name}`, { target: '#vm-region', swap: 'innerHTML' })}>서버 영역 새로고침</button></p>
      <HtmxRegion key={name} id="vm-region" url={`/vms/${name}`} onSwap={setLastSwap} className="htmx-region detail-region" />
    </div>
  );
}

function Layout({ children }) {
  return (
    <>
      <header className="top">
        <strong>운영 콘솔</strong>
        <nav><NavLink to="/console" end>홈</NavLink><a href="/vms">htmx 포털로</a></nav>
        <span className="ver">React SPA + htmx {window.htmx?.version}</span>
      </header>
      <main>{children}</main>
    </>
  );
}

// 개발 모드에서는 StrictMode가 effect를 마운트 → 정리 → 마운트로 두 번 실행한다 (6절 측정)
createRoot(document.getElementById('root')).render(
  <StrictMode>
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/console" element={<Dashboard />} />
          <Route path="/console/vms/:name" element={<VmPage />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  </StrictMode>
);
