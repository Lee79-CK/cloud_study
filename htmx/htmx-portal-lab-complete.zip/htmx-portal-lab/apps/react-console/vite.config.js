import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// 14편: 패턴 B. 기존 React SPA(운영 콘솔)를 흉내 낸 앱. /console/ 아래에서 서비스된다.
// 빌드 결과는 Express·FastAPI가 함께 쓰는 public/console로 보낸다
export default defineConfig(({ mode }) => ({
  plugins: [react()],
  base: '/console/',
  // 측정: `vite build --mode development`만으로는 React가 개발 빌드로 묶이지 않았다(StrictMode 이중 실행 없음).
  // 개발 모드 빌드에서는 NODE_ENV를 명시해 React 개발 빌드를 쓰게 한다 (6절)
  define: mode === 'development' ? { 'process.env.NODE_ENV': '"development"' } : {},
  build: {
    // 15편: 콘솔도 React를 공유 런타임에서 가져온다 (아일랜드와 같은 React 한 벌)
    rolldownOptions: { external: ['react', 'react/jsx-runtime', 'react-dom/client'] },
    outDir: '../server/public/console',
    emptyOutDir: true,
    minify: mode !== 'development',
  },
}));
