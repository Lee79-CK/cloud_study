import { defineCustomElement } from 'vue';
import HelloIsland from './HelloIsland.vue';
import MetricSummary from './MetricSummary.ce.vue';

// 12편: Vue는 defineCustomElement를 공식 제공한다. 속성이 prop으로 연결되고, 섀도 DOM 안에 마운트되며,
// 문서에서 떨어지면 다음 틱에 확인 후 스스로 언마운트한다(Vue 소스)
// 13편: .ce.vue 파일의 <style>은 섀도 루트 안에 주입된다
customElements.get('hello-vue') || customElements.define('hello-vue', defineCustomElement(HelloIsland));
customElements.get('metric-summary') || customElements.define('metric-summary', defineCustomElement(MetricSummary));
