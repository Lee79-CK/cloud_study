// 6편: 실습용 세션·역할 관리. 비밀번호 없이 사용자를 고르는 데모 로그인이다.
// 실제 서비스에서는 사내 SSO(OIDC·SAML)로 대체하는 자리 (OAuth·SAML 강의 참고)
import { randomUUID } from 'node:crypto';
import { AsyncLocalStorage } from 'node:async_hooks';

export const USERS = {
  kim: { name: '김운영', role: 'operator' },
  lee: { name: '이조회', role: 'viewer' },
};
export const ROLE_LABEL = { operator: '운영자', viewer: '조회 전용' };
const SESSION_TTL_MS = 30 * 60 * 1000;
const sessions = new Map();          // sid → { userId, role, expiresAt }
export const als = new AsyncLocalStorage();   // 요청마다 현재 사용자를 템플릿 도우미에 전달

export function parseCookies(header = '') {
  return Object.fromEntries(header.split(';').map(p => p.trim().split('=')).filter(([k]) => k)
    .map(([k, ...v]) => [k, decodeURIComponent(v.join('='))]));
}

export function createSession(userId) {
  const sid = randomUUID();
  sessions.set(sid, { userId, role: USERS[userId].role, expiresAt: Date.now() + SESSION_TTL_MS });
  return sid;
}

export function getSession(sid) {
  const s = sid && sessions.get(sid);
  if (!s) return null;
  if (Date.now() > s.expiresAt) { sessions.delete(sid); return null; }
  return s;
}

export const destroySession = sid => sessions.delete(sid);

export function currentUser() {
  return als.getStore()?.user ?? null;
}

// 로그인 뒤 돌아갈 주소. 같은 출처(origin)의 경로만 허용해 열린 리다이렉트(open redirect)를 막는다
export function safeNext(raw, selfOrigin) {
  if (!raw) return '/vms';
  let u;
  try { u = new URL(raw, selfOrigin); } catch { return '/vms'; }
  if (u.origin !== selfOrigin) return '/vms';
  const path = u.pathname + u.search;
  return path.startsWith('/login') ? '/vms' : path;
}
