// 20편: 아일랜드 번들을 "그 태그가 화면에 나타날 때만" 불러온다.
// 11편부터 모든 페이지가 React·Vue 번들을 받던 것을 페이지별로 줄인다. 부스트·스왑으로 들어온 태그도
// htmx:after:process에서 다시 찾으므로, 아일랜드가 없는 페이지에서 시작해 부스트로 이동해도 동작한다.
(() => {
  const map = JSON.parse(document.getElementById('island-bundles')?.textContent || '{}');   // 태그 → 번들 URL (매니페스트)
  const requested = new Set();
  function scan(root) {
    const scope = root?.querySelector ? root : document;
    for (const [tag, url] of Object.entries(map)) {
      if (requested.has(url) || customElements.get(tag)) continue;
      if (scope.matches?.(tag) || scope.querySelector(tag)) {
        requested.add(url);
        import(url).catch((e) => console.error('아일랜드 번들 로드 실패', url, e));
      }
    }
  }
  htmx.onLoad(scan);                                  // 처음 로드와 이후 모든 스왑
})();
