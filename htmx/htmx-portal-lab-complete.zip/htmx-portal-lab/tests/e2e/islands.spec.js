// 아일랜드 E2E: 모핑과 같은 요소 유지(12편), 이벤트 브리지(13편)
import { test, expect } from '@playwright/test';
import { login, reset } from './helpers.js';

test.beforeEach(async ({ page }) => { await login(page); await reset(page); });

test('상세 패널을 다른 VM HTML로 모핑해도 차트 요소는 같은 노드', async ({ page }) => {
  await page.goto('/vms/web-01');
  await expect(page.locator('#detail-chart svg polyline')).toBeVisible();
  await page.evaluate(() => { window.__el = document.getElementById('detail-chart'); });
  await page.evaluate(async () => {
    const t = await fetch('/vms/web-03', { headers: { 'HX-Request': 'true', 'HX-Request-Type': 'partial' } }).then(r => r.text());
    await htmx.swap({ target: document.getElementById('detail'), swap: 'innerMorph', text: t });
  });
  expect(await page.evaluate(() => document.getElementById('detail-chart') === window.__el)).toBe(true);
  await expect(page.locator('#detail-chart')).toHaveAttribute('vm', 'web-03');
});

test('차트 점 클릭 → htmx 영역이 그 시점 활동을 요청', async ({ page }) => {
  await page.goto('/vms/web-01');
  await expect(page.locator('#detail-chart svg polyline')).toBeVisible();
  const req = page.waitForRequest(r => r.url().includes('/vms/web-01/activity/window?t='));
  await page.locator('#detail-chart rect.hit').last().click();
  await req;
  await expect(page.locator('#win-web-01')).toContainText('전후 1분');
});
