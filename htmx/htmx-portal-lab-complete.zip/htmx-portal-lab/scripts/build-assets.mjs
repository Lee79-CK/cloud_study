// 20편: 정적 자산 파이프라인. (1) 이름이 고정된 파일에 내용 해시를 붙여 public/dist/로 복사하고
// (2) Vite가 만든 해시 파일(아일랜드·공유 런타임)까지 합쳐 논리 이름 → 실제 URL 매니페스트를 만들고
// (3) 모든 해시 파일을 최고 품질 br(11)·gzip(9)로 미리 압축해 둔다. 서버는 매니페스트만 읽는다.
import { createHash } from 'node:crypto';
import { cpSync, existsSync, mkdirSync, readdirSync, readFileSync, rmSync, statSync, writeFileSync } from 'node:fs';
import { basename, dirname, extname, join, relative } from 'node:path';
import { fileURLToPath } from 'node:url';
import { brotliCompressSync, constants, gzipSync } from 'node:zlib';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const PUBLIC = join(root, 'apps/server/public');
const DIST = join(PUBLIC, 'dist');

// 논리 이름 → 원본 파일
const sources = {
  'vendor/htmx/htmx.min.js': join(PUBLIC, 'vendor/htmx/htmx.min.js'),
  ...Object.fromEntries(['hx-live', 'hx-sse', 'hx-ws', 'hx-ptag', 'hx-preload', 'hx-csp'].map(n =>
    [`vendor/htmx/ext/${n}.js`, join(PUBLIC, `vendor/htmx/ext/${n}.js`)])),
  'vendor/web-vitals.js': join(PUBLIC, 'vendor/web-vitals.js'),   // copy-vendor(postinstall)가 복사해 둔 것
  ...Object.fromEntries(['portal.js', 'ext/portal-ops.js', 'event-monitor.js', 'csp-demo.js', 'islands-loader.js', 'rum.js'].map(n =>
    [`js/${n}`, join(PUBLIC, 'js', n)])),
  'css/tokens.css': join(PUBLIC, 'css/tokens.css'),
  'css/app.css': join(PUBLIC, 'css/app.css'),
};

rmSync(DIST, { recursive: true, force: true });
const manifest = {};
for (const [logical, file] of Object.entries(sources)) {
  const body = readFileSync(file);
  const hash = createHash('sha256').update(body).digest('base64url').slice(0, 10);
  const ext = extname(logical);
  const out = join(DIST, dirname(logical), `${basename(logical, ext)}-${hash}${ext}`);
  mkdirSync(dirname(out), { recursive: true });
  cpSync(file, out);
  manifest[logical] = '/' + relative(PUBLIC, out).replaceAll('\\', '/');
}

// Vite 매니페스트 합치기 (진입점만)
function viteEntries(dir, prefix, names) {
  const m = JSON.parse(readFileSync(join(PUBLIC, dir, '.vite/manifest.json'), 'utf8'));
  for (const [src, logical] of Object.entries(names)) {
    if (!m[src]) throw new Error(`${dir}의 Vite 매니페스트에 ${src} 없음`);
    manifest[logical] = `/${prefix}/${m[src].file}`;
  }
}
viteEntries('islands/react', 'islands/react', { 'src/main.jsx': 'islands/react.js' });
viteEntries('islands/vue', 'islands/vue', { 'src/main.js': 'islands/vue.js' });
viteEntries('shared', 'shared', { 'src/react.js': 'shared/react.js', 'src/react-jsx-runtime.js': 'shared/react-jsx-runtime.js', 'src/react-dom-client.js': 'shared/react-dom-client.js' });

// 사전 압축: 해시 파일이 있는 폴더 전체
let raw = 0, br = 0, gz = 0, n = 0;
function precompress(dir) {
  if (!existsSync(dir)) return;
  for (const name of readdirSync(dir)) {
    const p = join(dir, name);
    if (statSync(p).isDirectory()) { if (name !== '.vite') precompress(p); continue; }
    if (!/\.(js|css|json|svg|html)$/.test(name)) continue;
    const body = readFileSync(p);
    const b = brotliCompressSync(body, { params: { [constants.BROTLI_PARAM_QUALITY]: 11, [constants.BROTLI_PARAM_SIZE_HINT]: body.length } });
    const g = gzipSync(body, { level: 9 });
    if (b.length < body.length) writeFileSync(p + '.br', b);
    if (g.length < body.length) writeFileSync(p + '.gz', g);
    raw += body.length; br += b.length; gz += g.length; n++;
  }
}
for (const d of ['dist', 'islands', 'shared', 'console/assets']) precompress(join(PUBLIC, d));

mkdirSync(DIST, { recursive: true });
writeFileSync(join(DIST, 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n');
console.log(`[assets] 매니페스트 ${Object.keys(manifest).length}개, 사전 압축 ${n}개 파일: 원본 ${raw}B → br ${br}B / gzip ${gz}B`);
