import { test } from 'node:test';
import assert from 'node:assert/strict';
import * as flags from '../../apps/server/src/flags.js';

const kim = { id: 'kim' }, lee = { id: 'lee' };

test('초기 상태는 전부 레거시', () => {
  flags.resetFlags();
  assert.equal(flags.decide('customers.detail', kim).impl, 'legacy');
});

test('비율 배정은 사용자별로 고정 (kim 58, lee 69 — 16편 측정값)', () => {
  flags.resetFlags();
  flags.setFlag('customers.detail', { mode: 'percent', percent: 60 });
  assert.equal(flags.decide('customers.detail', kim).impl, 'new');
  assert.equal(flags.decide('customers.detail', lee).impl, 'legacy');
  assert.match(flags.decide('customers.detail', lee).reason, /bucket=69/);
  for (let i = 0; i < 5; i++) assert.equal(flags.decide('customers.detail', kim).impl, 'new');
});

test('운영자 강제 지정이 모드보다 우선', () => {
  flags.resetFlags();
  assert.equal(flags.decide('customers.detail', kim, 'new').impl, 'new');
});

test('그림자 모드는 사용자에게 레거시 + shadow 표시', () => {
  flags.resetFlags();
  flags.setFlag('customers.detail', { mode: 'shadow' });
  assert.deepEqual(flags.decide('customers.detail', kim), { impl: 'legacy', shadow: true, reason: 'shadow' });
});

test('잘못된 모드는 거부', () => {
  assert.equal(flags.setFlag('customers.detail', { mode: 'beta' }), false);
});
