// 21편: 패치 작업 상태 기계 (JOB_TICK_MS로 빠르게)
import { test } from 'node:test';
import assert from 'node:assert/strict';
process.env.JOB_TICK_MS = '10';
const store = await import('../../apps/server/src/data.js');
const jobs = await import('../../apps/server/src/jobs.js');
const kim = { id: 'kim' };
const wait = (ms) => new Promise(r => setTimeout(r, ms));

test('검증: 빈 선택·없는 VM·최대 대수', () => {
  store.reset(); jobs.resetJobs();
  assert.equal(jobs.createJob([], kim).status, 422);
  assert.match(jobs.createJob(['nope'], kim).error, /없는 VM/);
  assert.equal(jobs.createJob(Array.from({ length: 21 }, (_, i) => `x${i}`), kim).status, 422);
});

test('중지된 VM은 건너뛰고, 나머지는 4단계를 거쳐 완료', async () => {
  store.reset(); jobs.resetJobs();
  const stopped = store.search('', 'stopped')[0].name;
  const { job } = jobs.createJob(['web-01', stopped], kim);
  assert.equal(job.id, 'J-0001');
  assert.equal(job.targets[1].state, 'skipped');
  const kinds = [];
  jobs.bus.on('change', (e) => kinds.push(e.kind));
  await wait(200);
  assert.equal(job.state, 'done');
  assert.deepEqual(jobs.progress(job), { done: 4, total: 4, percent: 100 });
  assert.equal(kinds.filter(k => k === 'progress').length, 4);
  assert.equal(kinds.at(-1), 'done');
  jobs.bus.removeAllListeners('change');
});

test('취소: 진행 중·대기는 취소됨, 끝난 작업은 409', async () => {
  store.reset(); jobs.resetJobs();
  const { job } = jobs.createJob(['web-01', 'web-02'], kim);
  await wait(25);
  assert.equal(jobs.cancelJob(job.id).job.state, 'cancelled');
  assert.ok(job.targets.every(t => t.state === 'cancelled' || t.state === 'done'));
  assert.equal(jobs.cancelJob(job.id).status, 409);
  jobs.resetJobs();
});
