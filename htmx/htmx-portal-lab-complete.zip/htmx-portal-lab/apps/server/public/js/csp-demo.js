// 17편: /lab/csp 데모의 기록용 스크립트 (인라인 스크립트는 CSP에 막히므로 외부 파일)
(() => {
  const log = (t) => { const li = document.createElement('li'); li.textContent = t; document.getElementById('seclog')?.prepend(li); };
  for (const n of ['htmx:security:strip', 'htmx:security:violation', 'htmx:error']) {
    document.addEventListener(n, (e) => log(`${n} @${e.target.id || e.target.tagName} ${JSON.stringify({ reason: e.detail?.reason, stripped: e.detail?.stripped, error: String(e.detail?.error ?? '') }).slice(0, 160)}`));
  }
  document.addEventListener('securitypolicyviolation', (e) => log(`CSP 위반: ${e.violatedDirective} ${e.blockedURI}`));
})();
