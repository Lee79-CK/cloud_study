// 21편: 종합 실습 — 패치 작업(Job). 선택한 VM마다 단계를 순서대로 진행하는 장기 작업.
// 진행은 서버 타이머가 하고, 바뀔 때마다 변경 버스(10편)에 알려 SSE가 화면에 밀어 준다.
// 실제 서비스에서는 작업 큐(예: 메시지 브로커 + 워커)가 이 자리를 맡는다.
import { EventEmitter } from 'node:events';
import * as store from './data.js';

export const STEPS = ['스냅샷', '패치 적용', '재부팅', '상태 확인'];
export const MAX_VMS = 20;
const TICK_MS = Number(process.env.JOB_TICK_MS ?? 400);
export const bus = new EventEmitter();
bus.setMaxListeners(0);

let jobs = [];
let seq = 0;
const timers = new Map();

export function resetJobs() {
  for (const t of timers.values()) clearInterval(t);
  timers.clear(); jobs = []; seq = 0;
}
export const listJobs = () => jobs;
export const findJob = (id) => jobs.find(j => j.id === id);

/** 검증 후 작업 생성. 반환: { job } 또는 { error, status } */
export function createJob(names, user) {
  const uniq = [...new Set((names ?? []).map(String))];
  if (!uniq.length) return { error: 'VM을 하나 이상 선택하세요.', status: 422 };
  if (uniq.length > MAX_VMS) return { error: `한 번에 ${MAX_VMS}대까지 선택할 수 있습니다.`, status: 422 };
  const missing = uniq.filter(n => !store.find(n));
  if (missing.length) return { error: `없는 VM: ${missing.join(', ')}`, status: 422 };
  const job = {
    id: `J-${String(++seq).padStart(4, '0')}`, createdBy: user.id, createdAt: new Date(), finishedAt: null,
    state: 'running',            // running → done | cancelled
    targets: uniq.map(name => {
      const stopped = store.find(name).status === 'stopped';
      // 중지된 VM은 패치하지 않고 건너뛴다 (운영 규칙: 켜진 VM만 패치 창에 포함)
      return { name, step: 0, state: stopped ? 'skipped' : 'pending' };
    }),
  };
  jobs.unshift(job);
  timers.set(job.id, setInterval(() => tick(job), TICK_MS));
  bus.emit('change', { id: job.id, kind: 'created' });
  return { job };
}

function tick(job) {
  const cur = job.targets.find(t => t.state === 'pending' || t.state === 'running');
  if (!cur) return finish(job, 'done');
  cur.state = 'running';
  cur.step++;
  if (cur.step >= STEPS.length) cur.state = 'done';
  bus.emit('change', { id: job.id, kind: 'progress' });
  if (!job.targets.some(t => t.state === 'pending' || t.state === 'running')) finish(job, 'done');
}

function finish(job, state) {
  clearInterval(timers.get(job.id)); timers.delete(job.id);
  if (job.state !== 'running') return;
  job.state = state; job.finishedAt = new Date();
  if (state === 'cancelled') for (const t of job.targets) if (t.state === 'pending' || t.state === 'running') t.state = 'cancelled';
  bus.emit('change', { id: job.id, kind: state });
}

export function cancelJob(id) {
  const job = findJob(id);
  if (!job) return { error: '작업을 찾을 수 없습니다.', status: 404 };
  if (job.state !== 'running') return { error: '이미 끝난 작업입니다.', status: 409 };
  finish(job, 'cancelled');
  return { job };
}

/** 화면용 요약: 전체 단계 중 끝난 단계 비율 (건너뛴 VM은 제외) */
export function progress(job) {
  const active = job.targets.filter(t => t.state !== 'skipped');
  const total = active.length * STEPS.length;
  const done = active.reduce((a, t) => a + Math.min(t.step, STEPS.length), 0);
  return { done, total, percent: total ? Math.round(done / total * 100) : 100 };
}
