import { defineConfig } from 'vite';
import vue from '@vitejs/plugin-vue';

export default defineConfig({
  plugins: [vue()],
  build: {
    manifest: true,         // 20편: 해시 파일명을 서버가 찾을 수 있게 .vite/manifest.json 생성
    outDir: '../server/public/islands/vue',
    emptyOutDir: true,
    rolldownOptions: {   // Vite 8: Rolldown 번들러 옵션 (rollupOptions는 deprecated 별칭)
      input: 'src/main.js',
      output: {
        entryFileNames: 'vue-islands-[hash].js',   // 20편: 내용 해시 → 1년 immutable 캐시
        chunkFileNames: 'chunks/[name]-[hash].js',
        assetFileNames: 'vue-islands[extname]',
      },
    },
  },
});
