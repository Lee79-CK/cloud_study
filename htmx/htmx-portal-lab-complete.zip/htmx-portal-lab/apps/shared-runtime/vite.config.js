import { defineConfig } from 'vite';

// 15편: 공유 런타임. 여러 진입점을 한 번에 빌드해 React 본체가 공용 청크 하나로 나오게 한다.
// 각 앱(아일랜드, 콘솔)은 react를 번들에 넣지 않고 import map이 가리키는 이 파일들을 import한다.
// (lib 모드의 es 출력은 공백을 압축하지 않아(측정) 일반 빌드 + 진입점 서명 보존으로 만든다)
export default defineConfig({
  define: { 'process.env.NODE_ENV': '"production"' },
  build: {
    manifest: true,         // 20편
    outDir: '../server/public/shared',
    emptyOutDir: true,
    rolldownOptions: {
      input: { react: 'src/react.js', 'react-jsx-runtime': 'src/react-jsx-runtime.js', 'react-dom-client': 'src/react-dom-client.js' },
      preserveEntrySignatures: 'strict',     // 진입점의 export를 지우지 않는다 (앱이 import하므로)
      output: { format: 'es', entryFileNames: '[name]-[hash].js', chunkFileNames: 'chunks/[name]-[hash].js' },   // 20편: 진입점도 해시
    },
  },
});
