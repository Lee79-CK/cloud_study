<script setup>
import { ref, version } from 'vue';
defineProps({ who: { type: String, default: 'Vue' } });
const count = ref(0);
</script>

<template>
  <div>
    <p>{{ who }} {{ version }}이(가) 이 상자를 소유합니다.</p>
    <button @click="count++">클릭 {{ count }}</button>
  </div>
</template>
