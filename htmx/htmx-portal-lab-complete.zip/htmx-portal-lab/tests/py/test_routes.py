"""19편: FastAPI 라우트 테스트 — htmx 계약(헤더·상태 코드·조각 여부)을 검사한다. 실행: npm run test:py"""
import json
import re

from conftest import HX


def test_같은_URL_두_응답_전체와_조각(kim):
    full = kim.get("/vms")
    part = kim.get("/vms", headers=HX)
    assert full.status_code == part.status_code == 200
    assert "<html" in full.text and "<html" not in part.text          # 2편: 조각에는 레이아웃 없음
    assert "HX-Request" in full.headers["vary"]                         # 캐시가 두 응답을 섞지 않게


def test_로그인_안_된_htmx_요청은_401과_HX_Redirect(client):
    r = client.get("/vms/web-01", headers={**HX, "HX-Current-URL": "http://testserver/vms/web-01"})
    assert r.status_code == 401
    assert r.headers["hx-redirect"].startswith("/login?next=")         # 6편


def test_로그인_안_된_데이터_API는_401_JSON(client):
    r = client.get("/api/vms/web-01/metrics")
    assert r.status_code == 401 and r.json() == {"error": "unauthenticated"}   # 11편


def test_조회_전용은_변경_403과_재지정(lee):
    r = lee.post("/vms/web-01/restart", headers=HX)
    assert r.status_code == 403
    assert r.headers.get("hx-retarget") == "#toasts"                    # 6편


def test_재시작_응답_HX_Trigger(kim):
    r = kim.post("/vms/web-01/restart", headers=HX)
    assert r.status_code == 200
    assert '"vmChanged"' in r.headers["hx-trigger"]


def test_CSRF_같은_사이트_다른_출처_차단(kim):
    r = kim.post("/vms/web-01/restart", headers={**HX, "Sec-Fetch-Site": "same-site", "Origin": "http://localhost:3999"})
    assert r.status_code == 403                                         # 17편
    r = kim.post("/vms/web-01/restart", headers={**HX, "Sec-Fetch-Site": "same-origin"})
    assert r.status_code == 200


def test_CSP_nonce가_import_map과_일치(kim):
    r = kim.get("/vms")
    nonce = re.search(r"'nonce-([^']+)'", r.headers["content-security-policy"]).group(1)
    assert f'<script type="importmap" nonce="{nonce}">' in r.text     # 17편
    assert kim.get("/vms").headers["content-security-policy"] != r.headers["content-security-policy"]   # 요청마다 새 nonce


def test_htmx_응답은_no_store_정적_파일은_정책(kim):
    assert kim.get("/vms/summary", headers=HX).headers["cache-control"] == "no-store"   # 18편
    assert kim.get("/vendor/htmx/htmx.min.js").headers["cache-control"] == "no-cache"


def test_hx_ptag_바뀌지_않으면_304(kim):
    r = kim.get("/vms/web-01/activity/live", headers=HX)
    tag = r.headers["hx-ptag"]
    assert kim.get("/vms/web-01/activity/live", headers={**HX, "HX-PTag": tag}).status_code == 304   # 10편
    kim.post("/vms/web-01/tags", data={"tag": "t1"}, headers=HX)
    assert kim.get("/vms/web-01/activity/live", headers={**HX, "HX-PTag": tag}).status_code == 200


def test_지표는_Express와_같은_값():
    import store
    store.reset()
    pts = store.metrics(store.find("web-01"), 1762500000000)["points"]
    assert [p["cpu"] for p in pts[:3]] == [50, 46, 40]                # Node 단위 테스트와 같은 기준값


def test_없는_VM_404_조각(kim):
    r = kim.get("/vms/nope", headers=HX)
    assert r.status_code == 404 and "<html" not in r.text


def test_상태_확인은_로그인_없이(client):
    assert client.get("/healthz").text == "ok"                          # 20편: Kubernetes 프로브
    assert client.get("/readyz").json()["assets"] >= 0


def test_레이아웃은_해시_자산과_아일랜드_지도(kim):
    import main
    html = kim.get("/vms").text
    assert main.asset("vendor/htmx/htmx.min.js") in html                # 운영·USE_DIST=1이면 해시 URL, 개발이면 원본 경로
    if main.USE_DIST and main.MANIFEST:
        assert '/islands/react/react-islands.js' not in html            # 11편의 "모든 페이지에 번들" 제거
    assert 'id="island-bundles"' in html and 'data-page="/vms"' in html


def test_RUM_수신_204와_라벨_제한(client):
    r = client.post("/rum", json=[{"name": "LCP", "value": 812, "rating": "good", "page": "/vms/:name"},
                                  {"name": "LCP", "value": 1, "rating": "good", "page": "<script>"}])
    assert r.status_code == 204                                         # 이상한 page 값은 'other'로 묶임


def test_패치_작업_생성_201과_HX_Location(kim):
    import jobs
    jobs.reset_jobs()
    r = kim.post("/jobs", data={"sel": ["web-01", "web-02"]}, headers=HX)
    assert r.status_code == 201
    assert json.loads(r.headers["hx-location"]) == {"path": "/jobs/J-0001", "target": "body"}   # 21편
    jobs.reset_jobs()


def test_패치_작업_검증과_권한(kim, client):
    r = kim.post("/jobs", data={}, headers=HX)
    assert r.status_code == 422 and r.headers["hx-retarget"] == "#toasts"
    from conftest import login
    login(client, "lee")
    assert client.post("/jobs", data={"sel": "web-01"}, headers=HX).status_code == 403


def test_패치_작업_취소_응답은_토스트로만(kim):
    import jobs
    jobs.reset_jobs()
    kim.post("/jobs", data={"sel": "web-01"}, headers=HX)
    r = kim.post("/jobs/J-0001/cancel", headers=HX)
    assert r.status_code == 200 and r.headers["hx-retarget"] == "#toasts"    # 작업 상세는 SSE가 소유
    assert kim.post("/jobs/J-0001/cancel", headers=HX).status_code == 409
    jobs.reset_jobs()
